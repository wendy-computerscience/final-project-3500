#!/usr/bin/env node

/**
 * 数据库迁移执行脚本
 * 用法: node scripts/migrate.js
 */

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const MIGRATIONS_DIR = path.join(__dirname, '../migrations');

async function runMigrations() {
  let connection;

  try {
    // 创建数据库连接
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'takeaway_platform',
      multipleStatements: true
    });

    console.log('✅ 数据库连接成功');

    // 读取所有迁移文件
    const files = fs.readdirSync(MIGRATIONS_DIR)
      .filter(f => f.endsWith('.sql'))
      .sort();

    console.log(`\n📂 找到 ${files.length} 个迁移文件\n`);

    // 执行每个迁移文件
    for (const file of files) {
      const filePath = path.join(MIGRATIONS_DIR, file);
      const sql = fs.readFileSync(filePath, 'utf8');

      console.log(`⏳ 执行迁移: ${file}`);

      try {
        await connection.query(sql);
        console.log(`✅ 完成: ${file}\n`);
      } catch (err) {
        // 如果是字段已存在的错误，忽略（因为使用了 ADD COLUMN）
        if (err.code === 'ER_DUP_FIELDNAME' || err.code === 'ER_DUP_KEYNAME') {
          console.log(`⚠️  跳过: ${file} (字段/索引已存在)\n`);
        } else {
          throw err;
        }
      }
    }

    console.log('🎉 所有迁移执行完成！');

  } catch (error) {
    console.error('❌ 迁移失败:', error.message);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

// 执行迁移
runMigrations();
