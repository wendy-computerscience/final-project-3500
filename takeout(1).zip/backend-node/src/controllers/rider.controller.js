const riderService = require('../services/rider.service');
const logger = require('../utils/logger');

/**
 * 获取可接订单列表
 */
exports.getAvailableOrders = async (req, res) => {
  try {
    const orders = await riderService.getAvailableOrders();
    res.json({
      success: true,
      data: orders
    });
  } catch (error) {
    logger.error('获取可接订单列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 接单
 */
exports.acceptOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { riderId } = req.body;
    await riderService.acceptOrder(orderId, riderId);
    res.json({
      success: true,
      message: '接单成功'
    });
  } catch (error) {
    logger.error('接单失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取骑手排行榜
 */
exports.getRiderRanking = async (req, res) => {
  try {
    const { period = 'today', type = 'orders', riderId } = req.query;
    const ranking = await riderService.getRiderRanking(period, type, riderId);

    res.json({
      success: true,
      data: ranking
    });
  } catch (error) {
    logger.error('获取骑手排行榜失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取骑手任务列表
 */
exports.getRiderTasks = async (req, res) => {
  try {
    const { riderId } = req.query;
    const tasks = await riderService.getRiderTasks(riderId);

    res.json({
      success: true,
      data: tasks
    });
  } catch (error) {
    logger.error('获取骑手任务列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 领取任务奖励
 */
exports.claimTaskReward = async (req, res) => {
  try {
    const { taskId } = req.params;
    const { riderId } = req.body;
    const result = await riderService.claimTaskReward(riderId, taskId);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('领取任务奖励失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 骑手登录（账号密码登录）
 */
exports.riderLogin = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: '账号和密码不能为空'
      });
    }

    const result = await riderService.riderLogin(username, password);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('骑手登录失败:', error);
    res.status(401).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 骑手退出登录
 */
exports.riderLogout = async (req, res) => {
  try {
    const { riderId } = req.body;

    if (!riderId) {
      return res.status(400).json({
        success: false,
        message: 'riderId不能为空'
      });
    }

    const result = await riderService.riderLogout(riderId);

    res.json({
      success: true,
      message: result.message
    });
  } catch (error) {
    logger.error('退出登录失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 确认取餐
 */
exports.confirmPickup = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { riderId } = req.body;

    if (!riderId) {
      return res.status(400).json({
        success: false,
        message: 'riderId不能为空'
      });
    }

    const result = await riderService.confirmPickup(orderId, riderId);

    res.json({
      success: true,
      message: result.message
    });
  } catch (error) {
    logger.error('确认取餐失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 确认送达
 */
exports.confirmDelivery = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { riderId } = req.body;

    if (!riderId) {
      return res.status(400).json({
        success: false,
        message: 'riderId不能为空'
      });
    }

    const result = await riderService.confirmDelivery(orderId, riderId);

    res.json({
      success: true,
      message: result.message
    });
  } catch (error) {
    logger.error('确认送达失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 提交骑手认证信息
 */
exports.submitRiderAuth = async (req, res) => {
  try {
    const authData = req.body;
    const result = await riderService.submitRiderAuth(authData);

    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('提交骑手认证失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取骑手认证状态
 */
exports.getRiderAuthStatus = async (req, res) => {
  try {
    const { riderId } = req.query;

    if (!riderId) {
      return res.status(400).json({
        success: false,
        message: '缺少骑手ID参数'
      });
    }

    const status = await riderService.getRiderAuthStatus(riderId);

    res.json({
      success: true,
      data: status
    });
  } catch (error) {
    logger.error('获取骑手认证状态失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取骑手收入统计
 */
exports.getRiderIncome = async (req, res) => {
  try {
    const { riderId, period = 'today' } = req.query;
    const income = await riderService.getRiderIncome(riderId, period);

    res.json({
      success: true,
      data: income
    });
  } catch (error) {
    logger.error('获取骑手收入统计失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取骑手订单列表
 */
exports.getRiderOrders = async (req, res) => {
  try {
    const { riderId, status, page = 1, pageSize = 10 } = req.query;
    const result = await riderService.getRiderOrders(riderId, status, page, pageSize);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取骑手订单列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取骑手订单详情
 */
exports.getRiderOrderDetail = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { riderId } = req.query;

    if (!riderId) {
      return res.status(400).json({
        success: false,
        message: '缺少riderId参数'
      });
    }

    const detail = await riderService.getRiderOrderDetail(orderId, riderId);

    res.json({
      success: true,
      data: detail
    });
  } catch (error) {
    logger.error('获取订单详情失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 创建提现申请
 */
exports.createWithdrawal = async (req, res) => {
  try {
    const { riderId, amount, bankAccount, bankName, realName } = req.body;

    // 参数验证
    if (!riderId || !amount || !bankAccount) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数：riderId, amount, bankAccount'
      });
    }

    const result = await riderService.createWithdrawal({
      riderId,
      amount: parseFloat(amount),
      bankAccount,
      bankName,
      realName
    });

    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('创建提现申请失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取提现记录
 */
exports.getWithdrawalRecords = async (req, res) => {
  try {
    const { riderId, page = 1, pageSize = 20 } = req.query;

    if (!riderId) {
      return res.status(400).json({
        success: false,
        message: '缺少riderId参数'
      });
    }

    const result = await riderService.getWithdrawalRecords(riderId, page, pageSize);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取提现记录失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 骑手注册
 */
exports.registerRider = async (req, res) => {
  try {
    const { username, password, realName, phone } = req.body;

    // 参数验证
    if (!username || !password || !realName) {
      return res.status(400).json({
        success: false,
        message: '用户名、密码和真实姓名不能为空'
      });
    }

    // 用户名格式验证
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    if (!usernameRegex.test(username)) {
      return res.status(400).json({
        success: false,
        message: '用户名只能包含字母、数字和下划线，长度3-20个字符'
      });
    }

    // 手机号格式验证（如果提供了手机号）
    if (phone) {
      const phoneRegex = /^1[3-9]\d{9}$/;
      if (!phoneRegex.test(phone)) {
        return res.status(400).json({
          success: false,
          message: '手机号格式不正确'
        });
      }
    }

    const result = await riderService.registerRider({
      username,
      password,
      realName,
      phone
    });

    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('骑手注册失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

