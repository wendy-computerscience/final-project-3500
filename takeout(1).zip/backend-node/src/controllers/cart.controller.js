const cartService = require('../services/cart.service');
const logger = require('../utils/logger');

/**
 * 获取用户购物车
 */
exports.getUserCart = async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: '用户ID不能为空'
      });
    }

    const result = await cartService.getUserCart(parseInt(userId));

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取购物车失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '获取购物车失败'
    });
  }
};

/**
 * 添加商品到购物车
 */
exports.addToCart = async (req, res) => {
  try {
    const { userId, restaurantId, menuItemId, quantity = 1 } = req.body;

    // 参数验证
    if (!userId || !restaurantId || !menuItemId) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    if (quantity < 1) {
      return res.status(400).json({
        success: false,
        message: '数量必须大于0'
      });
    }

    const result = await cartService.addOrUpdateCartItem({
      userId: parseInt(userId),
      restaurantId: parseInt(restaurantId),
      menuItemId: parseInt(menuItemId),
      quantity: parseInt(quantity)
    });

    res.json({
      success: true,
      data: result,
      message: '添加成功'
    });
  } catch (error) {
    logger.error('添加购物车失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '添加购物车失败'
    });
  }
};

/**
 * 更新购物车项数量
 */
exports.updateCartItem = async (req, res) => {
  try {
    const { itemId } = req.params;
    const { quantity, userId } = req.body;

    // 参数验证
    if (!itemId || quantity === undefined || !userId) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    if (quantity < 0) {
      return res.status(400).json({
        success: false,
        message: '数量不能小于0'
      });
    }

    const result = await cartService.updateCartItemQuantity(
      parseInt(itemId),
      parseInt(quantity),
      parseInt(userId)
    );

    res.json({
      success: true,
      data: result,
      message: '更新成功'
    });
  } catch (error) {
    logger.error('更新购物车失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '更新购物车失败'
    });
  }
};

/**
 * 删除购物车项
 */
exports.removeCartItem = async (req, res) => {
  try {
    const { itemId } = req.params;
    const { userId } = req.body;

    if (!itemId || !userId) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const result = await cartService.removeCartItem(
      parseInt(itemId),
      parseInt(userId)
    );

    res.json({
      success: true,
      data: result,
      message: '删除成功'
    });
  } catch (error) {
    logger.error('删除购物车项失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '删除购物车项失败'
    });
  }
};

/**
 * 清空购物车
 */
exports.clearCart = async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: '用户ID不能为空'
      });
    }

    const result = await cartService.clearCart(parseInt(userId));

    res.json({
      success: true,
      message: result.message
    });
  } catch (error) {
    logger.error('清空购物车失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '清空购物车失败'
    });
  }
};
