const couponService = require('../services/coupon.service');
const logger = require('../utils/logger');

/**
 * 获取用户优惠券列表
 */
exports.getUserCoupons = async (req, res) => {
  try {
    const { userId, type } = req.query;
    const coupons = await couponService.getUserCoupons(userId, type);

    res.json({
      success: true,
      data: coupons
    });
  } catch (error) {
    logger.error('获取优惠券列表失败', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取可领取的优惠券列表
 */
exports.getAvailableCoupons = async (req, res) => {
  try {
    const coupons = await couponService.getAvailableCoupons();

    res.json({
      success: true,
      data: coupons
    });
  } catch (error) {
    logger.error('获取可领取优惠券列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取可用优惠券（结算页使用）
 * Query: userId, orderAmount, restaurantId
 */
exports.getUsableCoupons = async (req, res) => {
  try {
    const { userId, orderAmount, restaurantId } = req.query;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: '缺少userId参数'
      });
    }

    const usable = await couponService.getUsableCoupons(
      userId,
      orderAmount ? parseFloat(orderAmount) : null,
      restaurantId || null
    );

    res.json({
      success: true,
      data: usable
    });
  } catch (error) {
    logger.error('获取可用优惠券失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 领取优惠券
 */
exports.claimCoupon = async (req, res) => {
  try {
    const { userId, couponId } = req.body;
    const result = await couponService.claimCoupon(userId, couponId);

    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('领取优惠券失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 使用优惠券
 */
exports.useCoupon = async (req, res) => {
  try {
    const { couponId } = req.params;
    const { orderId } = req.body;
    await couponService.useCoupon(couponId, orderId);

    res.json({
      success: true,
      message: '优惠券使用成功'
    });
  } catch (error) {
    logger.error('使用优惠券失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取用户红包余额
 */
exports.getRedPacket = async (req, res) => {
  try {
    const { userId } = req.query;
    const redPacket = await couponService.getRedPacket(userId);

    res.json({
      success: true,
      data: redPacket
    });
  } catch (error) {
    logger.error('获取红包余额失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

