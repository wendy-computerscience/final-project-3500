const orderService = require('../services/order.service');
const logger = require('../utils/logger');

/**
 * 创建订单
 */
exports.createOrder = async (req, res) => {
  try {
    const orderData = req.body;
    const result = await orderService.createOrder(orderData);

    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('创建订单失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取订单详情
 */
exports.getOrderDetail = async (req, res) => {
  try {
    const { orderId } = req.params;
    const order = await orderService.getOrderDetail(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: '订单不存在'
      });
    }

    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    logger.error('获取订单详情失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取用户订单列表
 */
exports.getUserOrders = async (req, res) => {
  try {
    const { userId } = req.params;
    const { status, page = 1, pageSize = 10 } = req.query;

    const result = await orderService.getUserOrders(userId, status, page, pageSize);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取订单列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 取消订单
 */
exports.cancelOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { cancelReason } = req.body;

    await orderService.cancelOrder(orderId, cancelReason);

    res.json({
      success: true,
      message: '订单已取消'
    });
  } catch (error) {
    logger.error('取消订单失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 支付订单
 */
exports.payOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { paymentMethod } = req.body;

    const result = await orderService.payOrder(orderId, paymentMethod);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('支付订单失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取订单状态徽章数量
 */
exports.getOrdersBadge = async (req, res) => {
  try {
    const { userId } = req.query;
    const result = await orderService.getOrdersBadge(userId);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取订单徽章数量失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 再来一单
 */
exports.reorderOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    const result = await orderService.reorderOrder(orderId);

    res.status(201).json({
      success: true,
      data: result,
      message: '新订单已创建'
    });
  } catch (error) {
    logger.error('再来一单失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 申请退款
 */
exports.refundOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { refundReason } = req.body;

    await orderService.refundOrder(orderId, refundReason);

    res.json({
      success: true,
      message: '退款申请已提交'
    });
  } catch (error) {
    logger.error('申请退款失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 删除订单（软删除）
 */
exports.deleteOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    await orderService.deleteOrder(orderId);

    res.json({
      success: true,
      message: '订单已删除'
    });
  } catch (error) {
    logger.error('删除订单失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
