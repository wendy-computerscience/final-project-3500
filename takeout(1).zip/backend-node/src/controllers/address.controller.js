const addressService = require('../services/address.service');
const logger = require('../utils/logger');

/**
 * 获取用户地址列表
 */
exports.getAddressList = async (req, res) => {
  try {
    const { userId } = req.query;
    const addresses = await addressService.getAddressList(userId);

    res.json({
      success: true,
      data: addresses
    });
  } catch (error) {
    logger.error('获取地址列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取地址详情
 */
exports.getAddressDetail = async (req, res) => {
  try {
    const { addressId } = req.params;
    const address = await addressService.getAddressDetail(addressId);

    if (!address) {
      return res.status(404).json({
        success: false,
        message: '地址不存在'
      });
    }

    res.json({
      success: true,
      data: address
    });
  } catch (error) {
    logger.error('获取地址详情失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 创建地址
 */
exports.createAddress = async (req, res) => {
  try {
    const addressData = req.body;
    const result = await addressService.createAddress(addressData);

    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('创建地址失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 更新地址
 */
exports.updateAddress = async (req, res) => {
  try {
    const { addressId } = req.params;
    const addressData = req.body;
    await addressService.updateAddress(addressId, addressData);

    res.json({
      success: true,
      message: '地址更新成功'
    });
  } catch (error) {
    logger.error('更新地址失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 删除地址
 */
exports.deleteAddress = async (req, res) => {
  try {
    const { addressId } = req.params;
    await addressService.deleteAddress(addressId);

    res.json({
      success: true,
      message: '地址删除成功'
    });
  } catch (error) {
    logger.error('删除地址失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 设置默认地址
 */
exports.setDefaultAddress = async (req, res) => {
  try {
    const { addressId } = req.params;
    const { userId } = req.body;
    await addressService.setDefaultAddress(userId, addressId);

    res.json({
      success: true,
      message: '默认地址设置成功'
    });
  } catch (error) {
    logger.error('设置默认地址失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
