const dashboardService = require('../services/dashboard.service');
const logger = require('../utils/logger');

/**
 * 获取仪表盘KPI数据
 */
exports.getDashboardKPIs = async (req, res) => {
  try {
    const kpis = await dashboardService.getDashboardKPIs();

    res.json({
      success: true,
      data: kpis
    });
  } catch (error) {
    logger.error('获取仪表盘KPI失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取订单趋势数据
 */
exports.getOrderTrend = async (req, res) => {
  try {
    const { days = 7 } = req.query;
    const trend = await dashboardService.getOrderTrend(parseInt(days));

    res.json({
      success: true,
      data: trend
    });
  } catch (error) {
    logger.error('获取订单趋势失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取收入统计
 */
exports.getRevenueStats = async (req, res) => {
  try {
    const { period = 'month' } = req.query; // month, week, today
    const stats = await dashboardService.getRevenueStats(period);

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    logger.error('获取收入统计失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
