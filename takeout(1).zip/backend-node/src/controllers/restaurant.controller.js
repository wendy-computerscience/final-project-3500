const restaurantService = require('../services/restaurant.service');
const logger = require('../utils/logger');

/**
 * 获取餐厅列表
 */
exports.getRestaurantList = async (req, res) => {
  try {
    const { category, latitude, longitude, page = 1, pageSize = 10 } = req.query;

    const result = await restaurantService.getRestaurantList({
      category,
      latitude: latitude ? parseFloat(latitude) : null,
      longitude: longitude ? parseFloat(longitude) : null,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
    });

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    logger.error('获取餐厅列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取餐厅列表失败',
    });
  }
};

/**
 * 获取餐厅详情
 */
exports.getRestaurantDetail = async (req, res) => {
  try {
    const { id } = req.params;

    const restaurant = await restaurantService.getRestaurantDetail(id);

    if (!restaurant) {
      return res.status(404).json({
        success: false,
        message: '餐厅不存在',
      });
    }

    res.json({
      success: true,
      data: restaurant,
    });
  } catch (error) {
    logger.error('获取餐厅详情失败:', error);
    res.status(500).json({
      success: false,
      message: '获取餐厅详情失败',
    });
  }
};

/**
 * 获取菜品列表失败
 */
exports.getRestaurantMenu = async (req, res) => {
  try {
    const { id } = req.params;

    const menu = await restaurantService.getRestaurantMenu(id);

    res.json({
      success: true,
      data: menu,
    });
  } catch (error) {
    logger.error('获取菜品列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取菜品列表失败',
    });
  }
};

/**
 * 获取所有食物列表（包含餐厅信息）
 * 用于首页展示
 */
exports.getAllFoods = async (req, res) => {
  try {
    const { page = 1, pageSize = 20, sortBy = 'sales' } = req.query;

    const result = await restaurantService.getAllFoods({
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      sortBy,
    });

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    logger.error('获取食物列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取食物列表失败',
    });
  }
};
