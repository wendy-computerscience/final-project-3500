const userService = require('../services/user.service');
const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

/**
 * 用户注册（手机号+验证码）
 */
exports.register = async (req, res) => {
  try {
    const { phone, code, nickname } = req.body;

    // 验证手机号
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      return res.status(400).json({
        success: false,
        message: '请输入正确的手机号',
      });
    }

    // 验证验证码
    if (!code) {
      return res.status(400).json({
        success: false,
        message: '验证码不能为空',
      });
    }

    // 开发环境：验证固定验证码 123456
    if (process.env.NODE_ENV === 'development') {
      if (code !== '123456') {
        return res.status(400).json({
          success: false,
          message: '验证码错误（开发环境固定为123456）',
        });
      }
    } else {
      // TODO: 生产环境验证Redis中的验证码
    }

    // 检查手机号是否已注册
    const existingUser = await userService.getUserByPhone(phone);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: '该手机号已注册，请直接登录',
      });
    }

    // 创建新用户
    const user = await userService.createUser({ phone, nickname });

    // 生成JWT Token
    const token = jwt.sign(
      { userId: user.id, phone: user.phone },
      process.env.JWT_SECRET || 'takeaway-secret-key',
      { expiresIn: '7d' }
    );

    // 更新最后登录时间
    await userService.updateLastLogin(user.id);

    logger.info(`用户注册成功: ${user.id}`);

    res.json({
      success: true,
      data: {
        token,
        user: {
          id: user.id,
          phone: user.phone,
          nickname: user.nickname || '新用户',
          avatar: null,
          points: 0,
        },
      },
    });
  } catch (error) {
    logger.error('用户注册失败:', error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

/**
 * 发送验证码
 */
exports.sendVerificationCode = async (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      return res.status(400).json({
        success: false,
        message: '请输入正确的手机号',
      });
    }

    const result = await userService.sendVerificationCode(phone);

    res.json({
      success: true,
      ...result,
    });
  } catch (error) {
    logger.error('发送验证码失败:', error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

/**
 * 用户登录（账号密码登录，不存在则自动注册）
 */
exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: '账号和密码不能为空',
      });
    }

    if (username.length < 3) {
      return res.status(400).json({
        success: false,
        message: '账号长度不能少于3位',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: '密码长度不能少于6位',
      });
    }

    // 查找用户
    let user = await userService.getUserByUsername(username);

    if (user) {
      // 用户存在，验证密码
      if (user.password !== password) {
        return res.status(401).json({
          success: false,
          message: '密码错误',
        });
      }
    } else {
      // 用户不存在，自动注册
      user = await userService.createUserWithPassword({ username, password });
      logger.info(`新用户自动注册: ${user.id}`);
    }

    // 生成JWT Token
    const token = jwt.sign(
      { userId: user.id, username: user.username },
      process.env.JWT_SECRET || 'takeaway-secret-key',
      { expiresIn: '7d' }
    );

    // 更新最后登录时间
    await userService.updateLastLogin(user.id);

    logger.info(`用户登录成功: ${user.id}`);

    res.json({
      success: true,
      data: {
        token,
        user: {
          id: user.id,
          username: user.username,
          nickname: user.nickname,
          avatar: user.avatar,
          points: user.points || 0,
        },
      },
    });
  } catch (error) {
    logger.error('用户登录失败:', error);
    res.status(401).json({
      success: false,
      message: error.message,
    });
  }
};

/**
 * 获取用户信息
 */
exports.getUserProfile = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await userService.getUserProfile(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }

    res.json({
      success: true,
      data: user
    });
  } catch (error) {
    logger.error('获取用户信息失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 更新用户信息
 */
exports.updateUserProfile = async (req, res) => {
  try {
    const { userId } = req.params;
    const userData = req.body;
    await userService.updateUserProfile(userId, userData);

    res.json({
      success: true,
      message: '用户信息更新成功'
    });
  } catch (error) {
    logger.error('更新用户信息失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
