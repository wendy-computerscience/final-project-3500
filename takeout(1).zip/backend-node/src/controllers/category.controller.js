const categoryService = require('../services/category.service');
const logger = require('../utils/logger');

/**
 * 获取商家的所有分类
 */
exports.getCategories = async (req, res) => {
  try {
    const { merchantId } = req.params;

    const categories = await categoryService.getCategories(merchantId);

    res.json({
      success: true,
      data: categories
    });
  } catch (error) {
    logger.error('获取分类列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '获取分类列表失败'
    });
  }
};

/**
 * 创建新分类
 */
exports.createCategory = async (req, res) => {
  try {
    const { merchantId } = req.params;
    const { name, sort_order } = req.body;

    // 参数验证
    if (!name || name.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: '分类名称不能为空'
      });
    }

    const category = await categoryService.createCategory(merchantId, {
      name,
      sort_order
    });

    res.status(201).json({
      success: true,
      data: category,
      message: '分类创建成功'
    });
  } catch (error) {
    logger.error('创建分类失败:', error);

    // 处理重复名称错误
    if (error.message.includes('已存在')) {
      return res.status(409).json({
        success: false,
        message: error.message
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || '创建分类失败'
    });
  }
};

/**
 * 更新分类
 */
exports.updateCategory = async (req, res) => {
  try {
    const { merchantId, categoryId } = req.params;
    const { name, sort_order } = req.body;

    // 参数验证
    if (!name && sort_order === undefined) {
      return res.status(400).json({
        success: false,
        message: '请提供要更新的字段'
      });
    }

    const category = await categoryService.updateCategory(
      merchantId,
      categoryId,
      { name, sort_order }
    );

    res.json({
      success: true,
      data: category,
      message: '分类更新成功'
    });
  } catch (error) {
    logger.error('更新分类失败:', error);

    if (error.message === '分类不存在') {
      return res.status(404).json({
        success: false,
        message: error.message
      });
    }

    if (error.message.includes('已存在')) {
      return res.status(409).json({
        success: false,
        message: error.message
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || '更新分类失败'
    });
  }
};

/**
 * 删除分类
 */
exports.deleteCategory = async (req, res) => {
  try {
    const { merchantId, categoryId } = req.params;

    const result = await categoryService.deleteCategory(merchantId, categoryId);

    res.json({
      success: true,
      message: result.message
    });
  } catch (error) {
    logger.error('删除分类失败:', error);

    if (error.message === '分类不存在') {
      return res.status(404).json({
        success: false,
        message: error.message
      });
    }

    // 处理分类下有菜品的情况
    if (error.message.includes('还有')) {
      return res.status(409).json({
        success: false,
        message: error.message
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || '删除分类失败'
    });
  }
};

/**
 * 批量更新分类排序
 */
exports.updateCategoriesSort = async (req, res) => {
  try {
    const { merchantId } = req.params;
    const { categories } = req.body;

    // 参数验证
    if (!Array.isArray(categories) || categories.length === 0) {
      return res.status(400).json({
        success: false,
        message: '排序数据格式错误'
      });
    }

    const result = await categoryService.updateCategoriesSort(merchantId, categories);

    res.json({
      success: true,
      message: result.message
    });
  } catch (error) {
    logger.error('更新分类排序失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '更新分类排序失败'
    });
  }
};
