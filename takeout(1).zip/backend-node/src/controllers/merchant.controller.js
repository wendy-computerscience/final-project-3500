const merchantService = require('../services/merchant.service');
const logger = require('../utils/logger');

/**
 * 商家登录（账号密码登录）
 */
exports.merchantLogin = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: '账号和密码不能为空'
      });
    }

    const result = await merchantService.merchantLogin(username, password);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('商家登录失败:', error);
    res.status(401).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 商家注册（即时注册）
 */
exports.merchantRegister = async (req, res) => {
  try {
    const registrationData = req.body;

    // 验证必填字段
    const { username, password, business_name, contact_phone } = registrationData;

    if (!username || !password || !business_name || !contact_phone) {
      return res.status(400).json({
        success: false,
        message: '缺少必要的注册信息'
      });
    }

    const result = await merchantService.merchantRegister(registrationData);

    res.status(201).json({
      success: true,
      message: '注册成功，请登录',
      data: result
    });
  } catch (error) {
    logger.error('商家注册失败:', error);

    // 处理重复用户名/手机号错误
    if (error.message.includes('已被注册') || error.message.includes('已注册')) {
      return res.status(409).json({
        success: false,
        message: error.message
      });
    }

    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取商家详情
 */
exports.getMerchantDetail = async (req, res) => {
  try {
    const { merchantId } = req.params;
    console.log('============ getMerchantDetail called ============');
    console.log('merchantId:', merchantId);
    console.log('req.path:', req.path);
    console.log('req.url:', req.url);

    const merchant = await merchantService.getMerchantDetail(merchantId);

    if (!merchant) {
      console.log('商家不存在');
      return res.status(404).json({
        success: false,
        message: '商家不存在'
      });
    }

    console.log('返回商家信息:', merchant);
    res.json({
      success: true,
      data: merchant
    });
  } catch (error) {
    logger.error('获取商家详情失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 更新商家信息
 */
exports.updateMerchant = async (req, res) => {
  try {
    const { merchantId } = req.params;
    const merchantData = req.body;
    await merchantService.updateMerchant(merchantId, merchantData);

    res.json({
      success: true,
      message: '商家信息更新成功'
    });
  } catch (error) {
    logger.error('更新商家信息失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取商家菜品列表
 */
exports.getMerchantDishes = async (req, res) => {
  try {
    const { merchantId } = req.params;
    const { category, status } = req.query;
    const dishes = await merchantService.getMerchantDishes(merchantId, category, status);

    res.json({
      success: true,
      data: dishes
    });
  } catch (error) {
    logger.error('获取商家菜品列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 添加菜品
 */
exports.addDish = async (req, res) => {
  try {
    const { merchantId } = req.params;
    const dishData = req.body;
    const result = await merchantService.addDish(merchantId, dishData);

    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('添加菜品失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 更新菜品
 */
exports.updateDish = async (req, res) => {
  try {
    const { merchantId, dishId } = req.params;
    const dishData = req.body;
    await merchantService.updateDish(merchantId, dishId, dishData);

    res.json({
      success: true,
      message: '菜品更新成功'
    });
  } catch (error) {
    logger.error('更新菜品失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 删除菜品
 */
exports.deleteDish = async (req, res) => {
  try {
    const { merchantId, dishId } = req.params;
    await merchantService.deleteDish(merchantId, dishId);

    res.json({
      success: true,
      message: '菜品删除成功'
    });
  } catch (error) {
    logger.error('删除菜品失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 上架/下架菜品
 */
exports.toggleDishStatus = async (req, res) => {
  try {
    const { merchantId, dishId } = req.params;
    const { status } = req.body;
    await merchantService.toggleDishStatus(merchantId, dishId, status);

    res.json({
      success: true,
      message: status === 'available' ? '菜品已上架' : '菜品已下架'
    });
  } catch (error) {
    logger.error('切换菜品状态失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取商家订单列表
 */
exports.getMerchantOrders = async (req, res) => {
  try {
    const { merchantId } = req.params;
    const { status, page = 1, pageSize = 10 } = req.query;
    const result = await merchantService.getMerchantOrders(merchantId, status, page, pageSize);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取商家订单列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取申请状态
 */
exports.getApplicationStatus = async (req, res) => {
  try {
    const { merchantId } = req.params;

    if (!merchantId) {
      return res.status(400).json({
        success: false,
        message: '缺少商家ID'
      });
    }

    const result = await merchantService.getApplicationStatus(merchantId);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取申请状态失败:', error);
    res.status(404).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 接受订单
 */
exports.acceptOrder = async (req, res) => {
  try {
    const { merchantId, orderId } = req.params;

    const result = await merchantService.acceptOrder(merchantId, orderId);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('接受订单失败:', error);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 拒绝订单
 */
exports.rejectOrder = async (req, res) => {
  try {
    const { merchantId, orderId } = req.params;
    const { reason } = req.body;

    const result = await merchantService.rejectOrder(merchantId, orderId, reason);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('拒绝订单失败:', error);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 完成备餐
 */
exports.completePreparation = async (req, res) => {
  try {
    const { merchantId, orderId } = req.params;

    const result = await merchantService.completePreparation(merchantId, orderId);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('完成备餐失败:', error);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 确认骑手取餐
 */
exports.confirmPickup = async (req, res) => {
  try {
    const { merchantId, orderId } = req.params;

    const result = await merchantService.confirmPickup(merchantId, orderId);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('确认取餐失败:', error);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取每日统计数据
 */
exports.getDailyStatistics = async (req, res) => {
  try {
    const { merchantId } = req.params;
    const { date } = req.query;

    const dateParam = date || new Date().toISOString().split('T')[0];
    const result = await merchantService.getDailyStatistics(merchantId, dateParam);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取统计数据失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取热销菜品
 */
exports.getHotDishes = async (req, res) => {
  try {
    const { merchantId } = req.params;
    const { timeRange = 'week', limit = 10 } = req.query;

    const result = await merchantService.getHotDishes(merchantId, timeRange, limit);

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('获取热销菜品失败:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
