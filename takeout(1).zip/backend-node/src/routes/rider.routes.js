const express = require('express');
const router = express.Router();
const riderController = require('../controllers/rider.controller');

// 骑手认证相关
router.post('/login', riderController.riderLogin); // 骑手登录（账号密码登录）
router.post('/logout', riderController.riderLogout); // 骑手退出登录
router.post('/auth', riderController.submitRiderAuth); // 提交认证信息
router.get('/auth/status', riderController.getRiderAuthStatus); // 获取认证状态
router.post('/register', riderController.registerRider); // 骑手注册

// 骑手订单相关
router.get('/orders/available', riderController.getAvailableOrders); // 获取可接订单列表
router.post('/orders/:orderId/accept', riderController.acceptOrder); // 接单
router.put('/orders/:orderId/pickup', riderController.confirmPickup); // 确认取餐
router.put('/orders/:orderId/deliver', riderController.confirmDelivery); // 确认送达
router.get('/orders', riderController.getRiderOrders); // 获取订单列表
router.get('/orders/:orderId', riderController.getRiderOrderDetail); // 获取订单详情

// 骑手排行榜和任务
router.get('/ranking', riderController.getRiderRanking); // 获取排行榜
router.get('/tasks', riderController.getRiderTasks); // 获取任务列表
router.post('/tasks/:taskId/claim', riderController.claimTaskReward); // 领取任务奖励

// 骑手收入和提现
router.get('/income', riderController.getRiderIncome); // 获取收入统计
router.post('/withdraw', riderController.createWithdrawal); // 创建提现申请
router.get('/withdraw/records', riderController.getWithdrawalRecords); // 获取提现记录

module.exports = router;
