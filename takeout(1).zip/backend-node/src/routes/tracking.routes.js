const express = require('express');
const router = express.Router();
const trackingService = require('../services/tracking.service');

/**
 * GET /api/track/:orderId
 * 获取订单追踪信息
 */
router.get('/:orderId', async (req, res) => {
  try {
    const { orderId } = req.params;

    const trackingInfo = await trackingService.getTrackingInfo(orderId);

    res.json({
      success: true,
      data: trackingInfo
    });
  } catch (error) {
    console.error('获取追踪信息失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * POST /api/track/:orderId
 * 更新骑手位置（骑手端/模拟器调用）
 */
router.post('/:orderId', (req, res) => {
  try {
    const { orderId } = req.params;
    const { courierId, lat, lng, ts } = req.body;

    if (!courierId || !lat || !lng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const result = trackingService.updateCourierLocation(
      orderId,
      courierId,
      parseFloat(lat),
      parseFloat(lng)
    );

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error('更新位置失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * GET /api/track/:orderId/route
 * 获取订单配送路径
 */
router.get('/:orderId/route', (req, res) => {
  try {
    const { orderId } = req.params;

    const route = trackingService.getOrderRoute(orderId);

    if (!route) {
      return res.status(404).json({
        success: false,
        message: '路径不存在'
      });
    }

    res.json({
      success: true,
      data: route
    });
  } catch (error) {
    console.error('获取路径失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

module.exports = router;
