const express = require('express');
const router = express.Router();
const dispatchService = require('../services/dispatch.service');

/**
 * POST /api/dispatch/assign
 * 智能派单 - 自动分配最优骑手
 */
router.post('/assign', async (req, res) => {
  try {
    const { orderId, restaurantLat, restaurantLng, userLat, userLng } = req.body;

    if (!orderId || !restaurantLat || !restaurantLng || !userLat || !userLng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const result = await dispatchService.assignOrder({
      orderId,
      restaurantLat: parseFloat(restaurantLat),
      restaurantLng: parseFloat(restaurantLng),
      userLat: parseFloat(userLat),
      userLng: parseFloat(userLng)
    });

    res.json(result);
  } catch (error) {
    console.error('派单失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * GET /api/dispatch/recommended-orders
 * 获取骑手推荐订单列表
 * Query params:
 *   - courierId: 骑手ID
 *   - lat: 骑手纬度
 *   - lng: 骑手经度
 *   - sortBy: 排序方式 (distance/income/smart)
 */
router.get('/recommended-orders', async (req, res) => {
  try {
    const { courierId, lat, lng, sortBy = 'smart' } = req.query;

    if (!courierId || !lat || !lng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const orders = await dispatchService.getRecommendedOrders(
      courierId,
      parseFloat(lat),
      parseFloat(lng),
      sortBy
    );

    res.json({
      success: true,
      data: orders
    });
  } catch (error) {
    console.error('获取推荐订单失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * GET /api/dispatch/predictive-notification
 * 获取预测性派单通知
 */
router.get('/predictive-notification', async (req, res) => {
  try {
    const { courierId, lat, lng } = req.query;

    if (!courierId || !lat || !lng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const notification = await dispatchService.getPredictiveNotification(
      courierId,
      parseFloat(lat),
      parseFloat(lng)
    );

    res.json({
      success: true,
      data: notification
    });
  } catch (error) {
    console.error('获取预测通知失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

module.exports = router;
