const express = require('express');
const router = express.Router();
const orderController = require('../controllers/order.controller');
const deliveryFeeService = require('../services/deliveryFee.service');

// 订单相关路由
router.post('/', orderController.createOrder);
router.get('/:orderId', orderController.getOrderDetail);
router.get('/user/:userId', orderController.getUserOrders);
router.put('/:orderId/cancel', orderController.cancelOrder);
router.put('/:orderId/pay', orderController.payOrder);

// 新增接口
router.get('/badge/count', orderController.getOrdersBadge); // 获取订单徽章数量
router.post('/:orderId/reorder', orderController.reorderOrder); // 再来一单
router.post('/:orderId/refund', orderController.refundOrder); // 申请退款
router.delete('/:orderId', orderController.deleteOrder); // 删除订单（软删除）


/**
 * POST /api/orders/calculate-delivery-fee
 * 计算动态配送费
 * Body参数：
 * - restaurantLat: 餐厅纬度
 * - restaurantLng: 餐厅经度
 * - userLat: 用户纬度
 * - userLng: 用户经度
 * - baseFee: 基础配送费（可选）
 */
router.post('/calculate-delivery-fee', (req, res) => {
  try {
    const { restaurantLat, restaurantLng, userLat, userLng, baseFee } = req.body;

    // 参数验证
    if (!restaurantLat || !restaurantLng || !userLat || !userLng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    // 计算配送费
    const result = deliveryFeeService.calculateDeliveryFee({
      restaurantLat: parseFloat(restaurantLat),
      restaurantLng: parseFloat(restaurantLng),
      userLat: parseFloat(userLat),
      userLng: parseFloat(userLng),
      baseFee: baseFee ? parseFloat(baseFee) : undefined
    });

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error('计算配送费失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

module.exports = router;
