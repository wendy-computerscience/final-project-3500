const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cart.controller');

/**
 * 获取用户购物车
 * GET /api/cart/:userId
 */
router.get('/:userId', cartController.getUserCart);

/**
 * 添加商品到购物车
 * POST /api/cart
 * Body: { userId, restaurantId, menuItemId, quantity }
 */
router.post('/', cartController.addToCart);

/**
 * 更新购物车项数量
 * PUT /api/cart/:itemId
 * Body: { quantity, userId }
 */
router.put('/:itemId', cartController.updateCartItem);

/**
 * 删除购物车项
 * DELETE /api/cart/:itemId
 * Body: { userId }
 */
router.delete('/:itemId', cartController.removeCartItem);

/**
 * 清空购物车
 * DELETE /api/cart/:userId/clear
 */
router.delete('/:userId/clear', cartController.clearCart);

module.exports = router;
