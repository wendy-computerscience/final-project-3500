const express = require('express');
const router = express.Router();
const suggestionService = require('../services/suggestion.service');
const logger = require('../utils/logger');

/**
 * 获取凑单建议
 * GET /api/suggestion/:restaurantId
 * Query: currentAmount, cartItems (可选，逗号分隔的菜品ID)
 */
router.get('/:restaurantId', async (req, res) => {
  try {
    const { restaurantId } = req.params;
    const { currentAmount, cartItems } = req.query;

    // 参数验证
    if (!currentAmount || isNaN(parseFloat(currentAmount))) {
      return res.status(400).json({
        success: false,
        message: '请提供有效的购物车金额'
      });
    }

    const amount = parseFloat(currentAmount);
    const cartItemIds = cartItems ? cartItems.split(',') : [];

    // 获取凑单建议
    const result = await suggestionService.getSuggestions(restaurantId, amount, cartItemIds);

    logger.info(`凑单建议查询成功: ${restaurantId}, 金额: ${amount}`);

    res.json({
      success: true,
      data: result
    });

  } catch (error) {
    logger.error('获取凑单建议失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '获取凑单建议失败'
    });
  }
});

/**
 * 获取组合建议
 * GET /api/suggestion/:restaurantId/combinations
 * Query: currentAmount, cartItems (可选)
 */
router.get('/:restaurantId/combinations', async (req, res) => {
  try {
    const { restaurantId } = req.params;
    const { currentAmount, cartItems } = req.query;

    if (!currentAmount || isNaN(parseFloat(currentAmount))) {
      return res.status(400).json({
        success: false,
        message: '请提供有效的购物车金额'
      });
    }

    const amount = parseFloat(currentAmount);
    const cartItemIds = cartItems ? cartItems.split(',') : [];

    const combinations = await suggestionService.getCombinationSuggestions(
      restaurantId,
      amount,
      cartItemIds
    );

    res.json({
      success: true,
      data: combinations
    });

  } catch (error) {
    logger.error('获取组合建议失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '获取组合建议失败'
    });
  }
});

module.exports = router;
