const express = require('express');
const router = express.Router();
const routeOptimizationService = require('../services/routeOptimization.service');

/**
 * POST /api/route/optimize
 * 优化多订单配送路径
 */
router.post('/optimize', (req, res) => {
  try {
    const { orders, courierLat, courierLng } = req.body;

    if (!orders || !courierLat || !courierLng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const result = routeOptimizationService.optimizeRoute({
      orders,
      courierLat: parseFloat(courierLat),
      courierLng: parseFloat(courierLng)
    });

    res.json(result);
  } catch (error) {
    console.error('路径优化失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * POST /api/route/visualization
 * 获取路径可视化数据
 */
router.post('/visualization', (req, res) => {
  try {
    const { optimizedRoute, courierLat, courierLng } = req.body;

    if (!optimizedRoute || !courierLat || !courierLng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const visualization = routeOptimizationService.getRouteVisualization(
      optimizedRoute,
      parseFloat(courierLat),
      parseFloat(courierLng)
    );

    res.json({
      success: true,
      data: visualization
    });
  } catch (error) {
    console.error('获取可视化数据失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * POST /api/route/adjust
 * 实时路径调整
 */
router.post('/adjust', (req, res) => {
  try {
    const {
      currentSequence,
      completedPoints,
      courierLat,
      courierLng,
      newOrders
    } = req.body;

    if (!currentSequence || !completedPoints || !courierLat || !courierLng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const result = routeOptimizationService.adjustRoute({
      currentSequence,
      completedPoints,
      courierLat: parseFloat(courierLat),
      courierLng: parseFloat(courierLng),
      newOrders: newOrders || []
    });

    res.json(result);
  } catch (error) {
    console.error('路径调整失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

module.exports = router;
