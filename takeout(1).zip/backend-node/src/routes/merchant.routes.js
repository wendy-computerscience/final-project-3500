const express = require('express');
const router = express.Router();
const merchantController = require('../controllers/merchant.controller');
const categoryController = require('../controllers/category.controller');

// 调试中间件
router.use((req, res, next) => {
  console.log('============ Merchant Routes ============');
  console.log('Method:', req.method);
  console.log('Path:', req.path);
  console.log('URL:', req.url);
  console.log('Params:', req.params);
  next();
});

// 商家认证相关
router.post('/login', merchantController.merchantLogin); // 商家登录
router.post('/register', merchantController.merchantRegister); // 商家入驻申请

// 注意：更具体的路由要放在通用路由前面

// 获取申请状态 (before /:merchantId)
router.get('/application/:merchantId', merchantController.getApplicationStatus);

// 菜品管理 (before /:merchantId)
router.get('/:merchantId/dishes', merchantController.getMerchantDishes); // 获取商家菜品列表
router.post('/:merchantId/dishes', merchantController.addDish); // 添加菜品
router.put('/:merchantId/dishes/:dishId/status', merchantController.toggleDishStatus); // 上架/下架菜品 (before update)
router.put('/:merchantId/dishes/:dishId', merchantController.updateDish); // 更新菜品
router.delete('/:merchantId/dishes/:dishId', merchantController.deleteDish); // 删除菜品

// 分类管理 (before /:merchantId)
router.get('/:merchantId/categories', categoryController.getCategories); // 获取分类列表
router.post('/:merchantId/categories', categoryController.createCategory); // 创建分类
router.put('/:merchantId/categories/sort', categoryController.updateCategoriesSort); // 批量更新排序 (before update)
router.put('/:merchantId/categories/:categoryId', categoryController.updateCategory); // 更新分类
router.delete('/:merchantId/categories/:categoryId', categoryController.deleteCategory); // 删除分类

// 订单管理 (before /:merchantId)
router.get('/:merchantId/orders', merchantController.getMerchantOrders); // 获取商家订单列表
router.post('/:merchantId/orders/:orderId/accept', merchantController.acceptOrder); // 接受订单
router.post('/:merchantId/orders/:orderId/reject', merchantController.rejectOrder); // 拒绝订单
router.post('/:merchantId/orders/:orderId/complete-prep', merchantController.completePreparation); // 完成备餐
router.post('/:merchantId/orders/:orderId/confirm-pickup', merchantController.confirmPickup); // 确认取餐

// 统计数据 (before /:merchantId)
router.get('/:merchantId/statistics/daily', merchantController.getDailyStatistics); // 获取每日统计
router.get('/:merchantId/statistics/hot-dishes', merchantController.getHotDishes); // 获取热销菜品

// 商家信息管理 (PUT before GET to avoid conflicts)
router.put('/:merchantId', merchantController.updateMerchant); // 更新商家信息
router.get('/:merchantId', merchantController.getMerchantDetail); // 获取商家详情

module.exports = router;
