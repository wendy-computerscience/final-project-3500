const express = require('express');
const router = express.Router();
const recommendationService = require('../services/recommendation.service');

/**
 * GET /api/reco/home
 * 获取首页个性化推荐
 * Query参数：
 * - userId: 用户ID
 * - lat: 用户纬度
 * - lng: 用户经度
 * - limit: 返回数量（默认8）
 */
router.get('/home', async (req, res) => {
  try {
    const { userId, lat, lng, limit = 8 } = req.query;

    // 参数验证
    if (!lat || !lng) {
      return res.status(400).json({
        success: false,
        message: '缺少位置参数'
      });
    }

    const userLat = parseFloat(lat);
    const userLng = parseFloat(lng);

    if (isNaN(userLat) || isNaN(userLng)) {
      return res.status(400).json({
        success: false,
        message: '位置参数格式错误'
      });
    }

    // 获取推荐
    const recommendations = await recommendationService.getHomeRecommendations(
      userId,
      userLat,
      userLng,
      parseInt(limit)
    );

    res.json({
      success: true,
      data: recommendations
    });
  } catch (error) {
    console.error('获取推荐失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * GET /api/reco/alternatives
 * 获取替代推荐（结算页）
 * Query参数：
 * - orderId: 订单ID
 * - restaurantId: 当前餐厅ID
 * - lat: 用户纬度
 * - lng: 用户经度
 */
router.get('/alternatives', async (req, res) => {
  try {
    const { orderId, restaurantId, lat, lng } = req.query;

    if (!restaurantId || !lat || !lng) {
      return res.status(400).json({
        success: false,
        message: '缺少必要参数'
      });
    }

    const userLat = parseFloat(lat);
    const userLng = parseFloat(lng);

    const alternatives = await recommendationService.getAlternatives(
      orderId,
      userLat,
      userLng,
      restaurantId
    );

    res.json({
      success: true,
      data: alternatives
    });
  } catch (error) {
    console.error('获取替代推荐失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

module.exports = router;
