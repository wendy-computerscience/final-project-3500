const express = require('express');
const router = express.Router();
const restaurantController = require('../controllers/restaurant.controller');

/**
 * 获取所有食物列表（包含餐厅信息）
 * GET /api/restaurants/foods
 * Query参数：
 * - page: 页码（默认1）
 * - pageSize: 每页数量（默认20）
 * - sortBy: 排序方式（sales/price_asc/price_desc/rating，默认sales）
 */
router.get('/foods', restaurantController.getAllFoods);

/**
 * 获取所有餐厅列表
 * GET /api/restaurants
 * Query参数：
 * - category: 分类（可选）
 * - latitude: 用户纬度（可选）
 * - longitude: 用户经度（可选）
 * - page: 页码（默认1）
 * - pageSize: 每页数量（默认10）
 */
router.get('/', restaurantController.getRestaurantList);

/**
 * 获取单个餐厅详情
 * GET /api/restaurants/:id
 */
router.get('/:id', restaurantController.getRestaurantDetail);

/**
 * 获取餐厅菜品
 * GET /api/restaurants/:id/menu
 */
router.get('/:id/menu', restaurantController.getRestaurantMenu);

module.exports = router;
