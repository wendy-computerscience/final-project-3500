const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboard.controller');

// 仪表盘数据路由
router.get('/kpis', dashboardController.getDashboardKPIs); // 获取KPI数据
router.get('/order-trend', dashboardController.getOrderTrend); // 获取订单趋势
router.get('/revenue', dashboardController.getRevenueStats); // 获取收入统计

module.exports = router;
