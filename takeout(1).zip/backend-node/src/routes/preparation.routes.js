const express = require('express');
const router = express.Router();
const preparationService = require('../services/preparation.service');

/**
 * GET /api/preparation/kanban
 * 获取订单看板数据
 */
router.get('/kanban', (req, res) => {
  try {
    const { merchantId = 'm_001' } = req.query;

    const kanban = preparationService.getKanbanOrders(merchantId);

    res.json({
      success: true,
      data: kanban
    });
  } catch (error) {
    console.error('获取看板数据失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * PUT /api/preparation/order/:orderId/status
 * 更新订单状态
 */
router.put('/order/:orderId/status', (req, res) => {
  try {
    const { orderId } = req.params;
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({
        success: false,
        message: '缺少状态参数'
      });
    }

    const result = preparationService.updateOrderStatus(orderId, status);

    res.json(result);
  } catch (error) {
    console.error('更新订单状态失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * POST /api/preparation/batch-update
 * 批量更新订单状态
 */
router.post('/batch-update', (req, res) => {
  try {
    const { updates } = req.body;

    if (!updates || !Array.isArray(updates)) {
      return res.status(400).json({
        success: false,
        message: '缺少更新数据'
      });
    }

    const result = preparationService.batchUpdateStatus(updates);

    res.json(result);
  } catch (error) {
    console.error('批量更新失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * GET /api/preparation/statistics
 * 获取出餐统计数据
 */
router.get('/statistics', (req, res) => {
  try {
    const { merchantId = 'm_001', timeRange = 'today' } = req.query;

    const stats = preparationService.getStatistics(merchantId, timeRange);

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('获取统计数据失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * GET /api/preparation/bottleneck
 * 获取瓶颈分析
 */
router.get('/bottleneck', (req, res) => {
  try {
    const { merchantId = 'm_001' } = req.query;

    const analysis = preparationService.getBottleneckAnalysis(merchantId);

    res.json({
      success: true,
      data: analysis
    });
  } catch (error) {
    console.error('瓶颈分析失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * PUT /api/preparation/order/:orderId/priority
 * 设置订单优先级
 */
router.put('/order/:orderId/priority', (req, res) => {
  try {
    const { orderId } = req.params;
    const { priority } = req.body;

    if (!priority) {
      return res.status(400).json({
        success: false,
        message: '缺少优先级参数'
      });
    }

    const result = preparationService.setOrderPriority(orderId, priority);

    res.json(result);
  } catch (error) {
    console.error('设置优先级失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * PUT /api/preparation/order/:orderId/notes
 * 添加订单备注
 */
router.put('/order/:orderId/notes', (req, res) => {
  try {
    const { orderId } = req.params;
    const { notes } = req.body;

    const result = preparationService.addOrderNotes(orderId, notes || '');

    res.json(result);
  } catch (error) {
    console.error('添加备注失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

/**
 * GET /api/preparation/order/:orderId
 * 获取订单详情
 */
router.get('/order/:orderId', (req, res) => {
  try {
    const { orderId } = req.params;

    const result = preparationService.getOrderDetail(orderId);

    res.json(result);
  } catch (error) {
    console.error('获取订单详情失败:', error);
    res.status(500).json({
      success: false,
      message: '服务器错误',
      error: error.message
    });
  }
});

module.exports = router;
