const express = require('express');
const router = express.Router();
const addressController = require('../controllers/address.controller');

// 地址管理路由
router.get('/', addressController.getAddressList); // 获取地址列表
router.get('/:addressId', addressController.getAddressDetail); // 获取地址详情
router.post('/', addressController.createAddress); // 创建地址
router.put('/:addressId', addressController.updateAddress); // 更新地址
router.delete('/:addressId', addressController.deleteAddress); // 删除地址
router.post('/:addressId/default', addressController.setDefaultAddress); // 设置默认地址

module.exports = router;
