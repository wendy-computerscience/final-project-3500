const express = require('express');
const router = express.Router();
const couponController = require('../controllers/coupon.controller');

// 优惠券管理路由
router.get('/', couponController.getUserCoupons); // 获取用户优惠券列表
router.get('/available', couponController.getAvailableCoupons); // 获取可领取的优惠券列表
router.get('/usable', couponController.getUsableCoupons); // 获取可用优惠券（结算页）
router.post('/', couponController.claimCoupon); // 领取优惠券
router.put('/:couponId/use', couponController.useCoupon); // 使用优惠券

// 红包相关路由
router.get('/red-packet', couponController.getRedPacket); // 获取红包余额

module.exports = router;

