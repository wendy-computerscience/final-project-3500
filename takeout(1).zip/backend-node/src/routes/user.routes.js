const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');

// 用户认证相关
router.post('/register', userController.register); // 用户注册
router.post('/login', userController.login); // 用户登录
router.post('/send-code', userController.sendVerificationCode); // 发送验证码

// 用户信息相关
router.get('/:userId/profile', userController.getUserProfile); // 获取用户信息
router.put('/:userId/profile', userController.updateUserProfile); // 更新用户信息

module.exports = router;
