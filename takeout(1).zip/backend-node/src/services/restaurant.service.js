const db = require('../config/database');
const logger = require('../utils/logger');

/**
 * 获取餐厅列表
 */
exports.getRestaurantList = async (params) => {
  const { category, latitude, longitude, page = 1, pageSize = 10 } = params;

  let query = 'SELECT * FROM restaurants WHERE status = 1';
  const queryParams = [];

  // 按分类筛选
  if (category) {
    query += ' AND category = ?';
    queryParams.push(category);
  }

  // TODO: 如果有位置，可以计算距离并排序
  // 暂时按评分排序
  query += ' ORDER BY rating DESC, total_sales DESC';

  // 分页 - 确保参数为有效数字且为整数
  const limit = Math.max(1, parseInt(pageSize) || 10);
  const pageNum = Math.max(1, parseInt(page) || 1);
  const offset = (pageNum - 1) * limit;

  // 调试日志
  logger.info(`准备执行SQL查询，分页参数: page=${pageNum}, pageSize=${limit}, offset=${offset}`);

  // 使用字符串拼接代替参数绑定（避免 mysql2 参数绑定的 LIMIT 问题）
  query += ` LIMIT ${offset}, ${limit}`;

  logger.info(`最终SQL: ${query}`);
  logger.info(`SQL参数: ${JSON.stringify(queryParams)}`);

  const [rows] = await db.execute(query, queryParams);

  // 获取总数
  let countQuery = 'SELECT COUNT(*) as total FROM restaurants WHERE status = 1';
  const countParams = [];

  if (category) {
    countQuery += ' AND category = ?';
    countParams.push(category);
  }

  const [countRows] = await db.execute(countQuery, countParams);

  // 转换数据格式（兼容前端）
  const restaurants = rows.map((row) => ({
    id: row.id.toString(),
    name: row.name,
    logo: row.logo,
    cuisine: JSON.parse(row.tags || '[]'),
    rating: parseFloat(row.rating),
    distance: 1.2, // TODO: 根据用户位置计算实际距离
    avgPrepMin: row.avg_delivery_time,
    minOrder: parseFloat(row.min_order_amount),
    deliveryFee: parseFloat(row.delivery_fee),
    address: row.address,
    lat: parseFloat(row.latitude),
    lng: parseFloat(row.longitude),
    onTimeRate: 0.95, // TODO: 从订单统计计算
    phone: row.phone,
  }));

  return {
    restaurants,
    total: countRows[0].total,
    page: parseInt(page),
    pageSize: parseInt(pageSize),
  };
};

/**
 * 获取餐厅详情
 */
exports.getRestaurantDetail = async (restaurantId) => {
  const [rows] = await db.execute(
    'SELECT * FROM restaurants WHERE id = ? AND status = 1',
    [restaurantId]
  );

  if (rows.length === 0) {
    return null;
  }

  const row = rows[0];

  return {
    id: row.id.toString(),
    merchantId: row.merchant_id,
    name: row.name,
    logo: row.logo,
    cuisine: JSON.parse(row.tags || '[]'),
    rating: parseFloat(row.rating),
    avgPrepMin: row.avg_delivery_time,
    minOrder: parseFloat(row.min_order_amount),
    deliveryFee: parseFloat(row.delivery_fee),
    address: row.address,
    lat: parseFloat(row.latitude),
    lng: parseFloat(row.longitude),
    onTimeRate: 0.95, // TODO: 从订单统计计算
    phone: row.phone,
    businessHours: row.business_hours,
    isOpen: row.is_open === 1,
  };
};

/**
 * 获取餐厅菜品列表
 */
exports.getRestaurantMenu = async (restaurantId) => {
  const [rows] = await db.execute(
    `SELECT * FROM menu_items
     WHERE restaurant_id = ? AND is_available = 1
     ORDER BY category_id, sort_order, sales DESC`,
    [restaurantId]
  );

  return rows.map((row) => ({
    id: row.id.toString(),
    restaurantId: row.restaurant_id.toString(),
    name: row.name,
    description: row.description,
    price: parseFloat(row.price),
    originalPrice: row.original_price ? parseFloat(row.original_price) : null,
    monthSales: row.sales,
    rating: 4.5, // TODO: 从订单评价计算
    image: row.image,
    tags: [], // TODO: 如果需要可以添加tags字段
  }));
};

/**
 * 获取所有食物列表（包含餐厅信息）
 * 用于首页展示
 */
exports.getAllFoods = async (params = {}) => {
  const { page = 1, pageSize = 20, sortBy = 'sales' } = params;

  const limit = Math.max(1, parseInt(pageSize) || 20);
  const pageNum = Math.max(1, parseInt(page) || 1);
  const offset = (pageNum - 1) * limit;

  // 根据排序方式设置ORDER BY
  let orderBy = 'm.sales DESC';
  if (sortBy === 'price_asc') {
    orderBy = 'm.price ASC';
  } else if (sortBy === 'price_desc') {
    orderBy = 'm.price DESC';
  } else if (sortBy === 'rating') {
    orderBy = 'r.rating DESC, m.sales DESC';
  }

  // 查询食物列表，JOIN餐厅表获取餐厅信息
  const query = `
    SELECT
      m.id,
      m.restaurant_id,
      m.name,
      m.description,
      m.price,
      m.original_price,
      m.image,
      m.sales,
      m.is_available,
      r.id as r_id,
      r.name as restaurant_name,
      r.logo as restaurant_logo,
      r.rating as restaurant_rating,
      r.delivery_fee as restaurant_delivery_fee,
      r.avg_delivery_time as restaurant_avg_delivery_time,
      r.address as restaurant_address,
      r.latitude as restaurant_lat,
      r.longitude as restaurant_lng
    FROM menu_items m
    JOIN restaurants r ON m.restaurant_id = r.id
    WHERE m.is_available = 1 AND r.status = 1
    ORDER BY ${orderBy}
    LIMIT ${offset}, ${limit}
  `;

  const [rows] = await db.execute(query);

  // 获取总数
  const [countRows] = await db.execute(`
    SELECT COUNT(*) as total
    FROM menu_items m
    JOIN restaurants r ON m.restaurant_id = r.id
    WHERE m.is_available = 1 AND r.status = 1
  `);

  // 转换数据格式
  const foods = rows.map((row) => ({
    id: row.id.toString(),
    name: row.name,
    description: row.description,
    price: parseFloat(row.price),
    originalPrice: row.original_price ? parseFloat(row.original_price) : null,
    image: row.image,
    monthSales: row.sales || 0,
    rating: 4.5, // TODO: 从订单评价计算
    restaurantId: row.restaurant_id.toString(),
    restaurant: {
      id: row.r_id.toString(),
      name: row.restaurant_name,
      logo: row.restaurant_logo,
      rating: parseFloat(row.restaurant_rating || 5.0),
      deliveryFee: parseFloat(row.restaurant_delivery_fee || 0),
      avgDeliveryTime: row.restaurant_avg_delivery_time || 30,
      address: row.restaurant_address,
      lat: parseFloat(row.restaurant_lat || 0),
      lng: parseFloat(row.restaurant_lng || 0),
    },
  }));

  return {
    foods,
    total: countRows[0].total,
    page: pageNum,
    pageSize: limit,
  };
};

/**
 * 搜索餐厅或菜品
 */
exports.search = async (keyword, params = {}) => {
  const { type = 'all' } = params;
  const results = {
    restaurants: [],
    foods: [],
  };

  // 搜索餐厅
  if (type === 'all' || type === 'restaurant') {
    const [restaurantRows] = await db.execute(
      `SELECT * FROM restaurants
       WHERE status = 1 AND name LIKE ?
       ORDER BY rating DESC
       LIMIT 10`,
      [`%${keyword}%`]
    );

    results.restaurants = restaurantRows.map((row) => ({
      id: row.id.toString(),
      name: row.name,
      cuisine: JSON.parse(row.tags || '[]'),
      rating: parseFloat(row.rating),
      deliveryFee: parseFloat(row.delivery_fee),
    }));
  }

  // 搜索菜品
  if (type === 'all' || type === 'food') {
    const [foodRows] = await db.execute(
      `SELECT m.*, r.name as restaurant_name
       FROM menu_items m
       JOIN restaurants r ON m.restaurant_id = r.id
       WHERE m.is_available = 1 AND m.name LIKE ?
       ORDER BY m.sales DESC
       LIMIT 10`,
      [`%${keyword}%`]
    );

    results.foods = foodRows.map((row) => ({
      id: row.id.toString(),
      restaurantId: row.restaurant_id.toString(),
      restaurantName: row.restaurant_name,
      name: row.name,
      price: parseFloat(row.price),
      monthSales: row.sales,
      image: row.image,
    }));
  }

  return results;
};
