const db = require('../config/database');
const logger = require('../utils/logger');

/**
 * 获取仪表盘KPI数据
 */
exports.getDashboardKPIs = async () => {
  // 获取总GMV（总交易额）
  const [gmvRows] = await db.execute(
    `SELECT SUM(total_amount) as totalGmv
     FROM orders
     WHERE status IN ('paid', 'completed')`
  );

  // 获取总订单数
  const [orderRows] = await db.execute(
    `SELECT COUNT(*) as totalOrders
     FROM orders
     WHERE status != 'deleted'`
  );

  // 获取活跃骑手数（最近24小时有接单的骑手）
  const [riderRows] = await db.execute(
    `SELECT COUNT(DISTINCT courier_id) as activeRiders
     FROM orders
     WHERE status IN ('delivering', 'completed')
     AND updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)`
  );

  // 计算订单完成率
  const [completionRows] = await db.execute(
    `SELECT
      COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
      COUNT(*) as total
     FROM orders
     WHERE status NOT IN ('deleted', 'canceled', 'cancelled')`
  );

  const completionRate = completionRows[0].total > 0
    ? (completionRows[0].completed / completionRows[0].total * 100).toFixed(1)
    : 0;

  return {
    totalGmv: parseFloat(gmvRows[0].totalGmv) || 0,
    totalOrders: orderRows[0].totalOrders || 0,
    activeRiders: riderRows[0].activeRiders || 0,
    completionRate: parseFloat(completionRate)
  };
};

/**
 * 获取订单趋势数据
 */
exports.getOrderTrend = async (days = 7) => {
  const [rows] = await db.execute(
    `SELECT
      DATE_FORMAT(created_at, '%m-%d') as date,
      COUNT(*) as count
     FROM orders
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
     AND status != 'deleted'
     GROUP BY DATE(created_at)
     ORDER BY created_at ASC`,
    [days]
  );

  const labels = rows.map(row => row.date);
  const values = rows.map(row => row.count);

  return {
    labels,
    values
  };
};

/**
 * 获取收入统计
 */
exports.getRevenueStats = async (period) => {
  let dateCondition = '';

  switch (period) {
    case 'today':
      dateCondition = 'DATE(created_at) = CURDATE()';
      break;
    case 'week':
      dateCondition = 'created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
      break;
    case 'month':
    default:
      dateCondition = 'created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)';
  }

  const [rows] = await db.execute(
    `SELECT
      SUM(total_amount) as totalRevenue,
      SUM(delivery_fee) as deliveryFeeRevenue,
      COUNT(*) as orderCount,
      AVG(total_amount) as avgOrderAmount
     FROM orders
     WHERE ${dateCondition}
     AND status IN ('paid', 'completed')`
  );

  return {
    totalRevenue: parseFloat(rows[0].totalRevenue) || 0,
    deliveryFeeRevenue: parseFloat(rows[0].deliveryFeeRevenue) || 0,
    orderCount: rows[0].orderCount || 0,
    avgOrderAmount: parseFloat(rows[0].avgOrderAmount) || 0,
    period
  };
};
