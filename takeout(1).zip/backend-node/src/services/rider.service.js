const db = require('../config/database');
const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

/**
 * 获取可接订单列表
 */
exports.getAvailableOrders = async () => {
  const [rows] = await db.execute(
    `SELECT * FROM orders
     WHERE status = 'paid' AND courier_id IS NULL
     ORDER BY created_at DESC`
  );

  return rows;
};

/**
 * 接单
 */
exports.acceptOrder = async (orderId, riderId) => {
  const [result] = await db.execute(
    'UPDATE orders SET courier_id = ?, status = ?, accept_time = NOW() WHERE id = ? AND courier_id IS NULL AND status IN (?, ?, ?)',
    [riderId, 'preparing', orderId, 'paid', 'pending_accept', 'pending_payment']
  );

  if (result.affectedRows === 0) {
    throw new Error('订单不存在、已被接单或状态不正确');
  }

  logger.info(`骑手${riderId}接单成功: ${orderId}`);
};

/**
 * 获取骑手排行榜
 */
exports.getRiderRanking = async (period, type, currentRiderId) => {
  let dateCondition = '';

  switch (period) {
    case 'today':
      dateCondition = 'DATE(o.delivery_time) = CURDATE()';
      break;
    case 'week':
      dateCondition = 'o.delivery_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
      break;
    case 'month':
      dateCondition = 'o.delivery_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)';
      break;
    default:
      dateCondition = 'DATE(o.delivery_time) = CURDATE()';
  }

  let orderByField = '';
  let selectField = '';

  switch (type) {
    case 'orders':
      selectField = 'COUNT(*) as value';
      orderByField = 'COUNT(*)';
      break;
    case 'income':
      selectField = 'SUM(o.delivery_fee) as value';
      orderByField = 'SUM(o.delivery_fee)';
      break;
    case 'rating':
      selectField = 'AVG(c.rating) as value';
      orderByField = 'AVG(c.rating)';
      break;
    default:
      selectField = 'COUNT(*) as value';
      orderByField = 'COUNT(*)';
  }

  const [rows] = await db.execute(
    `SELECT
      c.id,
      c.real_name as name,
      c.avatar,
      ${selectField},
      RANK() OVER (ORDER BY ${orderByField} DESC) as \`rank\`
     FROM couriers c
     LEFT JOIN orders o ON c.id = o.courier_id
     WHERE ${dateCondition} AND o.status = 'completed'
     GROUP BY c.id
     ORDER BY \`rank\` ASC
     LIMIT 50`
  );

  // 格式化返回数据
  return rows.map(row => ({
    id: row.id,
    rank: row.rank,
    name: row.name,
    avatar: row.avatar || 'https://via.placeholder.com/50',
    value: Math.round(row.value),
    type,
    period,
    isMe: currentRiderId && row.id === parseInt(currentRiderId)
  }));
};

/**
 * 获取骑手任务列表
 */
exports.getRiderTasks = async (riderId) => {
  const [rows] = await db.execute(
    `SELECT * FROM rider_tasks
     WHERE courier_id = ? OR courier_id IS NULL
     ORDER BY status ASC, reward DESC`,
    [riderId]
  );

  return rows.map(row => ({
    id: row.id,
    titleKey: row.title_key,
    descriptionKey: row.description_key,
    progressCurrent: row.progress_current,
    progressTarget: row.progress_target,
    reward: row.reward,
    status: row.status, // inprogress, claimable, completed
    taskType: row.task_type
  }));
};

/**
 * 领取任务奖励
 */
exports.claimTaskReward = async (riderId, taskId) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 1. 检查任务状态
    const [taskRows] = await connection.execute(
      'SELECT * FROM rider_tasks WHERE id = ? AND courier_id = ?',
      [taskId, riderId]
    );

    if (taskRows.length === 0) {
      throw new Error('任务不存在');
    }

    const task = taskRows[0];

    if (task.status !== 'claimable') {
      throw new Error('任务奖励不可领取');
    }

    // 2. 更新任务状态为已完成
    await connection.execute(
      'UPDATE rider_tasks SET status = ?, claimed_at = NOW() WHERE id = ?',
      ['completed', taskId]
    );

    // 3. 增加骑手余额
    await connection.execute(
      'UPDATE couriers SET balance = balance + ? WHERE id = ?',
      [task.reward, riderId]
    );

    await connection.commit();

    logger.info(`骑手${riderId}领取任务奖励成功: ${taskId}, 奖励: ${task.reward}`);

    return {
      taskId,
      reward: task.reward,
      message: '奖励领取成功'
    };

  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 骑手登录（账号密码登录，明文密码）
 */
exports.riderLogin = async (username, password) => {
  // 查询骑手信息
  const [rows] = await db.execute(
    'SELECT * FROM couriers WHERE username = ?',
    [username]
  );

  if (rows.length === 0) {
    throw new Error('账号不存在');
  }

  const rider = rows[0];

  // 验证密码（明文比对）
  if (rider.password !== password) {
    throw new Error('密码错误');
  }

  // 注释掉审核状态检查，允许任何状态的骑手登录
  // if (rider.status !== 'approved') {
  //   throw new Error(`骑手状态: ${rider.status}，请等待审核通过后再登录`);
  // }

  // 生成真实JWT token
  const token = jwt.sign(
    {
      riderId: rider.id,
      username: rider.username,
      type: 'courier'
    },
    process.env.JWT_SECRET || 'takeaway-secret-key',
    { expiresIn: '7d' }
  );

  logger.info(`骑手登录成功: ${rider.id} (${rider.username})`);

  return {
    riderId: rider.id,
    name: rider.real_name,
    phone: rider.phone,
    username: rider.username,
    avatar: rider.avatar,
    authStatus: rider.status,
    token
  };
};

/**
 * 骑手退出登录
 */
exports.riderLogout = async (riderId) => {
  // 更新骑手在线状态
  await db.execute(
    'UPDATE couriers SET is_online = 0 WHERE id = ?',
    [riderId]
  );

  logger.info(`骑手${riderId}退出登录`);

  return {
    success: true,
    message: '退出登录成功'
  };
};

/**
 * 确认取餐
 */
exports.confirmPickup = async (orderId, riderId) => {
  const [result] = await db.execute(
    `UPDATE orders
     SET status = 'delivering', pickup_time = NOW()
     WHERE id = ? AND courier_id = ? AND status IN ('ready', 'pending_pickup')`,
    [orderId, riderId]
  );

  if (result.affectedRows === 0) {
    throw new Error('订单不存在或状态不正确');
  }

  logger.info(`骑手${riderId}确认取餐: ${orderId}`);

  return {
    success: true,
    message: '取餐成功，开始配送'
  };
};

/**
 * 确认送达
 */
exports.confirmDelivery = async (orderId, riderId) => {
  const [result] = await db.execute(
    `UPDATE orders
     SET status = 'completed', delivery_time = NOW()
     WHERE id = ? AND courier_id = ? AND status = 'delivering'`,
    [orderId, riderId]
  );

  if (result.affectedRows === 0) {
    throw new Error('订单不存在或状态不正确');
  }

  // 更新骑手统计数据
  await db.execute(
    `UPDATE couriers
     SET total_orders = total_orders + 1, is_busy = 0
     WHERE id = ?`,
    [riderId]
  );

  logger.info(`骑手${riderId}确认送达: ${orderId}`);

  return {
    success: true,
    message: '订单已送达'
  };
};

/**
 * 提交骑手认证信息
 */
exports.submitRiderAuth = async (authData) => {
  const { riderId, realName, idCard, healthCert, vehicleInfo } = authData;

  await db.execute(
    `UPDATE couriers SET
      real_name = ?,
      id_card = ?,
      status = 'pending'
     WHERE id = ?`,
    [realName || null, idCard || null, riderId]
  );

  logger.info(`骑手提交认证信息: ${riderId}`);

  return {
    riderId,
    authStatus: 'pending',
    message: '认证信息已提交，等待审核'
  };
};

/**
 * 获取骑手认证状态
 */
exports.getRiderAuthStatus = async (riderId) => {
  const [rows] = await db.execute(
    'SELECT status, real_name, created_at FROM couriers WHERE id = ?',
    [riderId]
  );

  if (rows.length === 0) {
    throw new Error('骑手不存在');
  }

  const rider = rows[0];

  return {
    authStatus: rider.status, // pending, approved, rejected, disabled
    realName: rider.real_name,
    submittedAt: rider.created_at
  };
};

/**
 * 获取骑手收入统计
 */
exports.getRiderIncome = async (riderId, period) => {
  let dateCondition = '';

  switch (period) {
    case 'today':
      dateCondition = 'DATE(o.delivery_time) = CURDATE()';
      break;
    case 'week':
      dateCondition = 'o.delivery_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
      break;
    case 'month':
      dateCondition = 'o.delivery_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)';
      break;
    default:
      dateCondition = 'DATE(o.delivery_time) = CURDATE()';
  }

  const [rows] = await db.execute(
    `SELECT
      COUNT(*) as totalOrders,
      SUM(o.delivery_fee) as totalIncome,
      AVG(o.delivery_fee) as avgIncome
     FROM orders o
     WHERE o.courier_id = ? AND o.status = 'completed' AND ${dateCondition}`,
    [riderId]
  );

  // 获取骑手余额
  const [balanceRows] = await db.execute(
    'SELECT balance FROM couriers WHERE id = ?',
    [riderId]
  );

  return {
    period,
    totalOrders: rows[0].totalOrders || 0,
    totalIncome: parseFloat(rows[0].totalIncome) || 0,
    avgIncome: parseFloat(rows[0].avgIncome) || 0,
    balance: balanceRows.length > 0 ? parseFloat(balanceRows[0].balance) : 0
  };
};

/**
 * 获取骑手订单列表
 */
exports.getRiderOrders = async (riderId, status, page, pageSize) => {
  const offset = (parseInt(page) - 1) * parseInt(pageSize);

  let query = 'SELECT * FROM orders WHERE courier_id = ?';
  const params = [riderId];

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  const limit = parseInt(pageSize);
  query += ` ORDER BY created_at DESC LIMIT ${limit} OFFSET ${offset}`;

  const [orders] = await db.execute(query, params);

  // 获取总数
  let countQuery = 'SELECT COUNT(*) as total FROM orders WHERE courier_id = ?';
  const countParams = [riderId];

  if (status) {
    countQuery += ' AND status = ?';
    countParams.push(status);
  }

  const [countResult] = await db.execute(countQuery, countParams);

  return {
    orders,
    total: countResult[0].total,
    page: parseInt(page),
    pageSize: parseInt(pageSize)
  };
};

/**
 * 获取骑手订单详情
 */
exports.getRiderOrderDetail = async (orderId, riderId) => {
  // 查询订单基本信息，关联商家和客户信息
  const [orders] = await db.execute(
    `SELECT
       o.id, o.order_no, o.total_amount, o.delivery_fee, o.package_fee,
       o.discount_amount, o.final_amount, o.payment_method, o.remark,
       o.status, o.created_at, o.accept_time, o.pickup_time, o.delivery_time,
       o.estimated_delivery_time,
       r.name AS restaurant_name, r.phone AS restaurant_phone,
       r.address AS restaurant_address, r.latitude AS restaurant_lat, r.longitude AS restaurant_lng,
       o.contact_name AS customer_name, o.contact_phone AS customer_phone,
       o.delivery_address AS customer_address, o.latitude AS customer_lat, o.longitude AS customer_lng
     FROM orders o
     LEFT JOIN restaurants r ON o.restaurant_id = r.id
     WHERE o.id = ? AND o.courier_id = ?`,
    [orderId, riderId]
  );

  if (orders.length === 0) {
    throw new Error('订单不存在或无权查看');
  }

  // 查询订单商品明细
  const [items] = await db.execute(
    `SELECT
       oi.id, oi.name AS dish_name, oi.image, oi.price, oi.quantity, oi.subtotal
     FROM order_items oi
     WHERE oi.order_id = ?`,
    [orderId]
  );

  const order = orders[0];

  return {
    ...order,
    items
  };
};

/**
 * 创建提现申请
 */
exports.createWithdrawal = async ({ riderId, amount, bankAccount, bankName, realName }) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 1. 检查骑手余额
    const [couriers] = await connection.execute(
      'SELECT balance, real_name FROM couriers WHERE id = ?',
      [riderId]
    );

    if (couriers.length === 0) {
      throw new Error('骑手不存在');
    }

    const balance = parseFloat(couriers[0].balance);
    const courierRealName = couriers[0].real_name;

    // 验证金额
    if (amount <= 0) {
      throw new Error('提现金额必须大于0');
    }

    if (balance < amount) {
      throw new Error(`余额不足，当前余额: ¥${balance.toFixed(2)}`);
    }

    // 提现限额检查
    if (amount > 5000) {
      throw new Error('单次提现金额不能超过5000元');
    }

    // 检查今日提现次数
    const [todayCount] = await connection.execute(
      `SELECT COUNT(*) as count FROM withdrawal_records
       WHERE courier_id = ? AND DATE(created_at) = CURDATE()`,
      [riderId]
    );

    if (todayCount[0].count >= 3) {
      throw new Error('每日最多提现3次');
    }

    // 2. 扣除余额
    await connection.execute(
      'UPDATE couriers SET balance = balance - ? WHERE id = ?',
      [amount, riderId]
    );

    // 3. 创建提现记录
    const [result] = await connection.execute(
      `INSERT INTO withdrawal_records
       (courier_id, amount, bank_account, bank_name, real_name, status)
       VALUES (?, ?, ?, ?, ?, 'pending')`,
      [riderId, amount, bankAccount, bankName, realName || courierRealName]
    );

    await connection.commit();

    logger.info(`骑手${riderId}提现申请成功: ${amount}元, 提现ID: ${result.insertId}`);

    return {
      withdrawalId: result.insertId,
      amount,
      status: 'pending',
      message: '提现申请已提交，预计1-3个工作日到账'
    };

  } catch (error) {
    await connection.rollback();
    logger.error(`骑手${riderId}提现失败:`, error);
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 获取提现记录
 */
exports.getWithdrawalRecords = async (riderId, page = 1, pageSize = 20) => {
  const offset = (parseInt(page) - 1) * parseInt(pageSize);
  const limit = parseInt(pageSize);

  const [records] = await db.execute(
    `SELECT
       id, amount, status, bank_account, bank_name, real_name, reject_reason,
       created_at, approved_at, completed_at
     FROM withdrawal_records
     WHERE courier_id = ?
     ORDER BY created_at DESC
     LIMIT ${limit} OFFSET ${offset}`,
    [riderId]
  );

  // 获取总数
  const [countResult] = await db.execute(
    'SELECT COUNT(*) as total FROM withdrawal_records WHERE courier_id = ?',
    [riderId]
  );

  return {
    records,
    total: countResult[0].total,
    page: parseInt(page),
    pageSize: parseInt(pageSize)
  };
};

/**
 * 骑手注册
 */
exports.registerRider = async ({ username, password, realName, phone }) => {
  // 1. 检查用户名是否已注册
  const [existingUsername] = await db.execute(
    'SELECT id FROM couriers WHERE username = ?',
    [username]
  );

  if (existingUsername.length > 0) {
    throw new Error('该用户名已被使用');
  }

  // 2. 如果提供了手机号，检查是否已注册
  if (phone) {
    const [existingPhone] = await db.execute(
      'SELECT id FROM couriers WHERE phone = ?',
      [phone]
    );

    if (existingPhone.length > 0) {
      throw new Error('该手机号已注册');
    }
  }

  // 3. 创建骑手账号（密码明文存储）
  const [result] = await db.execute(
    `INSERT INTO couriers
     (username, phone, password, real_name, id_card, status, balance, is_online, is_busy)
     VALUES (?, ?, ?, ?, 'PENDING', 'pending', 0.00, 0, 0)`,
    [username, phone || null, password, realName]
  );

  logger.info(`骑手注册成功: ${result.insertId}, 用户名: ${username}`);

  return {
    riderId: result.insertId,
    username,
    phone,
    status: 'pending',
    message: '注册成功，请登录后完成实名认证'
  };
};

