const db = require('../config/database');
const logger = require('../utils/logger');

/**
 * 获取商家的所有分类（含菜品数量统计）
 */
exports.getCategories = async (restaurantId) => {
  const query = `
    SELECT
      mc.id,
      mc.name,
      mc.sort_order,
      mc.created_at,
      COUNT(mi.id) as dish_count
    FROM menu_categories mc
    LEFT JOIN menu_items mi ON mc.id = mi.category_id AND mi.restaurant_id = mc.restaurant_id
    WHERE mc.restaurant_id = ?
    GROUP BY mc.id, mc.name, mc.sort_order, mc.created_at
    ORDER BY mc.sort_order ASC, mc.id ASC
  `;

  const [rows] = await db.execute(query, [restaurantId]);
  return rows;
};

/**
 * 根据ID获取单个分类
 */
exports.getCategoryById = async (restaurantId, categoryId) => {
  const query = `
    SELECT id, name, sort_order, created_at
    FROM menu_categories
    WHERE id = ? AND restaurant_id = ?
  `;

  const [rows] = await db.execute(query, [categoryId, restaurantId]);

  if (rows.length === 0) {
    throw new Error('分类不存在');
  }

  return rows[0];
};

/**
 * 创建新分类
 */
exports.createCategory = async (restaurantId, categoryData) => {
  const { name, sort_order = 0 } = categoryData;

  // 验证分类名称
  if (!name || name.trim().length === 0) {
    throw new Error('分类名称不能为空');
  }

  // 检查分类名称是否已存在
  const checkQuery = `
    SELECT id FROM menu_categories
    WHERE restaurant_id = ? AND name = ?
  `;
  const [existing] = await db.execute(checkQuery, [restaurantId, name.trim()]);

  if (existing.length > 0) {
    throw new Error('分类名称已存在');
  }

  // 如果未指定排序，自动设置为最大值+1
  let finalSortOrder = sort_order;
  if (!sort_order) {
    const maxQuery = `
      SELECT COALESCE(MAX(sort_order), 0) + 1 as next_order
      FROM menu_categories
      WHERE restaurant_id = ?
    `;
    const [maxResult] = await db.execute(maxQuery, [restaurantId]);
    finalSortOrder = maxResult[0].next_order;
  }

  // 插入新分类
  const insertQuery = `
    INSERT INTO menu_categories (restaurant_id, name, sort_order)
    VALUES (?, ?, ?)
  `;

  const [result] = await db.execute(insertQuery, [
    restaurantId,
    name.trim(),
    finalSortOrder
  ]);

  logger.info(`创建分类成功: ID=${result.insertId}, 商家=${restaurantId}, 名称=${name}`);

  return {
    id: result.insertId,
    name: name.trim(),
    sort_order: finalSortOrder
  };
};

/**
 * 更新分类
 */
exports.updateCategory = async (restaurantId, categoryId, updateData) => {
  const { name, sort_order } = updateData;

  // 验证分类是否存在
  await this.getCategoryById(restaurantId, categoryId);

  const updates = [];
  const params = [];

  if (name !== undefined) {
    if (!name || name.trim().length === 0) {
      throw new Error('分类名称不能为空');
    }

    // 检查名称是否与其他分类重复
    const checkQuery = `
      SELECT id FROM menu_categories
      WHERE restaurant_id = ? AND name = ? AND id != ?
    `;
    const [existing] = await db.execute(checkQuery, [restaurantId, name.trim(), categoryId]);

    if (existing.length > 0) {
      throw new Error('分类名称已存在');
    }

    updates.push('name = ?');
    params.push(name.trim());
  }

  if (sort_order !== undefined) {
    updates.push('sort_order = ?');
    params.push(parseInt(sort_order, 10));
  }

  if (updates.length === 0) {
    throw new Error('没有需要更新的字段');
  }

  params.push(categoryId, restaurantId);

  const updateQuery = `
    UPDATE menu_categories
    SET ${updates.join(', ')}
    WHERE id = ? AND restaurant_id = ?
  `;

  await db.execute(updateQuery, params);

  logger.info(`更新分类成功: ID=${categoryId}, 商家=${restaurantId}`);

  return await this.getCategoryById(restaurantId, categoryId);
};

/**
 * 删除分类
 */
exports.deleteCategory = async (restaurantId, categoryId) => {
  // 验证分类是否存在
  await this.getCategoryById(restaurantId, categoryId);

  // 检查是否有菜品使用该分类
  const checkQuery = `
    SELECT COUNT(*) as count
    FROM menu_items
    WHERE restaurant_id = ? AND category_id = ?
  `;
  const [countResult] = await db.execute(checkQuery, [restaurantId, categoryId]);

  if (countResult[0].count > 0) {
    throw new Error(`无法删除分类，该分类下还有 ${countResult[0].count} 个菜品`);
  }

  // 删除分类
  const deleteQuery = `
    DELETE FROM menu_categories
    WHERE id = ? AND restaurant_id = ?
  `;

  await db.execute(deleteQuery, [categoryId, restaurantId]);

  logger.info(`删除分类成功: ID=${categoryId}, 商家=${restaurantId}`);

  return { message: '分类删除成功' };
};

/**
 * 批量更新分类排序
 */
exports.updateCategoriesSort = async (restaurantId, sortData) => {
  if (!Array.isArray(sortData) || sortData.length === 0) {
    throw new Error('排序数据格式错误');
  }

  // 使用事务批量更新
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    for (const item of sortData) {
      const { id, sort_order } = item;

      if (!id || sort_order === undefined) {
        throw new Error('排序数据缺少必要字段');
      }

      await connection.execute(
        'UPDATE menu_categories SET sort_order = ? WHERE id = ? AND restaurant_id = ?',
        [sort_order, id, restaurantId]
      );
    }

    await connection.commit();
    logger.info(`批量更新分类排序成功: 商家=${restaurantId}, 数量=${sortData.length}`);

  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }

  return { message: '排序更新成功' };
};
