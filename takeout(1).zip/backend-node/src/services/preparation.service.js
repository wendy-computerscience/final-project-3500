/**
 * 出餐进度管理服务
 * 为商家提供订单看板、瓶颈分析、进度更新等功能
 */

class PreparationService {
  constructor() {
    // 内存存储（Demo用）
    this.orders = new Map();
    this.stats = {
      totalOrders: 0,
      averagePrepTime: 0,
      onTimeRate: 0
    };

    // 初始化模拟订单
    this.initMockOrders();
  }

  /**
   * 初始化模拟订单
   */
  initMockOrders() {
    const mockOrders = [
      {
        orderId: 'o_001',
        items: ['宫保鸡丁', '麻婆豆腐', '米饭x2'],
        status: 'PENDING', // PENDING, PREPARING, READY, PICKED_UP
        createdAt: Date.now() - 600000, // 10分钟前
        estimatedTime: 15,
        actualStartTime: null,
        completedTime: null,
        priority: 'normal', // normal, high, urgent
        notes: ''
      },
      {
        orderId: 'o_002',
        items: ['红烧肉', '青菜', '米饭'],
        status: 'PREPARING',
        createdAt: Date.now() - 420000, // 7分钟前
        estimatedTime: 20,
        actualStartTime: Date.now() - 300000,
        completedTime: null,
        priority: 'high',
        notes: ''
      },
      {
        orderId: 'o_003',
        items: ['番茄炒蛋', '米饭'],
        status: 'READY',
        createdAt: Date.now() - 900000, // 15分钟前
        estimatedTime: 10,
        actualStartTime: Date.now() - 600000,
        completedTime: Date.now() - 60000, // 1分钟前完成
        priority: 'normal',
        notes: ''
      },
      {
        orderId: 'o_004',
        items: ['水煮鱼', '米饭x2'],
        status: 'PENDING',
        createdAt: Date.now() - 180000, // 3分钟前
        estimatedTime: 25,
        actualStartTime: null,
        completedTime: null,
        priority: 'urgent',
        notes: '客户催单'
      },
      {
        orderId: 'o_005',
        items: ['炒面', '凉菜拼盘'],
        status: 'PICKED_UP',
        createdAt: Date.now() - 1200000, // 20分钟前
        estimatedTime: 12,
        actualStartTime: Date.now() - 900000,
        completedTime: Date.now() - 300000,
        priority: 'normal',
        notes: ''
      }
    ];

    mockOrders.forEach((order) => {
      this.orders.set(order.orderId, order);
    });
  }

  /**
   * 获取订单看板数据（按状态分组）
   */
  getKanbanOrders(merchantId) {
    const allOrders = Array.from(this.orders.values());

    return {
      pending: allOrders.filter((o) => o.status === 'PENDING'),
      preparing: allOrders.filter((o) => o.status === 'PREPARING'),
      ready: allOrders.filter((o) => o.status === 'READY'),
      pickedUp: allOrders.filter((o) => o.status === 'PICKED_UP')
    };
  }

  /**
   * 更新订单状态
   */
  updateOrderStatus(orderId, newStatus) {
    const order = this.orders.get(orderId);

    if (!order) {
      return {
        success: false,
        message: '订单不存在'
      };
    }

    const oldStatus = order.status;
    order.status = newStatus;

    // 记录时间戳
    if (newStatus === 'PREPARING' && !order.actualStartTime) {
      order.actualStartTime = Date.now();
    } else if (newStatus === 'READY' && !order.completedTime) {
      order.completedTime = Date.now();
    }

    return {
      success: true,
      data: {
        orderId,
        oldStatus,
        newStatus,
        order
      }
    };
  }

  /**
   * 批量更新订单状态（拖拽看板）
   */
  batchUpdateStatus(updates) {
    const results = [];

    updates.forEach(({ orderId, newStatus }) => {
      const result = this.updateOrderStatus(orderId, newStatus);
      results.push(result);
    });

    return {
      success: true,
      data: results
    };
  }

  /**
   * 获取出餐统计数据
   */
  getStatistics(merchantId, timeRange = 'today') {
    const allOrders = Array.from(this.orders.values());

    // 计算平均出餐时间
    const completedOrders = allOrders.filter((o) => o.completedTime);
    const avgPrepTime =
      completedOrders.length > 0
        ? completedOrders.reduce((sum, o) => {
            const prepTime = o.completedTime - o.actualStartTime;
            return sum + prepTime / 60000; // 转换为分钟
          }, 0) / completedOrders.length
        : 0;

    // 计算准时率
    const onTimeOrders = completedOrders.filter((o) => {
      const actualTime = (o.completedTime - o.actualStartTime) / 60000;
      return actualTime <= o.estimatedTime;
    });
    const onTimeRate =
      completedOrders.length > 0
        ? (onTimeOrders.length / completedOrders.length) * 100
        : 0;

    // 按小时统计订单量
    const hourlyStats = Array.from({ length: 24 }, (_, hour) => ({
      hour,
      count: 0
    }));

    allOrders.forEach((order) => {
      const hour = new Date(order.createdAt).getHours();
      hourlyStats[hour].count++;
    });

    return {
      totalOrders: allOrders.length,
      pendingOrders: allOrders.filter((o) => o.status === 'PENDING').length,
      preparingOrders: allOrders.filter((o) => o.status === 'PREPARING').length,
      readyOrders: allOrders.filter((o) => o.status === 'READY').length,
      completedOrders: completedOrders.length,
      averagePrepTime: Math.round(avgPrepTime),
      onTimeRate: Math.round(onTimeRate),
      hourlyStats: hourlyStats.filter((h) => h.count > 0)
    };
  }

  /**
   * 瓶颈分析
   */
  getBottleneckAnalysis(merchantId) {
    const allOrders = Array.from(this.orders.values());

    // 待处理订单分析
    const pending = allOrders.filter((o) => o.status === 'PENDING');
    const preparing = allOrders.filter((o) => o.status === 'PREPARING');

    // 计算超时订单
    const now = Date.now();
    const overtimeOrders = preparing.filter((o) => {
      const elapsed = (now - o.actualStartTime) / 60000;
      return elapsed > o.estimatedTime;
    });

    // 识别高峰时段
    const currentHour = new Date().getHours();
    const peakHours = [11, 12, 13, 18, 19, 20]; // 午餐和晚餐高峰
    const isPeakTime = peakHours.includes(currentHour);

    // 瓶颈分析
    const bottlenecks = [];

    if (pending.length > 5) {
      bottlenecks.push({
        type: 'PENDING_BACKLOG',
        severity: 'high',
        message: `待处理订单积压：${pending.length}个订单等待制作`,
        suggestion: '建议优先处理高优先级订单，或增加厨师人手'
      });
    }

    if (overtimeOrders.length > 0) {
      bottlenecks.push({
        type: 'OVERTIME',
        severity: 'critical',
        message: `${overtimeOrders.length}个订单制作超时`,
        suggestion: '请关注超时订单，及时与客户沟通'
      });
    }

    if (isPeakTime && preparing.length > 3) {
      bottlenecks.push({
        type: 'PEAK_HOUR',
        severity: 'medium',
        message: '当前为高峰时段，订单量较大',
        suggestion: '建议提前备好半成品，提高出餐效率'
      });
    }

    return {
      totalBottlenecks: bottlenecks.length,
      bottlenecks,
      pendingCount: pending.length,
      preparingCount: preparing.length,
      overtimeCount: overtimeOrders.length,
      isPeakTime,
      currentLoad: preparing.length / 5, // 假设最大并行5个订单
      recommendations:
        bottlenecks.length === 0
          ? ['当前出餐流畅，继续保持']
          : bottlenecks.map((b) => b.suggestion)
    };
  }

  /**
   * 设置订单优先级
   */
  setOrderPriority(orderId, priority) {
    const order = this.orders.get(orderId);

    if (!order) {
      return {
        success: false,
        message: '订单不存在'
      };
    }

    order.priority = priority;

    return {
      success: true,
      data: order
    };
  }

  /**
   * 添加订单备注
   */
  addOrderNotes(orderId, notes) {
    const order = this.orders.get(orderId);

    if (!order) {
      return {
        success: false,
        message: '订单不存在'
      };
    }

    order.notes = notes;

    return {
      success: true,
      data: order
    };
  }

  /**
   * 获取单个订单详情
   */
  getOrderDetail(orderId) {
    const order = this.orders.get(orderId);

    if (!order) {
      return {
        success: false,
        message: '订单不存在'
      };
    }

    // 计算已耗时
    const now = Date.now();
    let elapsedTime = 0;

    if (order.actualStartTime) {
      if (order.completedTime) {
        elapsedTime = (order.completedTime - order.actualStartTime) / 60000;
      } else {
        elapsedTime = (now - order.actualStartTime) / 60000;
      }
    }

    return {
      success: true,
      data: {
        ...order,
        elapsedTime: Math.round(elapsedTime),
        isOvertime: elapsedTime > order.estimatedTime
      }
    };
  }
}

module.exports = new PreparationService();
