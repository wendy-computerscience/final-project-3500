const db = require('../config/database');
const logger = require('../utils/logger');

/**
 * 获取用户优惠券列表
 */
exports.getUserCoupons = async (userId, type) => {
  let query = 'SELECT * FROM user_coupons WHERE customer_id = ?';
  const params = [userId];

  if (type) {
    query += ' AND status = ?';
    params.push(type);
  }

  query += ' ORDER BY created_at DESC';

  const [rows] = await db.execute(query, params);

  return rows.map(row => ({
    id: row.id,
    amount: row.amount,
    conditionKey: row.condition_key,
    scopeKey: row.scope_key,
    expiryKey: row.expiry_key,
    type: row.status,
    expiryDate: row.expiry_date
  }));
};

/**
 * 获取可领取的优惠券列表
 */
exports.getAvailableCoupons = async () => {
  const [rows] = await db.execute(
    `SELECT * FROM available_coupons
     WHERE is_active = 1 AND remaining > 0
     ORDER BY amount DESC`
  );

  return rows.map(row => ({
    id: row.id,
    amount: row.amount,
    conditionKey: row.condition_key,
    scopeKey: row.scope_key,
    expiryKey: row.expiry_key,
    remaining: row.remaining,
    type: 'available'
  }));
};

/**
 * 领取优惠券
 */
exports.claimCoupon = async (userId, couponId) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 1. 检查优惠券是否存在且可领取
    const [couponRows] = await connection.execute(
      'SELECT * FROM available_coupons WHERE id = ? AND is_active = 1 AND remaining > 0',
      [couponId]
    );

    if (couponRows.length === 0) {
      throw new Error('优惠券不存在或已领完');
    }

    const coupon = couponRows[0];

    // 2. 检查用户是否已领取过
    const [userCouponRows] = await connection.execute(
      'SELECT * FROM user_coupons WHERE customer_id = ? AND coupon_template_id = ?',
      [userId, couponId]
    );

    if (userCouponRows.length > 0) {
      throw new Error('您已领取过该优惠券');
    }

    // 3. 创建用户优惠券记录
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 30); // 30天有效期

    const [result] = await connection.execute(
      `INSERT INTO user_coupons (
        customer_id, coupon_template_id, amount, condition_key, scope_key,
        expiry_key, expiry_date, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId,
        couponId,
        coupon.amount,
        coupon.condition_key,
        coupon.scope_key,
        coupon.expiry_key,
        expiryDate,
        'unused'
      ]
    );

    // 4. 减少可领取数量
    await connection.execute(
      'UPDATE available_coupons SET remaining = remaining - 1 WHERE id = ?',
      [couponId]
    );

    await connection.commit();

    logger.info(`用户${userId}领取优惠券成功: ${result.insertId}`);

    return {
      id: result.insertId,
      message: '优惠券领取成功'
    };

  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 使用优惠券
 */
exports.useCoupon = async (couponId, orderId) => {
  await db.execute(
    'UPDATE user_coupons SET status = ?, used_at = NOW(), order_id = ? WHERE id = ?',
    ['used', orderId, couponId]
  );

  logger.info(`优惠券使用成功: ${couponId}`);
};

/**
 * 获取用户红包余额
 */
exports.getRedPacket = async (userId) => {
  const [rows] = await db.execute(
    'SELECT balance FROM red_packets WHERE customer_id = ?',
    [userId]
  );

  if (rows.length === 0) {
    return {
      balance: 0,
      currency: 'CNY'
    };
  }

  return {
    balance: parseFloat(rows[0].balance),
    currency: 'CNY'
  };
};

/**
 * 获取可用优惠券（结算页使用）
 * 当前简单实现：返回用户所有未使用且未过期的优惠券
 */
exports.getUsableCoupons = async (userId, orderAmount, restaurantId) => {
  // 复用 getUserCoupons 逻辑，筛选 status = 'unused'
  const allUnused = await exports.getUserCoupons(userId, 'unused');

  const now = new Date();
  const usable = allUnused.filter((coupon) => {
    if (!coupon.expiryDate) {
      return true;
    }
    const expiry = new Date(coupon.expiryDate);
    return expiry >= now;
  });

  return usable;
};
