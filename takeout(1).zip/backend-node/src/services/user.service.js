const db = require('../config/database');
const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

/**
 * 根据手机号获取用户
 */
exports.getUserByPhone = async (phone) => {
  const [rows] = await db.execute(
    'SELECT * FROM customers WHERE phone = ?',
    [phone]
  );

  return rows.length > 0 ? rows[0] : null;
};

/**
 * 根据用户名获取用户
 */
exports.getUserByUsername = async (username) => {
  const [rows] = await db.execute(
    'SELECT * FROM customers WHERE username = ?',
    [username]
  );

  return rows.length > 0 ? rows[0] : null;
};

/**
 * 创建用户
 */
exports.createUser = async (userData) => {
  const { phone, nickname = '新用户' } = userData;

  const [result] = await db.execute(
    `INSERT INTO customers (phone, password, nickname, created_at)
     VALUES (?, '', ?, NOW())`,
    [phone, nickname]
  );

  logger.info(`新用户创建成功: ${result.insertId}`);

  return {
    id: result.insertId,
    phone,
    nickname,
  };
};

/**
 * 创建带密码的用户
 */
exports.createUserWithPassword = async (userData) => {
  const { username, password, nickname } = userData;
  const displayName = nickname || username;

  const [result] = await db.execute(
    `INSERT INTO customers (username, password, nickname, created_at)
     VALUES (?, ?, ?, NOW())`,
    [username, password, displayName]
  );

  logger.info(`新用户创建成功: ${result.insertId}`);

  return {
    id: result.insertId,
    username,
    nickname: displayName,
    password,
  };
};

/**
 * 更新最后登录时间
 */
exports.updateLastLogin = async (userId) => {
  await db.execute(
    'UPDATE customers SET updated_at = NOW() WHERE id = ?',
    [userId]
  );
};

/**
 * 发送验证码
 */
exports.sendVerificationCode = async (phone) => {
  // 生成6位验证码
  const code = Math.floor(100000 + Math.random() * 900000).toString();

  // TODO: 实际应用中应该：
  // 1. 调用短信服务商API发送验证码
  // 2. 将验证码存储到Redis，设置5分钟过期时间
  // 3. 限制同一手机号的发送频率（如1分钟1次）

  // 开发环境：固定验证码为 123456
  const actualCode = process.env.NODE_ENV === 'development' ? '123456' : code;

  logger.info(`验证码已生成 ${phone}: ${actualCode}`);

  // 开发环境下返回验证码
  if (process.env.NODE_ENV === 'development') {
    return { code: actualCode, message: '开发环境，验证码固定为123456' };
  }

  return { message: '验证码已发送' };
};

/**
 * 获取用户信息
 */
exports.getUserProfile = async (userId) => {
  const [users] = await db.execute(
    `SELECT id, username, phone, nickname, avatar, points, created_at
     FROM customers WHERE id = ?`,
    [userId]
  );

  if (users.length === 0) {
    return null;
  }

  const user = users[0];

  return {
    id: user.id,
    username: user.username,
    phone: user.phone,
    nickname: user.nickname,
    avatar: user.avatar,
    points: user.points,
    createdAt: user.created_at,
  };
};

/**
 * 更新用户信息
 */
exports.updateUserProfile = async (userId, updateData) => {
  const { nickname, avatar, email, gender, birthday } = updateData;
  const updates = [];
  const params = [];

  if (nickname) {
    updates.push('nickname = ?');
    params.push(nickname);
  }
  if (avatar) {
    updates.push('avatar = ?');
    params.push(avatar);
  }
  if (email !== undefined) {
    updates.push('email = ?');
    params.push(email);
  }
  if (gender !== undefined) {
    updates.push('gender = ?');
    params.push(gender);
  }
  if (birthday !== undefined) {
    updates.push('birthday = ?');
    params.push(birthday);
  }

  if (updates.length === 0) {
    throw new Error('没有需要更新的字段');
  }

  params.push(userId);

  await db.execute(
    `UPDATE customers SET ${updates.join(', ')}, updated_at = NOW() WHERE id = ?`,
    params
  );

  logger.info(`用户信息已更新: ${userId}`);

  return await exports.getUserProfile(userId);
};

