const db = require('../config/database');
const mlClient = require('../utils/mlClient');
const logger = require('../utils/logger');

/**
 * 创建订单
 */
exports.createOrder = async (orderData) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 生成订单号
    const orderNo = `ORD${Date.now()}${Math.floor(Math.random() * 1000)}`;

    // 1. 创建订单记录
    const [orderResult] = await connection.execute(
      `INSERT INTO orders (
        order_no, customer_id, restaurant_id,
        delivery_address_id, contact_name, contact_phone,
        delivery_address, latitude, longitude,
        total_amount, delivery_fee, discount_amount, final_amount,
        payment_method, remark, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        orderNo,
        orderData.userId,
        orderData.restaurantId,
        orderData.deliveryAddress.id || 0,
        orderData.deliveryAddress.name,
        orderData.deliveryAddress.phone,
        `${orderData.deliveryAddress.detail} ${orderData.deliveryAddress.room || ''}`.trim(),
        orderData.deliveryAddress.latitude || 0,
        orderData.deliveryAddress.longitude || 0,
        orderData.subtotal,
        orderData.deliveryFee,
        orderData.discount || 0,
        orderData.totalAmount,
        'wechat',  // 默认支付方式
        orderData.remark || '',
        'pending_payment'
      ]
    );

    const orderId = orderResult.insertId;

    // 2. 创建订单商品明细
    if (orderData.items && orderData.items.length > 0) {
      const itemValues = orderData.items.map(item => [
        orderId,
        item.foodId,
        item.name,
        item.price,
        item.quantity,
        item.price * item.quantity
      ]);

      const placeholders = itemValues.map(() => '(?, ?, ?, ?, ?, ?)').join(', ');
      const flatValues = itemValues.flat();

      await connection.execute(
        `INSERT INTO order_items (
          order_id, menu_item_id, name, price, quantity, subtotal
        ) VALUES ${placeholders}`,
        flatValues
      );
    }

    // 3. 清空用户该餐厅的购物车
    await connection.execute(
      `DELETE FROM cart_items WHERE customer_id = ? AND restaurant_id = ?`,
      [orderData.userId, orderData.restaurantId]
    );

    await connection.commit();

    logger.info(`订单创建成功: ${orderId}, 订单号: ${orderNo}`);

    return {
      orderId: orderId,
      orderNumber: orderNo,
      totalAmount: orderData.totalAmount,
      status: 'pending_payment',
      message: '订单创建成功'
    };

  } catch (error) {
    await connection.rollback();
    logger.error('创建订单失败:', error);
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 获取订单详情
 */
exports.getOrderDetail = async (orderId) => {
  // 获取订单基本信息
  const [orderRows] = await db.execute(
    `SELECT o.*, r.name as restaurant_name
     FROM orders o
     LEFT JOIN restaurants r ON o.restaurant_id = r.id
     WHERE o.id = ?`,
    [orderId]
  );

  if (orderRows.length === 0) {
    return null;
  }

  const order = orderRows[0];

  // 获取订单商品列表
  const [itemRows] = await db.execute(
    `SELECT id, menu_item_id, name, price, quantity, subtotal
     FROM order_items
     WHERE order_id = ?`,
    [orderId]
  );

  order.items = itemRows;

  return order;
};

/**
 * 获取用户订单列表
 */
exports.getUserOrders = async (userId, status, page, pageSize) => {
  // 确保分页参数是有效的整数
  const limit = parseInt(pageSize) || 20;
  const pageNum = parseInt(page) || 1;
  const offset = (pageNum - 1) * limit;

  let query = 'SELECT * FROM orders WHERE customer_id = ?';
  const params = [userId];

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  // 使用字符串插值而非参数绑定处理 LIMIT 和 OFFSET
  query += ` ORDER BY created_at DESC LIMIT ${limit} OFFSET ${offset}`;

  const [rows] = await db.execute(query, params);

  // 获取总数
  const [countResult] = await db.execute(
    'SELECT COUNT(*) as total FROM orders WHERE customer_id = ?' + (status ? ' AND status = ?' : ''),
    status ? [userId, status] : [userId]
  );

  return {
    orders: rows,
    total: countResult[0].total,
    page: pageNum,
    pageSize: limit
  };
};

/**
 * 取消订单
 */
exports.cancelOrder = async (orderId, cancelReason) => {
  await db.execute(
    'UPDATE orders SET status = ?, cancel_reason = ?, canceled_at = NOW() WHERE id = ?',
    ['canceled', cancelReason, orderId]
  );

  logger.info(`订单已取消: ${orderId}`);
};

/**
 * 支付订单
 */
exports.payOrder = async (orderId, paymentMethod) => {
  // TODO: 调用支付接口

  await db.execute(
    'UPDATE orders SET status = ?, payment_method = ?, paid_at = NOW() WHERE id = ?',
    ['paid', paymentMethod, orderId]
  );

  logger.info(`订单已支付: ${orderId}`);

  return {
    orderId,
    paymentStatus: 'success'
  };
};

/**
 * 获取订单状态徽章数量
 */
exports.getOrdersBadge = async (userId) => {
  const [rows] = await db.execute(
    `SELECT
      status,
      COUNT(*) as count
    FROM orders
    WHERE customer_id = ? AND status != 'deleted'
    GROUP BY status`,
    [userId]
  );

  const badges = {
    pendingPayment: 0,
    delivery: 0,
    completed: 0,
    cancelled: 0,
    all: 0
  };

  rows.forEach(row => {
    const status = row.status;
    badges[status] = row.count;
    badges.all += row.count;
  });

  return badges;
};

/**
 * 再来一单
 */
exports.reorderOrder = async (orderId) => {
  // 1. 获取原订单信息和商品明细
  const [orderRows] = await db.execute(
    'SELECT * FROM orders WHERE id = ?',
    [orderId]
  );

  if (orderRows.length === 0) {
    throw new Error('订单不存在');
  }

  const originalOrder = orderRows[0];

  // 2. 获取订单商品明细
  const [items] = await db.execute(
    'SELECT * FROM order_items WHERE order_id = ?',
    [orderId]
  );

  if (items.length === 0) {
    throw new Error('订单商品不存在');
  }

  // 3. 清空购物车原有商品（同一餐厅）
  await db.execute(
    'DELETE FROM cart_items WHERE customer_id = ? AND restaurant_id = ?',
    [originalOrder.customer_id, originalOrder.restaurant_id]
  );

  // 4. 把商品添加到购物车
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    for (const item of items) {
      // 检查 menu_item_id 是否存在
      if (item.menu_item_id) {
        await connection.execute(
          `INSERT INTO cart_items (
            customer_id, restaurant_id, menu_item_id, quantity
          ) VALUES (?, ?, ?, ?)`,
          [
            originalOrder.customer_id,
            originalOrder.restaurant_id,
            item.menu_item_id,
            item.quantity
          ]
        );
      }
    }

    await connection.commit();

    logger.info(`再来一单成功，已添加${items.length}个商品到购物车`);

    return {
      success: true,
      restaurantId: originalOrder.restaurant_id,
      itemCount: items.length,
      message: '商品已添加到购物车'
    };

  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 申请退款
 */
exports.refundOrder = async (orderId, refundReason) => {
  // 1. 检查订单状态
  const [rows] = await db.execute(
    'SELECT status FROM orders WHERE id = ?',
    [orderId]
  );

  if (rows.length === 0) {
    throw new Error('订单不存在');
  }

  const order = rows[0];

  // 2. 只有已支付或已完成的订单可以申请退款
  if (!['paid', 'completed'].includes(order.status)) {
    throw new Error('当前订单状态不允许申请退款');
  }

  // 3. 更新订单状态
  await db.execute(
    'UPDATE orders SET status = ?, refund_reason = ?, refund_requested_at = NOW() WHERE id = ?',
    ['refund_requested', refundReason, orderId]
  );

  logger.info(`退款申请已提交: ${orderId}`);
};

/**
 * 删除订单（软删除）
 */
exports.deleteOrder = async (orderId) => {
  // 1. 检查订单状态
  const [rows] = await db.execute(
    'SELECT status FROM orders WHERE id = ?',
    [orderId]
  );

  if (rows.length === 0) {
    throw new Error('订单不存在');
  }

  const order = rows[0];

  // 2. 只有已完成或已取消的订单可以删除
  if (!['completed', 'canceled', 'cancelled'].includes(order.status)) {
    throw new Error('只能删除已完成或已取消的订单');
  }

  // 3. 软删除
  await db.execute(
    'UPDATE orders SET status = ?, deleted_at = NOW() WHERE id = ?',
    ['deleted', orderId]
  );

  logger.info(`订单已删除: ${orderId}`);
};
