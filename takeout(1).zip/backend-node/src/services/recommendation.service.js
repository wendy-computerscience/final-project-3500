/**
 * 智能推荐服务
 * 实现基于多因子的餐厅推荐算法
 */

const fs = require('fs').promises;
const path = require('path');
const {
  calculateDistance,
  estimateETA,
  jaccardSimilarity,
  clamp
} = require('../utils/geo');

class RecommendationService {
  constructor() {
    this.restaurants = [];
    this.users = [];
    this.loadData();
  }

  /**
   * 加载数据
   */
  async loadData() {
    try {
      const restaurantsPath = path.join(__dirname, '../data/restaurants.json');
      const usersPath = path.join(__dirname, '../data/users.json');

      const [restaurantsData, usersData] = await Promise.all([
        fs.readFile(restaurantsPath, 'utf-8'),
        fs.readFile(usersPath, 'utf-8')
      ]);

      this.restaurants = JSON.parse(restaurantsData);
      this.users = JSON.parse(usersData);
    } catch (error) {
      console.error('加载数据失败:', error);
    }
  }

  /**
   * 获取用户个性化推荐
   * @param {string} userId - 用户ID
   * @param {number} userLat - 用户纬度
   * @param {number} userLng - 用户经度
   * @param {number} limit - 返回数量
   * @returns {Array} - 推荐列表
   */
  async getHomeRecommendations(userId, userLat, userLng, limit = 8) {
    // 获取用户信息
    const user = this.users.find(u => u.id === userId);

    if (!user) {
      // 用户不存在，返回默认推荐（基于距离和评分）
      return this.getDefaultRecommendations(userLat, userLng, limit);
    }

    // 计算每个餐厅的推荐分数
    const rankedRestaurants = this.restaurants
      .filter(r => r.status === 'OPEN')
      .map(restaurant => {
        const distanceKm = calculateDistance(userLat, userLng, restaurant.lat, restaurant.lng);
        const eta = estimateETA(distanceKm, restaurant.avgPrepMin);

        // 计算各项因子
        const tasteSim = jaccardSimilarity(user.tastes, restaurant.cuisine); // 口味相似度 (0-1)
        const etaNorm = clamp(1 - eta / 45, 0, 1); // ETA归一化 (0-1)，假设45分钟是最慢
        const reliability = restaurant.onTimeRate; // 准时率 (0-1)
        const ratingNorm = restaurant.rating / 5; // 评分归一化 (0-1)
        const explore = 0.05 * Math.random(); // 探索因子

        // 计算综合分数（权重可调整）
        const score =
          0.35 * tasteSim +
          0.25 * etaNorm +
          0.15 * reliability +
          0.20 * ratingNorm +
          explore;

        // 生成推荐理由标签
        const reasonTags = this.buildReasonTags(
          user,
          restaurant,
          distanceKm,
          eta,
          tasteSim
        );

        return {
          restaurantId: restaurant.id,
          name: restaurant.name,
          score,
          reasonTags,
          distance: distanceKm.toFixed(1),
          eta,
          rating: restaurant.rating,
          deliveryFee: restaurant.deliveryFee,
          minOrder: restaurant.minOrder
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);

    return rankedRestaurants;
  }

  /**
   * 获取默认推荐（冷启动场景）
   */
  async getDefaultRecommendations(userLat, userLng, limit = 8) {
    const ranked = this.restaurants
      .filter(r => r.status === 'OPEN')
      .map(restaurant => {
        const distanceKm = calculateDistance(userLat, userLng, restaurant.lat, restaurant.lng);
        const eta = estimateETA(distanceKm, restaurant.avgPrepMin);

        // 简单的分数：距离 + 评分 + 销量
        const score =
          0.4 * clamp(1 - distanceKm / 10, 0, 1) +
          0.3 * (restaurant.rating / 5) +
          0.3 * restaurant.onTimeRate;

        const reasonTags = [];
        if (distanceKm < 2) reasonTags.push(`距离${distanceKm.toFixed(1)}km`);
        if (eta < 20) reasonTags.push(`约${eta}分钟`);
        if (restaurant.rating >= 4.7) reasonTags.push(`高评分${restaurant.rating}分`);
        if (restaurant.onTimeRate >= 0.95) reasonTags.push(`准时率${(restaurant.onTimeRate * 100).toFixed(0)}%`);

        return {
          restaurantId: restaurant.id,
          name: restaurant.name,
          score,
          reasonTags,
          distance: distanceKm.toFixed(1),
          eta,
          rating: restaurant.rating,
          deliveryFee: restaurant.deliveryFee,
          minOrder: restaurant.minOrder
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);

    return ranked;
  }

  /**
   * 生成推荐理由标签
   */
  buildReasonTags(user, restaurant, distanceKm, eta, tasteSim) {
    const tags = [];

    // 距离因素
    if (distanceKm < 1.5) {
      tags.push(`距离${distanceKm.toFixed(1)}km`);
    }

    // 速度因素
    if (eta < 15) {
      tags.push(`约${eta}分钟`);
    } else if (eta < 25) {
      tags.push(`约${eta}分钟`);
    }

    // 口味匹配
    if (tasteSim > 0.3) {
      const matchedCuisine = restaurant.cuisine.find(c => user.tastes.includes(c));
      if (matchedCuisine) {
        const cuisineMap = {
          'sichuan': '川菜',
          'cantonese': '粤菜',
          'japanese': '日料',
          'taiwanese': '台式',
          'spicy': '辣味',
          'noodles': '面食'
        };
        const displayName = cuisineMap[matchedCuisine] || matchedCuisine;
        tags.push(`你常点${displayName}`);
      }
    }

    // 准时率
    if (restaurant.onTimeRate >= 0.95) {
      tags.push(`准时率${(restaurant.onTimeRate * 100).toFixed(0)}%`);
    }

    // 评分
    if (restaurant.rating >= 4.7) {
      tags.push(`高评分${restaurant.rating}分`);
    }

    // 最多返回3个标签
    return tags.slice(0, 3);
  }

  /**
   * 获取替代推荐（结算页）
   */
  async getAlternatives(orderId, userLat, userLng, currentRestaurantId) {
    // 获取当前餐厅信息
    const currentRestaurant = this.restaurants.find(r => r.id === currentRestaurantId);

    if (!currentRestaurant) {
      return [];
    }

    // 筛选同类型餐厅
    const alternatives = this.restaurants
      .filter(r =>
        r.id !== currentRestaurantId &&
        r.status === 'OPEN' &&
        r.cuisine.some(c => currentRestaurant.cuisine.includes(c))
      )
      .map(restaurant => {
        const distanceKm = calculateDistance(userLat, userLng, restaurant.lat, restaurant.lng);
        const eta = estimateETA(distanceKm, restaurant.avgPrepMin);

        let reason = '';
        if (eta < estimateETA(
          calculateDistance(userLat, userLng, currentRestaurant.lat, currentRestaurant.lng),
          currentRestaurant.avgPrepMin
        ) - 5) {
          reason = '同类口味，更快';
        } else if (distanceKm < calculateDistance(userLat, userLng, currentRestaurant.lat, currentRestaurant.lng)) {
          reason = '距离更近';
        } else if (restaurant.rating > currentRestaurant.rating) {
          reason = '评分更高';
        } else {
          reason = '同样推荐';
        }

        return {
          restaurantId: restaurant.id,
          name: restaurant.name,
          eta,
          rating: restaurant.rating,
          reason,
          deliveryFee: restaurant.deliveryFee
        };
      })
      .sort((a, b) => a.eta - b.eta)
      .slice(0, 3);

    return alternatives;
  }
}

module.exports = new RecommendationService();
