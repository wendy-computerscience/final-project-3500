const db = require('../config/database');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const logger = require('../utils/logger');

/**
 * 商家登录（支持bcrypt加密密码）
 */
exports.merchantLogin = async (username, password) => {
  // 查询商家信息
  const [merchants] = await db.execute(
    'SELECT * FROM merchants WHERE username = ?',
    [username]
  );

  if (merchants.length === 0) {
    throw new Error('账号不存在');
  }

  const merchant = merchants[0];

  // 验证密码（支持bcrypt和明文密码以实现平滑迁移）
  let isPasswordValid = false;
  if (merchant.password && merchant.password.startsWith('$2b$')) {
    // bcrypt加密密码
    isPasswordValid = await bcrypt.compare(password, merchant.password);
  } else {
    // 明文密码（兼容旧数据）
    isPasswordValid = (merchant.password === password);
    if (isPasswordValid) {
      // 自动升级为bcrypt加密
      const hashedPassword = await bcrypt.hash(password, 10);
      await db.execute('UPDATE merchants SET password = ? WHERE id = ?',
        [hashedPassword, merchant.id]);
      logger.info(`密码已自动升级为bcrypt: ${merchant.id}`);
    }
  }

  if (!isPasswordValid) {
    throw new Error('密码错误');
  }

  // 检查商家状态（只限制disabled状态，approved和pending都可登录）
  if (merchant.status === 'disabled') {
    throw new Error('账号已被禁用，请联系管理员');
  }

  // 生成token
  const token = jwt.sign(
    {
      merchantId: merchant.id,
      username: merchant.username,
      type: 'merchant'
    },
    process.env.JWT_SECRET || 'takeaway-secret-key',
    { expiresIn: '7d' }
  );

  logger.info(`商家登录成功: ${merchant.id} (${merchant.username})`);

  return {
    token,
    merchant: {
      id: merchant.id,
      username: merchant.username,
      phone: merchant.phone,
      business_name: merchant.business_name,
      contact_name: merchant.contact_name,
      contact_phone: merchant.contact_phone,
      email: merchant.email,
      address: merchant.business_name, // 后续可以添加address字段
      status: merchant.status
    }
  };
};

/**
 * 商家注册（即时注册，无需审核）
 */
exports.merchantRegister = async (registrationData) => {
  const {
    username,
    password,
    business_name,
    contact_phone,
    email
  } = registrationData;

  // 必填字段验证
  if (!username || !password || !business_name || !contact_phone) {
    throw new Error('缺少必要的注册信息');
  }

  // 用户名长度验证
  if (username.length < 3) {
    throw new Error('用户名至少3个字符');
  }

  // 密码长度验证
  if (password.length < 6) {
    throw new Error('密码至少6个字符');
  }

  // 检查用户名是否已注册
  const [existingUsername] = await db.execute(
    'SELECT id FROM merchants WHERE username = ?',
    [username]
  );

  if (existingUsername.length > 0) {
    throw new Error('该用户名已被注册');
  }

  // 检查手机号是否已注册
  const [existingPhone] = await db.execute(
    'SELECT id FROM merchants WHERE contact_phone = ?',
    [contact_phone]
  );

  if (existingPhone.length > 0) {
    throw new Error('该手机号已被注册');
  }

  // 使用bcrypt加密密码
  const hashedPassword = await bcrypt.hash(password, 10);

  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    // 插入商家记录（状态直接设为approved）
    const [merchantResult] = await connection.execute(
      `INSERT INTO merchants (
        username, password, business_name, contact_name, contact_phone, email,
        status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'approved', NOW())`,
      [
        username,
        hashedPassword,
        business_name,
        business_name, // contact_name默认使用business_name
        contact_phone,
        email || null
      ]
    );

    const merchantId = merchantResult.insertId;

    // 同时创建餐厅记录
    await connection.execute(
      `INSERT INTO restaurants (
        merchant_id, name, phone, address, status, rating,
        min_order_amount, delivery_fee, avg_delivery_time,
        latitude, longitude, created_at
      ) VALUES (?, ?, ?, ?, 1, 5.0, 0, 0, 30, 39.9042, 116.4074, NOW())`,
      [merchantId, business_name, contact_phone, '待完善地址']
    );

    await connection.commit();

    logger.info(`商家注册成功: merchantId=${merchantId}, username=${username}`);

    return {
      merchantId,
      message: '注册成功，请登录'
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 获取商家详情
 */
exports.getMerchantDetail = async (merchantId) => {
  const [rows] = await db.execute(
    `SELECT
      id, username, phone, business_name, contact_name, contact_phone,
      email, legal_name, license_number, status, created_at, updated_at
     FROM merchants WHERE id = ?`,
    [merchantId]
  );

  if (rows.length === 0) {
    return null;
  }

  const merchant = rows[0];

  // Map database fields to frontend expected format
  return {
    id: merchant.id,
    name: merchant.business_name,
    shopName: merchant.business_name,
    phone: merchant.contact_phone || merchant.phone,
    category: 'Restaurant', // Default category
    address: '', // Not available in current schema
    businessHours: '09:00-22:00', // Default value
    description: '', // Not available in current schema
    license: merchant.license_number,
    avatar: null,
    status: merchant.status === 'approved' ? 'active' : merchant.status,
    rating: 0, // Default rating
    username: merchant.username,
    email: merchant.email,
    contactName: merchant.contact_name,
    legalName: merchant.legal_name,
    createdAt: merchant.created_at,
    updatedAt: merchant.updated_at
  };
};

/**
 * 更新商家信息
 */
exports.updateMerchant = async (merchantId, updateData) => {
  const { name, shopName, phone, email, category, address, businessHours, description } = updateData;

  const updates = [];
  const params = [];

  // Map frontend fields to database fields
  const businessName = name || shopName;
  if (businessName) {
    updates.push('business_name = ?');
    params.push(businessName);
  }
  if (phone) {
    updates.push('contact_phone = ?');
    params.push(phone);
  }
  if (email) {
    updates.push('email = ?');
    params.push(email);
  }

  // Note: address, businessHours, description, category are not in current schema
  // These fields are ignored for now until schema is updated

  if (updates.length === 0) {
    throw new Error('没有需要更新的字段');
  }

  params.push(merchantId);

  await db.execute(
    `UPDATE merchants SET ${updates.join(', ')}, updated_at = NOW() WHERE id = ?`,
    params
  );

  logger.info(`商家信息已更新: ${merchantId}`);
};

/**
 * 获取商家菜品列表
 */
exports.getMerchantDishes = async (merchantId, category, status) => {
  let query = 'SELECT * FROM menu_items WHERE restaurant_id = ?';
  const params = [merchantId];

  if (category) {
    query += ' AND category_id = ?';
    params.push(category);
  }

  if (status !== undefined) {
    query += ' AND is_available = ?';
    params.push(status);
  }

  query += ' ORDER BY created_at DESC';

  const [rows] = await db.execute(query, params);

  return rows;
};

/**
 * 添加菜品
 */
exports.addDish = async (merchantId, dishData) => {
  const {
    name,
    description,
    price,
    originalPrice,
    category_id,  // 改为 category_id
    image,
    stock,
    unit
  } = dishData;

  const [result] = await db.execute(
    `INSERT INTO menu_items (
      restaurant_id, name, description, price, original_price,
      category_id, image, stock, unit, is_available, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
    [
      merchantId,
      name,
      description || null,
      price,
      originalPrice || price,
      category_id || null,  // 使用 category_id
      image || null,
      stock || 999,
      unit || '份',
      1
    ]
  );

  logger.info(`菜品添加成功: ${result.insertId}`);

  return {
    dishId: result.insertId,
    message: '菜品添加成功'
  };
};

/**
 * 更新菜品
 */
exports.updateDish = async (merchantId, dishId, dishData) => {
  // 验证菜品是否属于该商家
  const [existing] = await db.execute(
    'SELECT id FROM menu_items WHERE id = ? AND restaurant_id = ?',
    [dishId, merchantId]
  );

  if (existing.length === 0) {
    throw new Error('菜品不存在或无权限');
  }

  const updates = [];
  const params = [];

  const fieldMap = {
    name: 'name',
    description: 'description',
    price: 'price',
    originalPrice: 'original_price',
    category: 'category_id',  // 向后兼容
    category_id: 'category_id',  // 标准字段名
    image: 'image',
    stock: 'stock',
    unit: 'unit'
  };

  Object.keys(dishData).forEach(key => {
    if (fieldMap[key] && dishData[key] !== undefined) {
      updates.push(`${fieldMap[key]} = ?`);
      params.push(dishData[key]);
    }
  });

  if (updates.length > 0) {
    params.push(dishId, merchantId);
    await db.execute(
      `UPDATE menu_items SET ${updates.join(', ')}, updated_at = NOW()
       WHERE id = ? AND restaurant_id = ?`,
      params
    );
  }

  logger.info(`菜品已更新: ${dishId}`);
};

/**
 * 删除菜品
 */
exports.deleteDish = async (merchantId, dishId) => {
  const [result] = await db.execute(
    'DELETE FROM menu_items WHERE id = ? AND restaurant_id = ?',
    [dishId, merchantId]
  );

  if (result.affectedRows === 0) {
    throw new Error('菜品不存在或无权限');
  }

  logger.info(`菜品已删除: ${dishId}`);
};

/**
 * 上架/下架菜品
 */
exports.toggleDishStatus = async (merchantId, dishId, status) => {
  const [result] = await db.execute(
    'UPDATE menu_items SET is_available = ?, updated_at = NOW() WHERE id = ? AND restaurant_id = ?',
    [status, dishId, merchantId]
  );

  if (result.affectedRows === 0) {
    throw new Error('菜品不存在或无权限');
  }

  logger.info(`菜品状态已更新: ${dishId} -> ${status}`);
};

/**
 * 获取商家订单列表
 */
exports.getMerchantOrders = async (merchantId, status, page, pageSize) => {
  const parsedPage = parseInt(page, 10) || 1;
  const parsedPageSize = parseInt(pageSize, 10) || 10;
  const offset = (parsedPage - 1) * parsedPageSize;

  let query = 'SELECT * FROM orders WHERE restaurant_id = ?';
  const params = [merchantId];

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  query += ` ORDER BY created_at DESC LIMIT ${parsedPageSize} OFFSET ${offset}`;

  const [orders] = await db.execute(query, params);

  // 为每个订单查询订单商品
  const ordersWithItems = await Promise.all(
    orders.map(async (order) => {
      const [items] = await db.execute(
        'SELECT * FROM order_items WHERE order_id = ?',
        [order.id]
      );

      return {
        id: order.id,
        orderId: order.id,
        orderNo: order.order_no,
        customerId: order.customer_id,
        customerName: order.contact_name,
        customerPhone: order.contact_phone,
        customerAddress: order.delivery_address,
        totalAmount: order.total_amount || order.final_amount,
        deliveryFee: order.delivery_fee,
        status: order.status,
        remark: order.remark,
        notes: order.remark,
        createdAt: order.created_at,
        paidAt: order.paid_at,
        estimatedPrepTime: order.estimated_prep_time,
        actualStartTime: order.actual_start_time,
        estimatedDeliveryTime: order.estimated_delivery_time,
        items: items.map(item => ({
          id: item.id,
          foodId: item.food_id,
          name: item.food_name,
          quantity: item.quantity,
          price: item.price
        }))
      };
    })
  );

  // 获取总数
  let countQuery = 'SELECT COUNT(*) as total FROM orders WHERE restaurant_id = ?';
  const countParams = [merchantId];

  if (status) {
    countQuery += ' AND status = ?';
    countParams.push(status);
  }

  const [countResult] = await db.execute(countQuery, countParams);

  return {
    orders: ordersWithItems,
    total: countResult[0].total,
    page: parsedPage,
    pageSize: parsedPageSize
  };
};

/**
 * 获取申请状态
 */
exports.getApplicationStatus = async (merchantId) => {
  const [rows] = await db.execute(
    `SELECT
      id, phone, contact_name, contact_phone, email,
      business_name, category, address,
      status, reject_reason, created_at, updated_at
     FROM merchants
     WHERE id = ?`,
    [merchantId]
  );

  if (rows.length === 0) {
    throw new Error('申请记录不存在');
  }

  const merchant = rows[0];

  // 获取餐厅信息
  const [restaurants] = await db.execute(
    'SELECT category, address FROM restaurants WHERE merchant_id = ?',
    [merchantId]
  );

  const restaurant = restaurants.length > 0 ? restaurants[0] : {};

  // 构建时间线
  const timeline = [
    {
      time: merchant.created_at,
      status: '提交申请',
      description: '您已成功提交商家入驻申请'
    }
  ];

  if (merchant.status === 'pending') {
    timeline.push({
      time: merchant.updated_at || merchant.created_at,
      status: '资料审核中',
      description: '平台正在审核您的入驻资料'
    });
  } else if (merchant.status === 'approved') {
    timeline.push({
      time: merchant.updated_at,
      status: '审核通过',
      description: '恭喜您，审核已通过！'
    });
  } else if (merchant.status === 'rejected') {
    timeline.push({
      time: merchant.updated_at,
      status: '审核未通过',
      description: merchant.reject_reason || '资料不符合要求'
    });
  }

  // 格式化时间
  const formatTime = (date) => {
    if (!date) return null;
    const d = new Date(date);
    return d.toISOString().replace('T', ' ').substring(0, 19);
  };

  return {
    applicationId: merchant.id,
    submitTime: formatTime(merchant.created_at),
    shopName: merchant.business_name,
    contactName: merchant.contact_name,
    contactPhone: merchant.contact_phone,
    category: restaurant.category || '未设置',
    address: restaurant.address || merchant.address || '未设置',
    status: merchant.status,
    rejectReason: merchant.reject_reason,
    timeline: timeline.map(item => ({
      ...item,
      time: formatTime(item.time)
    }))
  };
};

/**
 * 接受订单
 */
exports.acceptOrder = async (merchantId, orderId) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 检查订单是否存在且属于该商家
    const [orders] = await connection.execute(
      'SELECT * FROM orders WHERE id = ? AND restaurant_id = ?',
      [orderId, merchantId]
    );

    if (orders.length === 0) {
      throw new Error('订单不存在或无权限操作');
    }

    const order = orders[0];

    // 检查订单状态是否为已支付
    if (order.status !== 'paid') {
      throw new Error(`订单当前状态为${order.status}，无法接单`);
    }

    // 更新订单状态为preparing（备餐中）
    await connection.execute(
      `UPDATE orders
       SET status = 'preparing',
           accept_time = NOW(),
           updated_at = NOW()
       WHERE id = ?`,
      [orderId]
    );

    await connection.commit();

    logger.info(`商家${merchantId}接受订单${orderId}`);

    return {
      orderId,
      status: 'preparing'
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 拒绝订单
 */
exports.rejectOrder = async (merchantId, orderId, reason) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 检查订单是否存在且属于该商家
    const [orders] = await connection.execute(
      'SELECT * FROM orders WHERE id = ? AND restaurant_id = ?',
      [orderId, merchantId]
    );

    if (orders.length === 0) {
      throw new Error('订单不存在或无权限操作');
    }

    const order = orders[0];

    if (order.status !== 'pending') {
      throw new Error(`订单当前状态为${order.status}，无法拒绝`);
    }

    // 更新订单状态为cancelled
    await connection.execute(
      `UPDATE orders
       SET status = 'cancelled',
           cancel_reason = ?,
           updated_at = NOW()
       WHERE id = ?`,
      [reason || '商家拒绝接单', orderId]
    );

    await connection.commit();

    logger.info(`商家${merchantId}拒绝订单${orderId}，原因：${reason}`);

    return {
      orderId,
      status: 'cancelled',
      reason: reason || '商家拒绝接单'
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 完成备餐
 */
exports.completePreparation = async (merchantId, orderId) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 检查订单是否存在且属于该商家
    const [orders] = await connection.execute(
      'SELECT * FROM orders WHERE id = ? AND restaurant_id = ?',
      [orderId, merchantId]
    );

    if (orders.length === 0) {
      throw new Error('订单不存在或无权限操作');
    }

    const order = orders[0];

    if (order.status !== 'preparing') {
      throw new Error(`订单当前状态为${order.status}，无法完成备餐`);
    }

    // 更新订单状态为ready（待取餐）
    await connection.execute(
      `UPDATE orders
       SET status = 'ready',
           prep_completed_at = NOW(),
           updated_at = NOW()
       WHERE id = ?`,
      [orderId]
    );

    await connection.commit();

    logger.info(`商家${merchantId}完成订单${orderId}备餐`);

    return {
      orderId,
      status: 'ready'
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 确认骑手取餐
 */
exports.confirmPickup = async (merchantId, orderId) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 检查订单是否存在且属于该商家
    const [orders] = await connection.execute(
      'SELECT * FROM orders WHERE id = ? AND restaurant_id = ?',
      [orderId, merchantId]
    );

    if (orders.length === 0) {
      throw new Error('订单不存在或无权限操作');
    }

    const order = orders[0];

    if (order.status !== 'ready') {
      throw new Error(`订单当前状态为${order.status}，无法确认取餐`);
    }

    // 更新订单状态为delivering（配送中）
    await connection.execute(
      `UPDATE orders
       SET status = 'delivering',
           pickup_time = NOW(),
           updated_at = NOW()
       WHERE id = ?`,
      [orderId]
    );

    await connection.commit();

    logger.info(`商家${merchantId}确认订单${orderId}已被取餐`);

    return {
      orderId,
      status: 'delivering'
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 获取商家每日统计数据
 */
exports.getDailyStatistics = async (merchantId, date) => {
  const startDate = new Date(date);
  startDate.setHours(0, 0, 0, 0);
  const endDate = new Date(date);
  endDate.setHours(23, 59, 59, 999);

  // 订单数量和总金额
  const [orderStats] = await db.execute(
    `SELECT
      COUNT(*) as orderCount,
      SUM(total_amount) as totalRevenue,
      AVG(total_amount) as avgPrice
     FROM orders
     WHERE restaurant_id = ?
       AND status IN ('completed', 'delivering', 'ready', 'preparing')
       AND created_at BETWEEN ? AND ?`,
    [merchantId, startDate, endDate]
  );

  const stats = orderStats[0];

  return {
    orderCount: stats.orderCount || 0,
    totalRevenue: parseFloat(stats.totalRevenue || 0).toFixed(2),
    avgPrice: parseFloat(stats.avgPrice || 0).toFixed(2),
    goodRating: 95.5, // TODO: 从评价系统计算
    peakHour: '12:00-13:00' // TODO: 从订单时间统计
  };
};

/**
 * 获取商家热销菜品
 */
exports.getHotDishes = async (merchantId, timeRange = 'week', limit = 10) => {
  // 计算时间范围
  const endDate = new Date();
  const startDate = new Date();

  switch (timeRange) {
    case 'today':
      startDate.setHours(0, 0, 0, 0);
      break;
    case 'week':
      startDate.setDate(startDate.getDate() - 7);
      break;
    case 'month':
      startDate.setDate(startDate.getDate() - 30);
      break;
    default:
      startDate.setDate(startDate.getDate() - 7);
  }

  // 查询热销菜品
  const limitValue = parseInt(limit) || 10;
  const [menu_items] = await db.execute(
    `SELECT
      d.id,
      d.name,
      d.price,
      COUNT(oi.id) as sales,
      SUM(oi.quantity * oi.price) as revenue
     FROM menu_items d
     LEFT JOIN order_items oi ON d.id = oi.menu_item_id
     LEFT JOIN orders o ON oi.order_id = o.id
     WHERE d.restaurant_id = ?
       AND o.created_at BETWEEN ? AND ?
       AND o.status IN ('completed', 'delivering', 'ready', 'preparing')
     GROUP BY d.id, d.name, d.price
     HAVING sales > 0
     ORDER BY sales DESC
     LIMIT ${limitValue}`,
    [merchantId, startDate, endDate]
  );

  return menu_items.map(dish => ({
    id: dish.id,
    name: dish.name,
    sales: dish.sales,
    revenue: parseFloat(dish.revenue || 0).toFixed(2),
    rating: 4.5 // TODO: 从评价系统获取实际评分
  }));
};

/**
 * 获取商家趋势数据（最近N天）
 */
exports.getTrendData = async (merchantId, days = 7) => {
  const trendData = [];

  for (let i = days - 1; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    date.setHours(0, 0, 0, 0);

    const endDate = new Date(date);
    endDate.setHours(23, 59, 59, 999);

    // 获取该天的订单统计
    const [stats] = await db.execute(
      `SELECT
        COUNT(*) as orderCount,
        COALESCE(SUM(total_amount), 0) as totalRevenue
       FROM orders
       WHERE restaurant_id = ?
         AND status IN ('completed', 'delivering', 'ready', 'preparing')
         AND created_at BETWEEN ? AND ?`,
      [merchantId, date, endDate]
    );

    trendData.push({
      date: `${date.getMonth() + 1}/${date.getDate()}`,
      orders: stats[0].orderCount || 0,
      revenue: parseFloat(stats[0].totalRevenue || 0).toFixed(2)
    });
  }

  return trendData;
};

