const db = require('../config/database');
const logger = require('../utils/logger');

/**
 * 获取用户地址列表
 */
exports.getAddressList = async (userId) => {
  const [rows] = await db.execute(
    'SELECT * FROM customer_addresses WHERE customer_id = ? ORDER BY is_default DESC, created_at DESC',
    [userId]
  );

  return rows.map(row => ({
    id: row.id,
    tag: row.tag,
    name: row.contact_name,
    phone: row.contact_phone,
    region: [row.province, row.city, row.district],
    detail: row.address,
    room: '', // customer_addresses 表没有room字段
    isDefault: row.is_default === 1,
    latitude: row.latitude,
    longitude: row.longitude
  }));
};

/**
 * 获取地址详情
 */
exports.getAddressDetail = async (addressId) => {
  const [rows] = await db.execute(
    'SELECT * FROM customer_addresses WHERE id = ?',
    [addressId]
  );

  if (rows.length === 0) {
    return null;
  }

  const row = rows[0];
  return {
    id: row.id,
    tag: row.tag,
    name: row.contact_name,
    phone: row.contact_phone,
    region: [row.province, row.city, row.district],
    detail: row.address,
    room: '',
    isDefault: row.is_default === 1,
    userId: row.customer_id,
    latitude: row.latitude,
    longitude: row.longitude
  };
};

/**
 * 创建地址
 */
exports.createAddress = async (addressData) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 如果设置为默认地址，先将该用户的其他地址设为非默认
    if (addressData.isDefault) {
      await connection.execute(
        'UPDATE customer_addresses SET is_default = 0 WHERE customer_id = ?',
        [addressData.userId]
      );
    }

    // 解析region数组 [省, 市, 区]
    const province = addressData.region?.[0] || '';
    const city = addressData.region?.[1] || '';
    const district = addressData.region?.[2] || '';

    const [result] = await connection.execute(
      `INSERT INTO customer_addresses (
        customer_id, contact_name, contact_phone, province, city, district,
        address, latitude, longitude, tag, is_default
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        addressData.userId,
        addressData.name,
        addressData.phone,
        province,
        city,
        district,
        addressData.detail,
        addressData.latitude || null,
        addressData.longitude || null,
        addressData.tag,
        addressData.isDefault ? 1 : 0
      ]
    );

    await connection.commit();

    logger.info(`地址创建成功: ${result.insertId}`);

    return {
      id: result.insertId,
      message: '地址创建成功'
    };

  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 更新地址
 */
exports.updateAddress = async (addressId, addressData) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 如果设置为默认地址，先将该用户的其他地址设为非默认
    if (addressData.isDefault) {
      await connection.execute(
        'UPDATE customer_addresses SET is_default = 0 WHERE customer_id = ?',
        [addressData.userId]
      );
    }

    // 解析region数组 [省, 市, 区]
    const province = addressData.region?.[0] || '';
    const city = addressData.region?.[1] || '';
    const district = addressData.region?.[2] || '';

    await connection.execute(
      `UPDATE customer_addresses SET
        tag = ?, contact_name = ?, contact_phone = ?, province = ?,
        city = ?, district = ?, address = ?, latitude = ?, longitude = ?, is_default = ?
      WHERE id = ?`,
      [
        addressData.tag,
        addressData.name,
        addressData.phone,
        province,
        city,
        district,
        addressData.detail,
        addressData.latitude || null,
        addressData.longitude || null,
        addressData.isDefault ? 1 : 0,
        addressId
      ]
    );

    await connection.commit();

    logger.info(`地址更新成功: ${addressId}`);

  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

/**
 * 删除地址
 */
exports.deleteAddress = async (addressId) => {
  await db.execute(
    'DELETE FROM customer_addresses WHERE id = ?',
    [addressId]
  );

  logger.info(`地址删除成功: ${addressId}`);
};

/**
 * 设置默认地址
 */
exports.setDefaultAddress = async (userId, addressId) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    // 先将该用户的所有地址设为非默认
    await connection.execute(
      'UPDATE customer_addresses SET is_default = 0 WHERE customer_id = ?',
      [userId]
    );

    // 设置指定地址为默认
    await connection.execute(
      'UPDATE customer_addresses SET is_default = 1 WHERE id = ? AND customer_id = ?',
      [addressId, userId]
    );

    await connection.commit();

    logger.info(`默认地址设置成功: ${addressId}`);

  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};
