const db = require('../config/database');
const logger = require('../utils/logger');

/**
 * 凑单建议服务
 */
class SuggestionService {
  /**
   * 获取凑单建议
   * @param {string} restaurantId - 餐厅ID
   * @param {number} currentAmount - 当前购物车金额
   * @param {Array} cartItemIds - 已在购物车的菜品ID列表（可选）
   * @returns {Object} 凑单建议结果
   */
  async getSuggestions(restaurantId, currentAmount, cartItemIds = []) {
    try {
      // 1. 从数据库查找餐厅信息
      const [restaurantRows] = await db.execute(
        'SELECT * FROM restaurants WHERE id = ? AND status = 1',
        [restaurantId]
      );

      if (restaurantRows.length === 0) {
        throw new Error('餐厅不存在');
      }

      const restaurant = restaurantRows[0];
      const minOrder = parseFloat(restaurant.min_order_amount) || 0;

      // 2. 如果已达起送价，返回空建议
      if (currentAmount >= minOrder) {
        return {
          needSuggestion: false,
          minOrder,
          currentAmount,
          gap: 0,
          suggestions: [],
          message: '已达起送价，可直接下单'
        };
      }

      // 3. 计算差额
      const gap = minOrder - currentAmount;

      // 4. 从数据库获取该餐厅的所有菜品
      const [menuItems] = await db.execute(
        'SELECT * FROM menu_items WHERE restaurant_id = ? AND is_available = 1',
        [restaurantId]
      );

      // 转换数据格式
      const restaurantMenu = menuItems.map(item => ({
        id: item.id.toString(),
        restaurantId: item.restaurant_id.toString(),
        name: item.name,
        price: parseFloat(item.price),
        monthSales: item.sales || 0,
        rating: 4.5, // 默认评分，后续可从评价表计算
        description: item.description
      }));

      // 5. 排除已在购物车的菜品
      const availableItems = restaurantMenu.filter(item => !cartItemIds.includes(item.id));

      // 6. 筛选合适的菜品（价格在差额±20元范围内）
      const suitableItems = availableItems.filter(item => {
        const price = item.price;
        return price >= gap * 0.5 && price <= gap * 1.5;
      });

      // 7. 计算每个菜品的推荐分数
      const scoredItems = suitableItems.map(item => {
        const priceScore = this._calculatePriceScore(item.price, gap);
        const popularityScore = this._calculatePopularityScore(item.monthSales, restaurantMenu);
        const ratingScore = (item.rating || 4.5) / 5;

        // 综合评分：价格匹配度40% + 受欢迎度30% + 评分30%
        const totalScore = priceScore * 0.4 + popularityScore * 0.3 + ratingScore * 0.3;

        // 判断推荐原因
        const reasons = this._generateReasons(item, gap, restaurantMenu);

        return {
          ...item,
          score: totalScore,
          reasons,
          willReachMinOrder: (currentAmount + item.price) >= minOrder
        };
      });

      // 8. 按分数排序，取前5个
      const topSuggestions = scoredItems
        .sort((a, b) => b.score - a.score)
        .slice(0, 5);

      return {
        needSuggestion: true,
        minOrder,
        currentAmount,
        gap,
        suggestions: topSuggestions,
        message: `还差¥${gap.toFixed(2)}即可起送`
      };

    } catch (error) {
      logger.error('获取凑单建议失败:', error);
      throw error;
    }
  }

  /**
   * 计算价格匹配分数
   * @private
   */
  _calculatePriceScore(price, gap) {
    const diff = Math.abs(price - gap);
    const maxDiff = gap * 0.5;

    // 价格越接近差额，分数越高
    if (diff === 0) return 1.0;
    if (diff > maxDiff) return 0.5;

    return 1.0 - (diff / maxDiff) * 0.5;
  }

  /**
   * 计算受欢迎度分数
   * @private
   */
  _calculatePopularityScore(monthSales, allItems) {
    if (!allItems || allItems.length === 0) return 0.5;

    const maxSales = Math.max(...allItems.map(item => item.monthSales || 0));
    if (maxSales === 0) return 0.5;

    return (monthSales || 0) / maxSales;
  }

  /**
   * 生成推荐理由
   * @private
   */
  _generateReasons(item, gap, allItems) {
    const reasons = [];

    // 价格合适
    const priceDiff = Math.abs(item.price - gap);
    if (priceDiff <= gap * 0.2) {
      reasons.push('价格刚好');
    }

    // 高销量
    const avgSales = allItems.reduce((sum, i) => sum + (i.monthSales || 0), 0) / allItems.length;
    if (item.monthSales > avgSales * 1.5) {
      reasons.push('人气很高');
    }

    // 高评分
    if (item.rating >= 4.7) {
      reasons.push('好评如潮');
    }

    // 月销量排行
    const sortedBySales = [...allItems].sort((a, b) => (b.monthSales || 0) - (a.monthSales || 0));
    const rank = sortedBySales.findIndex(i => i.id === item.id) + 1;
    if (rank <= 3 && rank > 0) {
      reasons.push(`销量TOP${rank}`);
    }

    return reasons;
  }

  /**
   * 获取组合建议（多个菜品组合达到起送价）
   * @param {string} restaurantId - 餐厅ID
   * @param {number} currentAmount - 当前购物车金额
   * @param {Array} cartItemIds - 已在购物车的菜品ID列表
   * @returns {Array} 组合建议列表
   */
  async getCombinationSuggestions(restaurantId, currentAmount, cartItemIds = []) {
    try {
      // 从数据库查找餐厅信息
      const [restaurantRows] = await db.execute(
        'SELECT * FROM restaurants WHERE id = ? AND status = 1',
        [restaurantId]
      );

      if (restaurantRows.length === 0) {
        throw new Error('餐厅不存在');
      }

      const restaurant = restaurantRows[0];
      const minOrder = parseFloat(restaurant.min_order_amount) || 0;
      const gap = minOrder - currentAmount;

      if (gap <= 0) {
        return [];
      }

      // 从数据库获取可用菜品
      const [menuItems] = await db.execute(
        'SELECT * FROM menu_items WHERE restaurant_id = ? AND is_available = 1',
        [restaurantId]
      );

      const availableItems = menuItems
        .filter(item => !cartItemIds.includes(item.id.toString()))
        .filter(item => parseFloat(item.price) <= gap * 1.2)
        .map(item => ({
          id: item.id.toString(),
          name: item.name,
          price: parseFloat(item.price),
          rating: 4.5
        }));

      // 查找二菜品组合
      const combinations = [];
      for (let i = 0; i < availableItems.length && combinations.length < 3; i++) {
        for (let j = i + 1; j < availableItems.length && combinations.length < 3; j++) {
          const item1 = availableItems[i];
          const item2 = availableItems[j];
          const totalPrice = item1.price + item2.price;

          if (totalPrice >= gap && totalPrice <= gap * 1.3) {
            const avgRating = (item1.rating + item2.rating) / 2;
            combinations.push({
              items: [item1, item2],
              totalPrice,
              avgRating,
              willReachMinOrder: (currentAmount + totalPrice) >= minOrder
            });
          }
        }
      }

      // 按平均评分排序
      return combinations.sort((a, b) => b.avgRating - a.avgRating).slice(0, 3);

    } catch (error) {
      logger.error('获取组合建议失败:', error);
      return [];
    }
  }
}

module.exports = new SuggestionService();
