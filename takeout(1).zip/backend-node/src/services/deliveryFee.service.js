/**
 * 动态配送费计算服务
 * 基于时段、天气、距离的实时配送费计算
 */

const { calculateDistance, getTimePeriod, getWeather } = require('../utils/geo');

class DeliveryFeeService {
  /**
   * 计算动态配送费
   * @param {object} params - 参数对象
   * @param {number} params.restaurantLat - 餐厅纬度
   * @param {number} params.restaurantLng - 餐厅经度
   * @param {number} params.userLat - 用户纬度
   * @param {number} params.userLng - 用户经度
   * @param {number} params.baseFee - 基础配送费（可选，默认3元）
   * @returns {object} - 配送费详情
   */
  calculateDeliveryFee({
    restaurantLat,
    restaurantLng,
    userLat,
    userLng,
    baseFee = 3
  }) {
    // 计算距离
    const distanceKm = calculateDistance(restaurantLat, restaurantLng, userLat, userLng);

    // 获取时段
    const timePeriod = getTimePeriod();

    // 获取天气（模拟）
    const weather = getWeather();

    // 基础配送费
    let totalFee = baseFee;
    const breakdown = {
      base: baseFee,
      distance: 0,
      timePeriod: 0,
      weather: 0
    };

    // 距离加价
    // 3km以内：不加价
    // 3-5km：加2元
    // 5km以上：每公里加1元
    if (distanceKm > 3 && distanceKm <= 5) {
      breakdown.distance = 2;
      totalFee += 2;
    } else if (distanceKm > 5) {
      const extraDistance = distanceKm - 5;
      breakdown.distance = 2 + Math.ceil(extraDistance) * 1;
      totalFee += breakdown.distance;
    }

    // 时段加价
    // 高峰时段（11:00-13:00, 17:30-19:30）：加1元
    // 深夜时段（22:00-06:00）：加2元
    if (timePeriod === 'peak') {
      breakdown.timePeriod = 1;
      totalFee += 1;
    } else if (timePeriod === 'late') {
      breakdown.timePeriod = 2;
      totalFee += 2;
    }

    // 天气加价
    // 下雨：加1元
    // 其他：不加价
    if (weather === 'rainy') {
      breakdown.weather = 1;
      totalFee += 1;
    }

    // 返回详细信息
    return {
      totalFee: parseFloat(totalFee.toFixed(2)),
      breakdown,
      details: {
        distance: parseFloat(distanceKm.toFixed(2)),
        timePeriod,
        weather,
        explanation: this.generateExplanation(distanceKm, timePeriod, weather, breakdown)
      }
    };
  }

  /**
   * 生成配送费说明
   */
  generateExplanation(distanceKm, timePeriod, weather, breakdown) {
    const parts = [];

    parts.push(`基础费：¥${breakdown.base}`);

    if (breakdown.distance > 0) {
      if (distanceKm > 5) {
        parts.push(`距离加价：¥${breakdown.distance}（配送距离${distanceKm.toFixed(1)}km）`);
      } else {
        parts.push(`距离加价：¥${breakdown.distance}（距离>3km）`);
      }
    }

    if (breakdown.timePeriod > 0) {
      const periodMap = {
        'peak': '高峰时段（11:00-13:00 或 17:30-19:30）',
        'late': '深夜时段（22:00-06:00）'
      };
      parts.push(`时段加价：¥${breakdown.timePeriod}（${periodMap[timePeriod]}）`);
    }

    if (breakdown.weather > 0) {
      parts.push(`天气加价：¥${breakdown.weather}（下雨天）`);
    }

    return parts;
  }

  /**
   * 批量计算多个餐厅的配送费
   */
  calculateBatchDeliveryFees(restaurants, userLat, userLng) {
    return restaurants.map(restaurant => ({
      restaurantId: restaurant.id,
      ...this.calculateDeliveryFee({
        restaurantLat: restaurant.lat,
        restaurantLng: restaurant.lng,
        userLat,
        userLng,
        baseFee: restaurant.deliveryFee || 3
      })
    }));
  }
}

module.exports = new DeliveryFeeService();
