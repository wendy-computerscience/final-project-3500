/**
 * 智能派单服务
 * 根据距离、骑手状态、顺路情况等因素智能分配订单
 */

const fs = require('fs').promises;
const path = require('path');
const db = require('../config/database');
const { calculateDistance } = require('../utils/geo');

class DispatchService {
  constructor() {
    this.couriers = [];
    this.orders = new Map();
    this.loadCouriers();
  }

  async loadCouriers() {
    try {
      const couriersPath = path.join(__dirname, '../data/couriers.json');
      const couriersData = await fs.readFile(couriersPath, 'utf-8');
      this.couriers = JSON.parse(couriersData);
    } catch (error) {
      console.error('加载骑手数据失败:', error);
    }
  }

  /**
   * ⭐智能派单 - 自动选择最优骑手
   * @param {object} params - 订单参数
   * @returns {object} - 派单结果
   */
  async assignOrder(params) {
    const { orderId, restaurantLat, restaurantLng, userLat, userLng } = params;

    // 筛选空闲骑手
    const availableCouriers = this.couriers.filter(c => c.status === 'IDLE');

    if (availableCouriers.length === 0) {
      return {
        success: false,
        message: '暂无可用骑手'
      };
    }

    // 计算每个骑手的匹配分数
    const scored = availableCouriers.map(courier => {
      // 骑手到餐厅的距离
      const distanceToRestaurant = calculateDistance(
        courier.lat,
        courier.lng,
        restaurantLat,
        restaurantLng
      );

      // 餐厅到用户的距离
      const deliveryDistance = calculateDistance(
        restaurantLat,
        restaurantLng,
        userLat,
        userLng
      );

      // 总距离
      const totalDistance = distanceToRestaurant + deliveryDistance;

      // 计算分数（距离越近越好，评分越高越好，准时率越高越好）
      const distanceScore = Math.max(0, 1 - distanceToRestaurant / 5); // 5km内
      const ratingScore = courier.rating / 5;
      const onTimeScore = courier.onTimeRate;

      const score =
        0.6 * distanceScore +
        0.2 * ratingScore +
        0.2 * onTimeScore;

      return {
        courierId: courier.id,
        name: courier.name,
        distanceToRestaurant,
        deliveryDistance,
        totalDistance,
        score,
        rating: courier.rating,
        onTimeRate: courier.onTimeRate
      };
    });

    // 按分数排序，选择最优骑手
    scored.sort((a, b) => b.score - a.score);
    const selected = scored[0];

    // 更新骑手状态
    const courierIndex = this.couriers.findIndex(c => c.id === selected.courierId);
    if (courierIndex !== -1) {
      this.couriers[courierIndex].status = 'ASSIGNED';
    }

    // 记录订单
    this.orders.set(orderId, {
      orderId,
      courierId: selected.courierId,
      status: 'ASSIGNED',
      assignedAt: Date.now()
    });

    return {
      success: true,
      data: {
        orderId,
        courierId: selected.courierId,
        courierName: selected.name,
        distanceToRestaurant: selected.distanceToRestaurant.toFixed(2),
        estimatedTime: Math.ceil((selected.distanceToRestaurant / 18) * 60), // 分钟
        score: selected.score.toFixed(3)
      }
    };
  }

  /**
   * ⭐获取骑手推荐订单列表（按距离/顺路/收入排序）
   */
  async getRecommendedOrders(courierId, courierLat, courierLng, sortBy = 'distance') {
    // 从数据库获取待接订单（状态为 pending_accept 或 paid，且未分配骑手）
    const [dbOrders] = await db.execute(
      `SELECT
         o.id as orderId,
         o.restaurant_id as restaurantId,
         r.name as restaurantName,
         r.latitude as restaurantLat,
         r.longitude as restaurantLng,
         o.latitude as userLat,
         o.longitude as userLng,
         o.delivery_fee as income,
         o.status,
         o.created_at
       FROM orders o
       LEFT JOIN restaurants r ON o.restaurant_id = r.id
       WHERE o.status IN ('pending_accept', 'paid')
         AND o.courier_id IS NULL
       ORDER BY o.created_at DESC
       LIMIT 50`
    );

    // 如果数据库没有订单，返回空数组
    if (dbOrders.length === 0) {
      return [];
    }

    const availableOrders = dbOrders.map(order => ({
      orderId: order.orderId,
      restaurantId: order.restaurantId,
      restaurantName: order.restaurantName || '未知餐厅',
      restaurantLat: parseFloat(order.restaurantLat) || 22.302,
      restaurantLng: parseFloat(order.restaurantLng) || 114.172,
      userLat: parseFloat(order.userLat) || 22.301,
      userLng: parseFloat(order.userLng) || 114.172,
      income: parseFloat(order.income) || 5,
      prepStatus: 'READY',
      isMock: false
    }));

    // 计算每个订单的详细信息
    const orders = availableOrders.map(order => {
      const pickupDistance = calculateDistance(
        courierLat,
        courierLng,
        order.restaurantLat,
        order.restaurantLng
      );

      const deliveryDistance = calculateDistance(
        order.restaurantLat,
        order.restaurantLng,
        order.userLat,
        order.userLng
      );

      const totalDistance = pickupDistance + deliveryDistance;
      const estimatedTime = Math.ceil((totalDistance / 18) * 60);

      // 检查是否顺路（简化逻辑）
      const isOnRoute = pickupDistance < 1.5;

      return {
        ...order,
        pickupDistance: parseFloat(pickupDistance.toFixed(2)),
        deliveryDistance: parseFloat(deliveryDistance.toFixed(2)),
        totalDistance: parseFloat(totalDistance.toFixed(2)),
        estimatedTime,
        isOnRoute,
        tags: []
      };
    });

    // 添加标签
    orders.forEach(order => {
      if (order.isOnRoute) {
        order.tags.push('顺路订单，多赚8元');
      }
      if (order.pickupDistance < 1) {
        order.tags.push(`距离${order.pickupDistance}km`);
      }
      if (order.prepStatus === 'READY') {
        order.tags.push('餐已备好');
      }
      if (order.income >= 12) {
        order.tags.push('高收入');
      }
    });

    // 排序
    if (sortBy === 'distance') {
      orders.sort((a, b) => a.totalDistance - b.totalDistance);
    } else if (sortBy === 'income') {
      orders.sort((a, b) => b.income - a.income);
    } else {
      // 智能推荐排序
      orders.sort((a, b) => {
        const scoreA = (a.isOnRoute ? 0.4 : 0) + (1 - a.totalDistance / 10) * 0.3 + (a.income / 20) * 0.3;
        const scoreB = (b.isOnRoute ? 0.4 : 0) + (1 - b.totalDistance / 10) * 0.3 + (b.income / 20) * 0.3;
        return scoreB - scoreA;
      });
    }

    return orders;
  }

  /**
   * 预测性派单通知
   */
  async getPredictiveNotification(courierId, courierLat, courierLng) {
    // 模拟：5分钟后预计有订单到骑手附近
    return {
      predicted: true,
      area: '科技园北区',
      incomeRange: '10-15元',
      estimatedMinutes: 5,
      message: '5分钟后预计有订单到您附近'
    };
  }
}

module.exports = new DispatchService();
