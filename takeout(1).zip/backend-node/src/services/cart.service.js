const db = require('../config/database');
const logger = require('../utils/logger');

/**
 * 购物车服务
 */
class CartService {
  /**
   * 获取用户购物车
   * @param {number} userId - 用户ID
   * @returns {Object} 购物车数据（按餐厅分组）
   */
  async getUserCart(userId) {
    try {
      // 查询用户的购物车项
      const [cartItems] = await db.execute(
        `SELECT
          ci.id AS cart_item_id,
          ci.restaurant_id,
          ci.menu_item_id,
          ci.quantity,
          m.name AS menu_item_name,
          m.price,
          m.description,
          m.image,
          r.name AS restaurant_name,
          r.min_order_amount,
          r.delivery_fee,
          r.avg_delivery_time AS avg_prep_min,
          r.latitude AS lat,
          r.longitude AS lng,
          r.merchant_id
        FROM cart_items ci
        JOIN menu_items m ON ci.menu_item_id = m.id
        JOIN restaurants r ON ci.restaurant_id = r.id
        WHERE ci.customer_id = ?
        ORDER BY ci.created_at DESC`,
        [userId]
      );

      if (cartItems.length === 0) {
        return {
          carts: []
        };
      }

      // 按餐厅分组
      const restaurantMap = new Map();

      cartItems.forEach(item => {
        const restaurantId = item.restaurant_id.toString();

        if (!restaurantMap.has(restaurantId)) {
          restaurantMap.set(restaurantId, {
            restaurantId,
            restaurantName: item.restaurant_name,
            restaurant: {
              lat: parseFloat(item.lat),
              lng: parseFloat(item.lng),
              minOrder: parseFloat(item.min_order_amount),
              deliveryFee: parseFloat(item.delivery_fee),
              avgPrepMin: item.avg_prep_min,
              merchantId: item.merchant_id
            },
            items: []
          });
        }

        restaurantMap.get(restaurantId).items.push({
          id: item.menu_item_id.toString(),
          cartItemId: item.cart_item_id,
          name: item.menu_item_name,
          price: parseFloat(item.price),
          quantity: item.quantity,
          description: item.description || '',
          image: item.image
        });
      });

      return {
        carts: Array.from(restaurantMap.values())
      };
    } catch (error) {
      logger.error('获取购物车失败:', error);
      throw error;
    }
  }

  /**
   * 添加或更新购物车项
   * @param {Object} params - 参数
   * @returns {Object} 操作结果
   */
  async addOrUpdateCartItem({ userId, restaurantId, menuItemId, quantity }) {
    const connection = await db.getConnection();

    try {
      await connection.beginTransaction();

      // 使用 INSERT ... ON DUPLICATE KEY UPDATE 避免并发竞态条件
      const [result] = await connection.execute(
        `INSERT INTO cart_items (customer_id, restaurant_id, menu_item_id, quantity)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity), updated_at = NOW()`,
        [userId, restaurantId, menuItemId, quantity]
      );

      await connection.commit();

      logger.info(`用户${userId}添加购物车成功: 菜品${menuItemId}, 数量${quantity}`);

      // 返回更新后的购物车
      return await this.getUserCart(userId);
    } catch (error) {
      await connection.rollback();
      logger.error('添加购物车失败:', error);
      throw error;
    } finally {
      connection.release();
    }
  }

  /**
   * 更新购物车项数量
   * @param {number} cartItemId - 购物车项ID
   * @param {number} quantity - 新数量
   * @param {number} userId - 用户ID
   * @returns {Object} 操作结果
   */
  async updateCartItemQuantity(cartItemId, quantity, userId) {
    try {
      if (quantity <= 0) {
        // 数量为0，删除该项
        await db.execute(
          `DELETE FROM cart_items WHERE id = ? AND customer_id = ?`,
          [cartItemId, userId]
        );
      } else {
        // 更新数量
        await db.execute(
          `UPDATE cart_items SET quantity = ?, updated_at = NOW()
           WHERE id = ? AND customer_id = ?`,
          [quantity, cartItemId, userId]
        );
      }

      logger.info(`用户${userId}更新购物车项${cartItemId}数量为${quantity}`);

      // 返回更新后的购物车
      return await this.getUserCart(userId);
    } catch (error) {
      logger.error('更新购物车失败:', error);
      throw error;
    }
  }

  /**
   * 删除购物车项
   * @param {number} cartItemId - 购物车项ID
   * @param {number} userId - 用户ID
   * @returns {Object} 操作结果
   */
  async removeCartItem(cartItemId, userId) {
    try {
      await db.execute(
        `DELETE FROM cart_items WHERE id = ? AND customer_id = ?`,
        [cartItemId, userId]
      );

      logger.info(`用户${userId}删除购物车项${cartItemId}`);

      // 返回更新后的购物车
      return await this.getUserCart(userId);
    } catch (error) {
      logger.error('删除购物车项失败:', error);
      throw error;
    }
  }

  /**
   * 清空用户购物车
   * @param {number} userId - 用户ID
   * @returns {Object} 操作结果
   */
  async clearCart(userId) {
    try {
      await db.execute(
        `DELETE FROM cart_items WHERE customer_id = ?`,
        [userId]
      );

      logger.info(`用户${userId}清空购物车`);

      return {
        success: true,
        message: '购物车已清空'
      };
    } catch (error) {
      logger.error('清空购物车失败:', error);
      throw error;
    }
  }
}

module.exports = new CartService();
