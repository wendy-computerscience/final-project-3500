/**
 * 路径优化服务
 * 为骑手提供多订单配送的最优路径规划
 * 使用贪心算法（最近邻）+ 约束条件优化
 */

const { calculateDistance } = require('../utils/geo');

class RouteOptimizationService {
  /**
   * 优化多订单配送路径
   * @param {object} params - 参数
   * @param {array} params.orders - 订单列表，每个订单包含 {orderId, pickupLat, pickupLng, dropLat, dropLng, prepTime}
   * @param {number} params.courierLat - 骑手当前纬度
   * @param {number} params.courierLng - 骑手当前经度
   * @returns {object} - 优化后的路径
   */
  optimizeRoute(params) {
    const { orders, courierLat, courierLng } = params;

    if (!orders || orders.length === 0) {
      return {
        success: false,
        message: '无订单需要优化'
      };
    }

    // 单个订单，直接返回简单路径
    if (orders.length === 1) {
      const order = orders[0];
      return {
        success: true,
        data: {
          sequence: [
            {
              type: 'PICKUP',
              orderId: order.orderId,
              lat: order.pickupLat,
              lng: order.pickupLng,
              index: 0
            },
            {
              type: 'DELIVERY',
              orderId: order.orderId,
              lat: order.dropLat,
              lng: order.dropLng,
              index: 1
            }
          ],
          totalDistance: this._calculatePathDistance([
            { lat: courierLat, lng: courierLng },
            { lat: order.pickupLat, lng: order.pickupLng },
            { lat: order.dropLat, lng: order.dropLng }
          ]),
          estimatedTime: this._estimateRouteTime([
            { lat: courierLat, lng: courierLng },
            { lat: order.pickupLat, lng: order.pickupLng },
            { lat: order.dropLat, lng: order.dropLng }
          ], [order.prepTime || 0])
        }
      };
    }

    // 多订单优化
    const optimized = this._optimizeMultiOrder(orders, courierLat, courierLng);

    return {
      success: true,
      data: optimized
    };
  }

  /**
   * 多订单路径优化（贪心算法 + 约束条件）
   */
  _optimizeMultiOrder(orders, startLat, startLng) {
    // 构建所有待访问点（取餐点 + 配送点）
    const points = [];
    const orderMap = new Map();

    orders.forEach(order => {
      const pickupPoint = {
        type: 'PICKUP',
        orderId: order.orderId,
        lat: order.pickupLat,
        lng: order.pickupLng,
        prepTime: order.prepTime || 0
      };

      const dropPoint = {
        type: 'DELIVERY',
        orderId: order.orderId,
        lat: order.dropLat,
        lng: order.dropLng,
        prepTime: 0
      };

      points.push(pickupPoint, dropPoint);
      orderMap.set(order.orderId, { pickup: pickupPoint, drop: dropPoint, pickedUp: false });
    });

    // 贪心算法：每次选择距离最近且满足约束的点
    const sequence = [];
    const visited = new Set();
    let currentLat = startLat;
    let currentLng = startLng;

    while (visited.size < points.length) {
      let nearestPoint = null;
      let minDistance = Infinity;

      // 找到最近的可访问点
      for (const point of points) {
        const pointKey = `${point.type}_${point.orderId}`;

        if (visited.has(pointKey)) {
          continue;
        }

        // 约束条件：必须先取餐才能送餐
        if (point.type === 'DELIVERY') {
          const order = orderMap.get(point.orderId);
          if (!order.pickedUp) {
            continue;
          }
        }

        const distance = calculateDistance(currentLat, currentLng, point.lat, point.lng);

        if (distance < minDistance) {
          minDistance = distance;
          nearestPoint = point;
        }
      }

      if (nearestPoint) {
        const pointKey = `${nearestPoint.type}_${nearestPoint.orderId}`;
        visited.add(pointKey);

        sequence.push({
          type: nearestPoint.type,
          orderId: nearestPoint.orderId,
          lat: nearestPoint.lat,
          lng: nearestPoint.lng,
          index: sequence.length,
          distance: minDistance
        });

        // 更新订单状态
        if (nearestPoint.type === 'PICKUP') {
          const order = orderMap.get(nearestPoint.orderId);
          order.pickedUp = true;
        }

        // 更新当前位置
        currentLat = nearestPoint.lat;
        currentLng = nearestPoint.lng;
      } else {
        // 没有可访问的点了（不应该发生）
        break;
      }
    }

    // 计算总距离和预计时间
    const pathPoints = [
      { lat: startLat, lng: startLng },
      ...sequence.map(s => ({ lat: s.lat, lng: s.lng }))
    ];

    const totalDistance = this._calculatePathDistance(pathPoints);
    const prepTimes = orders.map(o => o.prepTime || 0);
    const estimatedTime = this._estimateRouteTime(pathPoints, prepTimes);

    return {
      sequence,
      totalDistance: parseFloat(totalDistance.toFixed(2)),
      estimatedTime: Math.ceil(estimatedTime),
      savings: this._calculateSavings(orders, sequence, startLat, startLng)
    };
  }

  /**
   * 计算路径总距离
   */
  _calculatePathDistance(points) {
    let totalDistance = 0;

    for (let i = 0; i < points.length - 1; i++) {
      const distance = calculateDistance(
        points[i].lat,
        points[i].lng,
        points[i + 1].lat,
        points[i + 1].lng
      );
      totalDistance += distance;
    }

    return totalDistance;
  }

  /**
   * 估算路径总时间（分钟）
   */
  _estimateRouteTime(pathPoints, prepTimes) {
    const totalDistance = this._calculatePathDistance(pathPoints);
    const drivingTime = (totalDistance / 18) * 60; // 18km/h
    const maxPrepTime = Math.max(...prepTimes, 0);
    const stopTime = (pathPoints.length - 1) * 2; // 每个点停留2分钟

    return drivingTime + maxPrepTime + stopTime;
  }

  /**
   * 计算优化节省的距离
   */
  _calculateSavings(orders, optimizedSequence, startLat, startLng) {
    // 简单路径：按订单顺序依次取餐送餐
    const simplePathPoints = [{ lat: startLat, lng: startLng }];

    orders.forEach(order => {
      simplePathPoints.push({ lat: order.pickupLat, lng: order.pickupLng });
      simplePathPoints.push({ lat: order.dropLat, lng: order.dropLng });
    });

    const simpleDistance = this._calculatePathDistance(simplePathPoints);

    // 优化路径
    const optimizedPathPoints = [
      { lat: startLat, lng: startLng },
      ...optimizedSequence.map(s => ({ lat: s.lat, lng: s.lng }))
    ];

    const optimizedDistance = this._calculatePathDistance(optimizedPathPoints);

    const savedDistance = simpleDistance - optimizedDistance;
    const savedPercentage = (savedDistance / simpleDistance) * 100;

    return {
      savedDistance: parseFloat(savedDistance.toFixed(2)),
      savedPercentage: parseFloat(savedPercentage.toFixed(1)),
      simpleDistance: parseFloat(simpleDistance.toFixed(2)),
      optimizedDistance: parseFloat(optimizedDistance.toFixed(2))
    };
  }

  /**
   * 获取路径可视化数据（用于地图显示）
   */
  getRouteVisualization(optimizedRoute, courierLat, courierLng) {
    const { sequence } = optimizedRoute;

    const path = [
      [courierLat, courierLng],
      ...sequence.map(s => [s.lat, s.lng])
    ];

    const markers = sequence.map((point, index) => ({
      lat: point.lat,
      lng: point.lng,
      type: point.type,
      orderId: point.orderId,
      order: index + 1,
      label: point.type === 'PICKUP' ? `取餐 #${point.orderId}` : `送达 #${point.orderId}`
    }));

    return {
      path,
      markers
    };
  }

  /**
   * 实时路径调整（当骑手位置改变或新订单加入时）
   */
  adjustRoute(params) {
    const {
      currentSequence,
      completedPoints,
      courierLat,
      courierLng,
      newOrders = []
    } = params;

    // 过滤掉已完成的点
    const remainingPoints = currentSequence.filter(
      point => !completedPoints.includes(`${point.type}_${point.orderId}`)
    );

    // 将剩余点转换为订单格式
    const remainingOrders = [];
    const orderSet = new Set();

    remainingPoints.forEach(point => {
      if (!orderSet.has(point.orderId)) {
        orderSet.add(point.orderId);
        // 从原序列中找到对应的取餐和配送点
        const pickup = currentSequence.find(
          p => p.orderId === point.orderId && p.type === 'PICKUP'
        );
        const drop = currentSequence.find(
          p => p.orderId === point.orderId && p.type === 'DELIVERY'
        );

        if (pickup && drop) {
          remainingOrders.push({
            orderId: point.orderId,
            pickupLat: pickup.lat,
            pickupLng: pickup.lng,
            dropLat: drop.lat,
            dropLng: drop.lng,
            prepTime: 0
          });
        }
      }
    });

    // 加入新订单
    const allOrders = [...remainingOrders, ...newOrders];

    // 重新优化
    return this.optimizeRoute({
      orders: allOrders,
      courierLat,
      courierLng
    });
  }
}

module.exports = new RouteOptimizationService();
