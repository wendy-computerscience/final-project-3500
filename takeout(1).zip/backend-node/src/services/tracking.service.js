/**
 * 订单追踪服务
 * 管理订单状态、骑手位置、ETA等实时信息
 */

const fs = require('fs').promises;
const path = require('path');
const { calculateDistance, estimateETA } = require('../utils/geo');
const db = require('../config/database');

class TrackingService {
  constructor() {
    // 内存存储（Demo用）
    this.orders = new Map(); // orderId -> order
    this.courierLocations = new Map(); // courierId -> {lat, lng, ts}
    this.routes = null;
    this.loadRoutes();
  }

  async loadRoutes() {
    try {
      const routesPath = path.join(__dirname, '../data/routes.json');
      const routesData = await fs.readFile(routesPath, 'utf-8');
      this.routes = JSON.parse(routesData);
    } catch (error) {
      console.error('加载路线数据失败:', error);
      this.routes = {};
    }
  }

  /**
   * 创建模拟订单（用于测试）
   */
  createMockOrder(orderId, restaurantId, courierId, userLat, userLng) {
    const order = {
      orderId,
      restaurantId,
      courierId,
      status: 'IN_TRANSIT',
      pickupLat: 22.302,
      pickupLng: 114.172,
      dropLat: userLat,
      dropLng: userLng,
      etaMinutes: 18,
      createdAt: Date.now(),
      events: [
        { ts: Date.now() - 600000, type: 'ORDER_CREATED' },
        { ts: Date.now() - 500000, type: 'RESTAURANT_ACCEPT' },
        { ts: Date.now() - 300000, type: 'COURIER_ASSIGNED' },
        { ts: Date.now() - 60000, type: 'PICKED_UP' }
      ],
      lastSeenTs: Date.now()
    };

    this.orders.set(orderId, order);

    // 初始化骑手位置
    this.courierLocations.set(courierId, {
      lat: 22.302,
      lng: 114.171,
      ts: Date.now()
    });

    return order;
  }

  /**
   * 获取订单追踪信息
   */
  async getTrackingInfo(orderId) {
    // 首先从数据库获取真实订单状态
    const [rows] = await db.execute(
      'SELECT id, status, created_at, latitude, longitude FROM orders WHERE id = ?',
      [orderId]
    );

    if (rows.length === 0) {
      return { error: 'ORDER_NOT_FOUND', message: '订单不存在' };
    }

    const dbOrder = rows[0];

    // 检查订单是否处于可追踪状态
    const trackableStatuses = ['pending_pickup', 'delivering'];
    if (!trackableStatuses.includes(dbOrder.status)) {
      // 返回订单当前状态，但不返回骑手追踪信息
      return {
        orderId: dbOrder.id,
        status: dbOrder.status,
        courier: null,
        etaMinutes: null,
        lastSeenTs: null,
        events: [
          { ts: new Date(dbOrder.created_at).getTime(), type: 'ORDER_CREATED' }
        ],
        route: null,
        trackable: false,
        message: this.getStatusMessage(dbOrder.status)
      };
    }

    // 订单可追踪，获取或创建追踪信息
    let order = this.orders.get(orderId);

    // 如果内存中没有追踪信息，基于数据库订单创建
    if (!order) {
      order = {
        orderId,
        restaurantId: dbOrder.restaurant_id,
        courierId: 'c_01', // TODO: 从配送表获取真实骑手ID
        status: dbOrder.status === 'delivering' ? 'IN_TRANSIT' : 'PICKED_UP',
        pickupLat: 22.302,
        pickupLng: 114.172,
        dropLat: dbOrder.latitude || 22.301,
        dropLng: dbOrder.longitude || 114.172,
        etaMinutes: 18,
        createdAt: new Date(dbOrder.created_at).getTime(),
        events: [
          { ts: new Date(dbOrder.created_at).getTime(), type: 'ORDER_CREATED' }
        ],
        lastSeenTs: Date.now()
      };

      // 根据状态添加事件
      if (dbOrder.status === 'pending_pickup' || dbOrder.status === 'delivering') {
        order.events.push({ ts: Date.now() - 300000, type: 'COURIER_ASSIGNED' });
      }
      if (dbOrder.status === 'delivering') {
        order.events.push({ ts: Date.now() - 60000, type: 'PICKED_UP' });
      }

      this.orders.set(orderId, order);

      // 初始化骑手位置
      this.courierLocations.set(order.courierId, {
        lat: 22.302,
        lng: 114.171,
        ts: Date.now()
      });
    }

    const courierLocation = this.courierLocations.get(order.courierId);

    // 计算实时ETA
    if (courierLocation && order.status === 'IN_TRANSIT') {
      const distanceKm = calculateDistance(
        courierLocation.lat,
        courierLocation.lng,
        order.dropLat,
        order.dropLng
      );
      order.etaMinutes = Math.max(Math.ceil((distanceKm / 18) * 60), 3); // 假设骑手速度18km/h
    }

    return {
      orderId: order.orderId,
      status: order.status,
      courier: courierLocation
        ? {
            id: order.courierId,
            lat: courierLocation.lat,
            lng: courierLocation.lng
          }
        : null,
      etaMinutes: order.etaMinutes,
      lastSeenTs: order.lastSeenTs,
      events: order.events,
      route: {
        pickup: { lat: order.pickupLat, lng: order.pickupLng },
        drop: { lat: order.dropLat, lng: order.dropLng }
      },
      trackable: true
    };
  }

  /**
   * 获取状态提示信息
   */
  getStatusMessage(status) {
    const messages = {
      pending_payment: '订单待支付',
      paid: '订单已支付，等待商家确认',
      pending_accept: '等待商家接单',
      preparing: '商家备餐中',
      ready: '餐品已备好，等待骑手取餐',
      completed: '订单已完成',
      cancelled: '订单已取消'
    };
    return messages[status] || '订单处理中';
  }

  /**
   * 更新骑手位置
   */
  updateCourierLocation(orderId, courierId, lat, lng) {
    const ts = Date.now();

    // 更新骑手位置
    this.courierLocations.set(courierId, { lat, lng, ts });

    // 更新订单的最后更新时间
    const order = this.orders.get(orderId);
    if (order) {
      order.lastSeenTs = ts;

      // 检查是否到达
      const distanceToDestination = calculateDistance(
        lat,
        lng,
        order.dropLat,
        order.dropLng
      );

      if (distanceToDestination < 0.05 && order.status === 'IN_TRANSIT') {
        // 到达目的地（50米内）
        order.status = 'ARRIVING';
        order.events.push({ ts, type: 'ARRIVING' });
      }
    }

    return { success: true, ts };
  }

  /**
   * 获取订单路径（用于地图显示）
   */
  getOrderRoute(orderId) {
    // 从routes.json获取预定义路径
    if (this.routes && this.routes[orderId]) {
      return this.routes[orderId];
    }

    // 如果没有预定义路径，返回直线路径
    const order = this.orders.get(orderId);
    if (order) {
      return {
        pickup: { lat: order.pickupLat, lng: order.pickupLng },
        drop: { lat: order.dropLat, lng: order.dropLng },
        path: [
          [order.pickupLat, order.pickupLng],
          [order.dropLat, order.dropLng]
        ]
      };
    }

    return null;
  }

  /**
   * 获取所有订单（用于追踪页面列表）
   */
  getAllOrders() {
    return Array.from(this.orders.values());
  }
}

module.exports = new TrackingService();
