const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const logger = require('./utils/logger');

// 导入路由
const userRoutes = require('./routes/user.routes');
const orderRoutes = require('./routes/order.routes');
const merchantRoutes = require('./routes/merchant.routes');
const riderRoutes = require('./routes/rider.routes');
const recommendationRoutes = require('./routes/recommendation.routes');
const trackingRoutes = require('./routes/tracking.routes');
const dispatchRoutes = require('./routes/dispatch.routes');
const routeRoutes = require('./routes/route.routes');
const preparationRoutes = require('./routes/preparation.routes');
const suggestionRoutes = require('./routes/suggestion.routes');
const restaurantRoutes = require('./routes/restaurant.routes');
const addressRoutes = require('./routes/address.routes');
const couponRoutes = require('./routes/coupon.routes');
const dashboardRoutes = require('./routes/dashboard.routes');
const cartRoutes = require('./routes/cart.routes');

const app = express();

// 中间件
app.use(helmet()); // 安全头
app.use(cors()); // 跨域
app.use(express.json()); // JSON解析
app.use(express.urlencoded({ extended: true })); // URL编码
app.use(morgan('combined', { stream: { write: message => logger.info(message.trim()) } })); // 请求日志

// 健康检查
app.get('/', (req, res) => {
  res.json({
    service: process.env.APP_NAME,
    status: 'running',
    timestamp: new Date().toISOString()
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'healthy' });
});

// API路由
app.use('/api/users', userRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/merchants', merchantRoutes);
app.use('/api/riders', riderRoutes);
app.use('/api/reco', recommendationRoutes);
app.use('/api/track', trackingRoutes);
app.use('/api/dispatch', dispatchRoutes);
app.use('/api/route', routeRoutes);
app.use('/api/preparation', preparationRoutes);
app.use('/api/suggestion', suggestionRoutes);
app.use('/api/restaurants', restaurantRoutes);
app.use('/api/addresses', addressRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/cart', cartRoutes);

// 404处理
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: '接口不存在'
  });
});

// 错误处理
app.use((err, req, res, next) => {
  logger.error('服务器错误:', err);

  res.status(err.status || 500).json({
    success: false,
    message: err.message || '服务器内部错误',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

module.exports = app;
