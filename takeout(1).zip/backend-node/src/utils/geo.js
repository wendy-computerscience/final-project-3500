/**
 * 地理位置相关工具函数
 */

/**
 * 计算两个经纬度坐标之间的距离（单位：公里）
 * 使用 Haversine 公式
 */
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371; // 地球半径（公里）
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * 估算配送时间（ETA）
 * @param {number} distanceKm - 距离（公里）
 * @param {number} avgPrepMin - 平均出餐时间（分钟）
 * @param {number} speedKmh - 骑手速度（公里/小时）
 * @returns {number} - 预计送达时间（分钟）
 */
function estimateETA(distanceKm, avgPrepMin = 10, speedKmh = 18) {
  const deliveryMin = (distanceKm / speedKmh) * 60; // 配送时间（分钟）
  const bufferMin = 3; // 缓冲时间
  return Math.ceil(avgPrepMin + deliveryMin + bufferMin);
}

/**
 * 计算 Jaccard 相似度（用于口味匹配）
 * @param {Array} arr1 - 用户口味偏好
 * @param {Array} arr2 - 餐厅菜系
 * @returns {number} - 相似度（0-1）
 */
function jaccardSimilarity(arr1, arr2) {
  if (!arr1 || !arr2 || arr1.length === 0 || arr2.length === 0) {
    return 0;
  }

  const set1 = new Set(arr1);
  const set2 = new Set(arr2);

  const intersection = new Set([...set1].filter(x => set2.has(x)));
  const union = new Set([...set1, ...set2]);

  return intersection.size / union.size;
}

/**
 * 限制数值范围
 */
function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

/**
 * 根据当前时间判断时段
 * @returns {string} - 'peak' | 'normal' | 'late'
 */
function getTimePeriod() {
  const hour = new Date().getHours();

  // 高峰时段：11:00-13:00, 17:30-19:30
  if ((hour >= 11 && hour < 13) || (hour >= 17 && hour < 20)) {
    return 'peak';
  }

  // 深夜时段：22:00-次日06:00
  if (hour >= 22 || hour < 6) {
    return 'late';
  }

  return 'normal';
}

/**
 * 模拟天气获取（实际应接入天气API）
 * @returns {string} - 'sunny' | 'rainy' | 'cloudy'
 */
function getWeather() {
  const weather = ['sunny', 'sunny', 'sunny', 'cloudy', 'rainy'];
  return weather[Math.floor(Math.random() * weather.length)];
}

module.exports = {
  calculateDistance,
  estimateETA,
  jaccardSimilarity,
  clamp,
  getTimePeriod,
  getWeather
};
