const axios = require('axios');
const logger = require('./logger');

const ML_SERVICE_URL = process.env.PYTHON_ML_SERVICE_URL || 'http://localhost:8000';

/**
 * 调用Python ML服务 - ETA预测
 */
async function predictETA(data) {
  try {
    const response = await axios.post(`${ML_SERVICE_URL}/api/eta/predict`, data, {
      timeout: 5000
    });
    return response.data;
  } catch (error) {
    logger.error('调用ETA预测服务失败:', error.message);
    // 降级：使用简单规则
    return fallbackETACalculation(data);
  }
}

/**
 * 调用Python ML服务 - 智能派单
 */
async function recommendRiders(data) {
  try {
    const response = await axios.post(`${ML_SERVICE_URL}/api/dispatch/recommend`, data, {
      timeout: 5000
    });
    return response.data;
  } catch (error) {
    logger.error('调用派单服务失败:', error.message);
    throw error;
  }
}

/**
 * 调用Python ML服务 - 动态定价
 */
async function calculateDeliveryFee(data) {
  try {
    const response = await axios.post(`${ML_SERVICE_URL}/api/pricing/calculate`, data, {
      timeout: 5000
    });
    return response.data;
  } catch (error) {
    logger.error('调用定价服务失败:', error.message);
    // 降级：使用固定价格
    return {
      delivery_fee: 5.0,
      breakdown: { base_fee: 5.0 },
      surge_multiplier: 1.0
    };
  }
}

/**
 * 调用Python ML服务 - 路径优化
 */
async function optimizeRoute(data) {
  try {
    const response = await axios.post(`${ML_SERVICE_URL}/api/route/optimize`, data, {
      timeout: 5000
    });
    return response.data;
  } catch (error) {
    logger.error('调用路径优化服务失败:', error.message);
    throw error;
  }
}

/**
 * ETA降级计算（简单规则）
 */
function fallbackETACalculation(data) {
  const baseTime = 15; // 基础时间
  const distanceTime = data.distance * 3; // 每公里3分钟
  const totalTime = Math.round(baseTime + distanceTime);

  return {
    eta_minutes: totalTime,
    confidence: 'low',
    breakdown: {
      prep_time: baseTime,
      delivery_time: Math.round(distanceTime)
    }
  };
}

module.exports = {
  predictETA,
  recommendRiders,
  calculateDeliveryFee,
  optimizeRoute
};
