-- ========================================
-- 外卖平台数据库初始化脚本
-- 包含：数据库创建 + 表结构定义
-- ========================================

-- 创建数据库
DROP DATABASE IF EXISTS takeaway_platform;
CREATE DATABASE IF NOT EXISTS takeaway_platform DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE takeaway_platform;

-- ========================================
-- 1. 后台管理系统相关表
-- ========================================

-- 后台管理员表
DROP TABLE IF EXISTS `admin_users`;
CREATE TABLE `admin_users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（加密）',
  `real_name` VARCHAR(50) DEFAULT NULL COMMENT '真实姓名',
  `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `phone` VARCHAR(20) DEFAULT NULL COMMENT '手机号',
  `role` ENUM('super_admin', 'admin', 'operator') NOT NULL DEFAULT 'operator' COMMENT '角色：超级管理员/管理员/运营',
  `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '状态：1-启用，0-禁用',
  `last_login_time` DATETIME DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` VARCHAR(50) DEFAULT NULL COMMENT '最后登录IP',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='后台管理员表';

-- ========================================
-- 2. 用户相关表
-- ========================================

-- 客户表
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '客户ID',
  `username` VARCHAR(50) NOT NULL COMMENT '登录账号',
  `phone` VARCHAR(20) DEFAULT NULL COMMENT '手机号（选填）',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（明文存储）',
  `nickname` VARCHAR(50) DEFAULT NULL COMMENT '昵称',
  `avatar` VARCHAR(255) DEFAULT NULL COMMENT '头像URL',
  `gender` TINYINT(1) DEFAULT NULL COMMENT '性别：0-女，1-男',
  `birthday` DATE DEFAULT NULL COMMENT '生日',
  `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `points` INT NOT NULL DEFAULT 0 COMMENT '积分',
  `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '状态：1-正常，0-禁用',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_phone` (`phone`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客户表（账号密码登录）';

-- 客户地址表
DROP TABLE IF EXISTS `customer_addresses`;
CREATE TABLE `customer_addresses` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '地址ID',
  `customer_id` INT UNSIGNED NOT NULL COMMENT '客户ID',
  `contact_name` VARCHAR(50) NOT NULL COMMENT '联系人姓名',
  `contact_phone` VARCHAR(20) NOT NULL COMMENT '联系电话',
  `province` VARCHAR(50) NOT NULL COMMENT '省份',
  `city` VARCHAR(50) NOT NULL COMMENT '城市',
  `district` VARCHAR(50) NOT NULL COMMENT '区县',
  `address` VARCHAR(255) NOT NULL COMMENT '详细地址',
  `latitude` DECIMAL(10,6) DEFAULT NULL COMMENT '纬度',
  `longitude` DECIMAL(10,6) DEFAULT NULL COMMENT '经度',
  `tag` VARCHAR(20) DEFAULT NULL COMMENT '标签：家/公司/学校',
  `is_default` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否默认地址：1-是，0-否',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_is_default` (`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客户地址表';

-- 商家表（即时注册，无需审核）
DROP TABLE IF EXISTS `merchants`;
CREATE TABLE `merchants` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '商家ID',
  `username` VARCHAR(50) NOT NULL COMMENT '登录账号',
  `phone` VARCHAR(20) DEFAULT NULL COMMENT '联系手机号（选填）',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（bcrypt加密）',
  `business_name` VARCHAR(100) NOT NULL COMMENT '商家名称',
  `contact_name` VARCHAR(50) NOT NULL COMMENT '联系人姓名',
  `contact_phone` VARCHAR(20) NOT NULL COMMENT '联系电话',
  `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `legal_name` VARCHAR(50) DEFAULT NULL COMMENT '法人姓名',
  `id_number` VARCHAR(18) DEFAULT NULL COMMENT '身份证号',
  `id_card_front` VARCHAR(255) DEFAULT NULL COMMENT '身份证正面URL',
  `id_card_back` VARCHAR(255) DEFAULT NULL COMMENT '身份证背面URL',
  `business_license` VARCHAR(255) DEFAULT NULL COMMENT '营业执照URL',
  `license_number` VARCHAR(100) DEFAULT NULL COMMENT '营业执照号',
  `food_license` VARCHAR(255) DEFAULT NULL COMMENT '食品经营许可证URL',
  `food_license_number` VARCHAR(100) DEFAULT NULL COMMENT '食品许可证号',
  `status` ENUM('pending', 'approved', 'rejected', 'disabled') NOT NULL DEFAULT 'approved' COMMENT '状态：即时通过/已通过/已拒绝/已禁用',
  `reject_reason` TEXT DEFAULT NULL COMMENT '拒绝原因',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_phone` (`phone`),
  KEY `idx_status` (`status`),
  KEY `idx_id_number` (`id_number`),
  KEY `idx_license_number` (`license_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商家表';

-- 骑手表
DROP TABLE IF EXISTS `couriers`;
CREATE TABLE `couriers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '骑手ID',
  `username` VARCHAR(50) NOT NULL COMMENT '登录账号',
  `phone` VARCHAR(20) DEFAULT NULL COMMENT '联系手机号（选填）',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（明文存储）',
  `real_name` VARCHAR(50) NOT NULL COMMENT '真实姓名',
  `id_card` VARCHAR(18) NOT NULL COMMENT '身份证号',
  `avatar` VARCHAR(255) DEFAULT NULL COMMENT '头像URL',
  `vehicle_type` ENUM('bicycle', 'ebike', 'motorcycle') DEFAULT 'ebike' COMMENT '车辆类型：自行车/电动车/摩托车',
  `vehicle_number` VARCHAR(20) DEFAULT NULL COMMENT '车牌号',
  `latitude` DECIMAL(10,6) DEFAULT NULL COMMENT '当前纬度',
  `longitude` DECIMAL(10,6) DEFAULT NULL COMMENT '当前经度',
  `is_online` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否在线：1-在线，0-离线',
  `is_busy` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否繁忙：1-繁忙，0-空闲',
  `rating` DECIMAL(3,2) DEFAULT 5.00 COMMENT '评分（0-5）',
  `total_orders` INT NOT NULL DEFAULT 0 COMMENT '总订单数',
  `on_time_rate` DECIMAL(5,2) DEFAULT 100.00 COMMENT '准时率（%）',
  `balance` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '账户余额',
  `status` ENUM('pending', 'approved', 'rejected', 'disabled') NOT NULL DEFAULT 'pending' COMMENT '状态：待审核/已通过/已拒绝/已禁用',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_id_card` (`id_card`),
  KEY `idx_phone` (`phone`),
  KEY `idx_is_online` (`is_online`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='骑手表';

-- ========================================
-- 3. 餐厅和菜品相关表
-- ========================================

-- 餐厅表
DROP TABLE IF EXISTS `restaurants`;
CREATE TABLE `restaurants` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '餐厅ID',
  `merchant_id` INT UNSIGNED NOT NULL COMMENT '商家ID',
  `name` VARCHAR(100) NOT NULL COMMENT '餐厅名称',
  `logo` VARCHAR(255) DEFAULT NULL COMMENT '餐厅logo',
  `phone` VARCHAR(20) NOT NULL COMMENT '餐厅电话',
  `address` VARCHAR(255) NOT NULL COMMENT '餐厅地址',
  `latitude` DECIMAL(10,6) NOT NULL COMMENT '纬度',
  `longitude` DECIMAL(10,6) NOT NULL COMMENT '经度',
  `category` VARCHAR(50) DEFAULT NULL COMMENT '分类：中餐/西餐/快餐/饮品等',
  `tags` VARCHAR(255) DEFAULT NULL COMMENT '标签（JSON格式）',
  `description` TEXT DEFAULT NULL COMMENT '餐厅介绍',
  `business_hours` VARCHAR(100) DEFAULT NULL COMMENT '营业时间',
  `min_order_amount` DECIMAL(10,2) DEFAULT 0.00 COMMENT '起送价',
  `delivery_fee` DECIMAL(10,2) DEFAULT 0.00 COMMENT '配送费',
  `rating` DECIMAL(3,2) DEFAULT 5.00 COMMENT '评分（0-5）',
  `total_sales` INT NOT NULL DEFAULT 0 COMMENT '总销量',
  `avg_delivery_time` INT DEFAULT 30 COMMENT '平均配送时间（分钟）',
  `is_open` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否营业：1-营业，0-休息',
  `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '状态：1-正常，0-禁用',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_merchant_id` (`merchant_id`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`),
  KEY `idx_location` (`latitude`, `longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='餐厅表';

-- 菜品分类表
DROP TABLE IF EXISTS `menu_categories`;
CREATE TABLE `menu_categories` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `restaurant_id` INT UNSIGNED NOT NULL COMMENT '餐厅ID',
  `name` VARCHAR(50) NOT NULL COMMENT '分类名称',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_restaurant_id` (`restaurant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='菜品分类表';

-- 菜品表
DROP TABLE IF EXISTS `menu_items`;
CREATE TABLE `menu_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '菜品ID',
  `restaurant_id` INT UNSIGNED NOT NULL COMMENT '餐厅ID',
  `category_id` INT UNSIGNED DEFAULT NULL COMMENT '分类ID',
  `name` VARCHAR(100) NOT NULL COMMENT '菜品名称',
  `image` VARCHAR(255) DEFAULT NULL COMMENT '菜品图片',
  `description` TEXT DEFAULT NULL COMMENT '菜品描述',
  `price` DECIMAL(10,2) NOT NULL COMMENT '价格',
  `original_price` DECIMAL(10,2) DEFAULT NULL COMMENT '原价',
  `unit` VARCHAR(20) DEFAULT '份' COMMENT '单位',
  `stock` INT DEFAULT NULL COMMENT '库存（NULL表示无限）',
  `sales` INT NOT NULL DEFAULT 0 COMMENT '销量',
  `is_available` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否可售：1-可售，0-售罄',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_restaurant_id` (`restaurant_id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_is_available` (`is_available`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='菜品表';

-- ========================================
-- 4. 订单相关表
-- ========================================

-- 订单表
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` VARCHAR(32) NOT NULL COMMENT '订单号',
  `customer_id` INT UNSIGNED NOT NULL COMMENT '客户ID',
  `restaurant_id` INT UNSIGNED NOT NULL COMMENT '餐厅ID',
  `courier_id` INT UNSIGNED DEFAULT NULL COMMENT '骑手ID',
  `delivery_address_id` INT UNSIGNED NOT NULL COMMENT '收货地址ID',
  `contact_name` VARCHAR(50) NOT NULL COMMENT '联系人姓名',
  `contact_phone` VARCHAR(20) NOT NULL COMMENT '联系电话',
  `delivery_address` VARCHAR(255) NOT NULL COMMENT '详细地址',
  `latitude` DECIMAL(10,6) NOT NULL COMMENT '纬度',
  `longitude` DECIMAL(10,6) NOT NULL COMMENT '经度',
  `total_amount` DECIMAL(10,2) NOT NULL COMMENT '商品总额',
  `delivery_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '配送费',
  `package_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '包装费',
  `discount_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '优惠金额',
  `final_amount` DECIMAL(10,2) NOT NULL COMMENT '实付金额',
  `payment_method` ENUM('wechat', 'alipay') NOT NULL COMMENT '支付方式',
  `remark` VARCHAR(255) DEFAULT NULL COMMENT '备注',
  `status` ENUM('pending_payment', 'paid', 'pending_accept', 'preparing', 'ready', 'pending_pickup', 'delivering', 'completed', 'cancelled') NOT NULL DEFAULT 'pending_payment' COMMENT '订单状态',
  `cancel_reason` VARCHAR(255) DEFAULT NULL COMMENT '取消原因',
  `canceled_at` DATETIME DEFAULT NULL COMMENT '订单取消时间',
  `paid_at` DATETIME DEFAULT NULL COMMENT '支付时间',
  `refund_reason` VARCHAR(255) DEFAULT NULL COMMENT '退款原因',
  `refund_requested_at` DATETIME DEFAULT NULL COMMENT '退款请求时间',
  `deleted_at` DATETIME DEFAULT NULL COMMENT '删除时间',
  `estimated_delivery_time` DATETIME DEFAULT NULL COMMENT '预计送达时间',
  `estimated_prep_time` INT DEFAULT NULL COMMENT '预计备餐时长（分钟）',
  `accept_time` DATETIME DEFAULT NULL COMMENT '商家接单时间',
  `preparation_time` DATETIME DEFAULT NULL COMMENT '出餐时间',
  `prep_completed_at` DATETIME DEFAULT NULL COMMENT '备餐完成时间',
  `pickup_time` DATETIME DEFAULT NULL COMMENT '取餐时间',
  `delivery_time` DATETIME DEFAULT NULL COMMENT '送达时间',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '下单时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_restaurant_id` (`restaurant_id`),
  KEY `idx_courier_id` (`courier_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表';

-- 订单明细表
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '明细ID',
  `order_id` INT UNSIGNED NOT NULL COMMENT '订单ID',
  `menu_item_id` INT UNSIGNED NOT NULL COMMENT '菜品ID',
  `name` VARCHAR(100) NOT NULL COMMENT '菜品名称',
  `image` VARCHAR(255) DEFAULT NULL COMMENT '菜品图片',
  `price` DECIMAL(10,2) NOT NULL COMMENT '单价',
  `quantity` INT NOT NULL COMMENT '数量',
  `subtotal` DECIMAL(10,2) NOT NULL COMMENT '小计',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_menu_item_id` (`menu_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单明细表';

-- 订单追踪表
DROP TABLE IF EXISTS `order_tracking`;
CREATE TABLE `order_tracking` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '追踪ID',
  `order_id` INT UNSIGNED NOT NULL COMMENT '订单ID',
  `courier_latitude` DECIMAL(10,6) DEFAULT NULL COMMENT '骑手纬度',
  `courier_longitude` DECIMAL(10,6) DEFAULT NULL COMMENT '骑手经度',
  `estimated_time` INT DEFAULT NULL COMMENT '预计送达时间（分钟）',
  `distance` DECIMAL(10,2) DEFAULT NULL COMMENT '距离（公里）',
  `status` VARCHAR(50) DEFAULT NULL COMMENT '状态描述',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单追踪表';

-- ========================================
-- 5. 评价相关表
-- ========================================

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '评价ID',
  `order_id` INT UNSIGNED NOT NULL COMMENT '订单ID',
  `customer_id` INT UNSIGNED NOT NULL COMMENT '客户ID',
  `restaurant_id` INT UNSIGNED NOT NULL COMMENT '餐厅ID',
  `courier_id` INT UNSIGNED DEFAULT NULL COMMENT '骑手ID',
  `food_rating` TINYINT(1) NOT NULL COMMENT '菜品评分（1-5）',
  `service_rating` TINYINT(1) NOT NULL COMMENT '服务评分（1-5）',
  `delivery_rating` TINYINT(1) DEFAULT NULL COMMENT '配送评分（1-5）',
  `content` TEXT DEFAULT NULL COMMENT '评价内容',
  `images` TEXT DEFAULT NULL COMMENT '评价图片（JSON格式）',
  `reply` TEXT DEFAULT NULL COMMENT '商家回复',
  `reply_time` DATETIME DEFAULT NULL COMMENT '回复时间',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '评价时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_id` (`order_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_restaurant_id` (`restaurant_id`),
  KEY `idx_courier_id` (`courier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评价表';

-- ========================================
-- 6. 优惠券相关表（统一使用customer_id）
-- ========================================

-- 优惠券模板表
DROP TABLE IF EXISTS `coupon_templates`;
CREATE TABLE `coupon_templates` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '优惠券模板ID',
  `name` VARCHAR(100) NOT NULL COMMENT '优惠券名称',
  `amount` DECIMAL(10,2) NOT NULL COMMENT '优惠金额',
  `min_order_amount` DECIMAL(10,2) DEFAULT 0.00 COMMENT '最低消费金额',
  `type` ENUM('new_user', 'discount', 'full_reduce') NOT NULL COMMENT '类型：新人券/折扣券/满减券',
  `total_quantity` INT NOT NULL COMMENT '总数量',
  `remaining_quantity` INT NOT NULL COMMENT '剩余数量',
  `valid_days` INT NOT NULL DEFAULT 30 COMMENT '有效天数',
  `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active' COMMENT '状态',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券模板表';

-- 用户优惠券表（统一使用customer_id）
DROP TABLE IF EXISTS `user_coupons`;
CREATE TABLE `user_coupons` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户优惠券ID',
  `customer_id` INT UNSIGNED NOT NULL COMMENT '客户ID',
  `coupon_template_id` INT UNSIGNED NOT NULL COMMENT '优惠券模板ID',
  `amount` DECIMAL(10,2) NOT NULL COMMENT '优惠金额',
  `min_order_amount` DECIMAL(10,2) DEFAULT 0.00 COMMENT '最低消费金额',
  `status` ENUM('unused', 'used', 'expired') NOT NULL DEFAULT 'unused' COMMENT '状态',
  `expiry_date` DATETIME NOT NULL COMMENT '过期时间',
  `used_at` DATETIME DEFAULT NULL COMMENT '使用时间',
  `order_id` INT UNSIGNED DEFAULT NULL COMMENT '使用的订单ID',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '领取时间',
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expiry_date` (`expiry_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户优惠券表';

-- 可领取优惠券表
DROP TABLE IF EXISTS `available_coupons`;
CREATE TABLE `available_coupons` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '优惠券ID',
  `amount` DECIMAL(10,2) NOT NULL COMMENT '优惠金额',
  `condition_key` VARCHAR(100) NOT NULL COMMENT '使用条件i18n键',
  `scope_key` VARCHAR(100) NOT NULL COMMENT '适用范围i18n键',
  `expiry_key` VARCHAR(100) NOT NULL COMMENT '有效期i18n键',
  `remaining` INT NOT NULL COMMENT '剩余数量',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否激活',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='可领取优惠券表';

-- 原始优惠券表（保留用于兼容）
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '优惠券ID',
  `name` VARCHAR(100) NOT NULL COMMENT '优惠券名称',
  `type` ENUM('discount', 'deduction', 'shipping') NOT NULL COMMENT '类型：折扣/满减/免配送费',
  `discount` DECIMAL(3,2) DEFAULT NULL COMMENT '折扣（0.1-1.0）',
  `deduction` DECIMAL(10,2) DEFAULT NULL COMMENT '减免金额',
  `min_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '最低消费金额',
  `max_discount` DECIMAL(10,2) DEFAULT NULL COMMENT '最高优惠金额',
  `total_quantity` INT NOT NULL COMMENT '总发放量',
  `remaining_quantity` INT NOT NULL COMMENT '剩余数量',
  `valid_from` DATETIME NOT NULL COMMENT '有效期开始',
  `valid_to` DATETIME NOT NULL COMMENT '有效期结束',
  `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '状态：1-启用，0-禁用',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_valid_time` (`valid_from`, `valid_to`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券表（旧版）';

-- ========================================
-- 7. 骑手任务相关表
-- ========================================

DROP TABLE IF EXISTS `rider_tasks`;
CREATE TABLE `rider_tasks` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `courier_id` INT UNSIGNED NOT NULL COMMENT '骑手ID',
  `title_key` VARCHAR(100) NOT NULL COMMENT '任务标题i18n键',
  `description_key` VARCHAR(200) DEFAULT NULL COMMENT '任务描述i18n键',
  `task_type` ENUM('daily', 'weekly') NOT NULL DEFAULT 'daily' COMMENT '任务类型：每日/每周',
  `progress_current` INT NOT NULL DEFAULT 0 COMMENT '当前进度',
  `progress_target` INT NOT NULL COMMENT '目标进度',
  `reward` DECIMAL(10,2) NOT NULL COMMENT '奖励金额',
  `status` ENUM('inprogress', 'claimable', 'completed') NOT NULL DEFAULT 'inprogress' COMMENT '任务状态：进行中/可领取/已完成',
  `claimed_at` DATETIME DEFAULT NULL COMMENT '领取奖励时间',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_courier_id` (`courier_id`),
  KEY `idx_status` (`status`),
  KEY `idx_task_type` (`task_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='骑手任务表';

-- ========================================
-- 8. 骑手提现相关表
-- ========================================

DROP TABLE IF EXISTS `withdrawal_records`;
CREATE TABLE `withdrawal_records` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '提现记录ID',
  `courier_id` INT UNSIGNED NOT NULL COMMENT '骑手ID',
  `amount` DECIMAL(10,2) NOT NULL COMMENT '提现金额',
  `status` ENUM('pending', 'approved', 'rejected', 'completed') NOT NULL DEFAULT 'pending' COMMENT '提现状态：待审核/已通过/已拒绝/已完成',
  `bank_account` VARCHAR(100) DEFAULT NULL COMMENT '银行账号',
  `bank_name` VARCHAR(100) DEFAULT NULL COMMENT '银行名称',
  `real_name` VARCHAR(50) DEFAULT NULL COMMENT '真实姓名',
  `reject_reason` VARCHAR(200) DEFAULT NULL COMMENT '拒绝原因',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
  `approved_at` DATETIME DEFAULT NULL COMMENT '审核通过时间',
  `completed_at` DATETIME DEFAULT NULL COMMENT '到账完成时间',
  PRIMARY KEY (`id`),
  KEY `idx_courier_id` (`courier_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='提现记录表';

-- ========================================
-- 9. 系统日志表
-- ========================================

DROP TABLE IF EXISTS `system_logs`;
CREATE TABLE `system_logs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` INT UNSIGNED DEFAULT NULL COMMENT '用户ID',
  `user_type` ENUM('admin', 'merchant', 'customer', 'courier') DEFAULT NULL COMMENT '用户类型',
  `action` VARCHAR(100) NOT NULL COMMENT '操作',
  `module` VARCHAR(50) NOT NULL COMMENT '模块',
  `ip` VARCHAR(50) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` VARCHAR(255) DEFAULT NULL COMMENT 'User Agent',
  `request_data` TEXT DEFAULT NULL COMMENT '请求数据',
  `response_data` TEXT DEFAULT NULL COMMENT '响应数据',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`, `user_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统日志表';

-- ========================================
-- 购物车表
-- ========================================

CREATE TABLE IF NOT EXISTS `cart_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id` INT UNSIGNED NOT NULL COMMENT '用户ID',
  `restaurant_id` INT UNSIGNED NOT NULL COMMENT '餐厅ID',
  `menu_item_id` INT UNSIGNED NOT NULL COMMENT '菜品ID',
  `quantity` INT NOT NULL DEFAULT 1 COMMENT '数量',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_customer_menu_item` (`customer_id`, `menu_item_id`),
  INDEX `idx_customer_restaurant` (`customer_id`, `restaurant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='购物车';

-- ========================================
-- 红包表
-- ========================================

CREATE TABLE IF NOT EXISTS `red_packets` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id` INT UNSIGNED NOT NULL COMMENT '用户ID',
  `balance` DECIMAL(10, 2) NOT NULL DEFAULT 0.00 COMMENT '红包余额',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户红包';
