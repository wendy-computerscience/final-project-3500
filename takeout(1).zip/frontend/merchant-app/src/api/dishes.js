import client from './client';

/**
 * 获取菜品列表
 * @param {string} merchantId - 商家ID
 * @param {Object} params - 查询参数（分页、分类等）
 * @returns {Promise<Object>} 菜品列表
 */
export const getDishes = async (merchantId, params = {}) => {
  const response = await client.get(`/merchants/${merchantId}/dishes`, {
    params,
  });
  return response;
};

/**
 * 获取菜品详情
 * @param {string} merchantId - 商家ID
 * @param {string} dishId - 菜品ID
 * @returns {Promise<Object>} 菜品详情
 */
export const getDishDetail = async (merchantId, dishId) => {
  const response = await client.get(`/merchants/${merchantId}/dishes/${dishId}`);
  return response;
};

/**
 * 添加菜品
 * @param {string} merchantId - 商家ID
 * @param {Object} dishData - 菜品数据
 * @returns {Promise<Object>} 创建结果
 */
export const addDish = async (merchantId, dishData) => {
  const response = await client.post(`/merchants/${merchantId}/dishes`, dishData);
  return response;
};

/**
 * 更新菜品
 * @param {string} merchantId - 商家ID
 * @param {string} dishId - 菜品ID
 * @param {Object} dishData - 更新的菜品数据
 * @returns {Promise<Object>} 更新结果
 */
export const updateDish = async (merchantId, dishId, dishData) => {
  const response = await client.put(`/merchants/${merchantId}/dishes/${dishId}`, dishData);
  return response;
};

/**
 * 删除菜品
 * @param {string} merchantId - 商家ID
 * @param {string} dishId - 菜品ID
 * @returns {Promise<Object>} 删除结果
 */
export const deleteDish = async (merchantId, dishId) => {
  const response = await client.delete(`/merchants/${merchantId}/dishes/${dishId}`);
  return response;
};

/**
 * 批量更新菜品状态（上架/下架）
 * @param {string} merchantId - 商家ID
 * @param {Array<string>} dishIds - 菜品ID数组
 * @param {string} status - 状态（available/unavailable）
 * @returns {Promise<Object>} 更新结果
 */
export const batchUpdateDishStatus = async (merchantId, dishIds, status) => {
  const response = await client.put(`/merchants/${merchantId}/dishes/batch-status`, {
    dishIds,
    status,
  });
  return response;
};

/**
 * 获取菜品分类列表
 * @param {string} merchantId - 商家ID
 * @returns {Promise<Array>} 分类列表
 */
export const getDishCategories = async (merchantId) => {
  const response = await client.get(`/merchants/${merchantId}/categories`);
  return response;
};

/**
 * 创建分类
 * @param {string} merchantId - 商家ID
 * @param {Object} categoryData - 分类数据 { name, sort_order }
 * @returns {Promise<Object>} 创建结果
 */
export const createCategory = async (merchantId, categoryData) => {
  const response = await client.post(`/merchants/${merchantId}/categories`, categoryData);
  return response;
};

/**
 * 更新分类
 * @param {string} merchantId - 商家ID
 * @param {string} categoryId - 分类ID
 * @param {Object} categoryData - 更新的分类数据 { name, sort_order }
 * @returns {Promise<Object>} 更新结果
 */
export const updateCategory = async (merchantId, categoryId, categoryData) => {
  const response = await client.put(`/merchants/${merchantId}/categories/${categoryId}`, categoryData);
  return response;
};

/**
 * 删除分类
 * @param {string} merchantId - 商家ID
 * @param {string} categoryId - 分类ID
 * @returns {Promise<Object>} 删除结果
 */
export const deleteCategory = async (merchantId, categoryId) => {
  const response = await client.delete(`/merchants/${merchantId}/categories/${categoryId}`);
  return response;
};

/**
 * 批量更新分类排序
 * @param {string} merchantId - 商家ID
 * @param {Array} categories - 分类排序数据 [{ id, sort_order }]
 * @returns {Promise<Object>} 更新结果
 */
export const updateCategoriesSort = async (merchantId, categories) => {
  const response = await client.put(`/merchants/${merchantId}/categories/sort`, { categories });
  return response;
};

