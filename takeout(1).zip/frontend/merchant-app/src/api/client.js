import axios from 'axios';
import { Toast } from 'antd-mobile';

const client = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 请求拦截器：添加token认证
client.interceptors.request.use(
  (config) => {
    // 从localStorage获取token
    const token = localStorage.getItem('merchant_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    console.error('请求拦截器错误:', error);
    return Promise.reject(error);
  }
);

// 响应拦截器：统一处理响应和错误
client.interceptors.response.use(
  (response) => {
    // 统一返回data字段
    return response.data;
  },
  (error) => {
    // 处理不同的HTTP错误状态码
    if (error.response) {
      const { status, data } = error.response;

      switch (status) {
        case 401:
          // 未授权，清除token并跳转到登录页
          localStorage.removeItem('merchant_token');
          localStorage.removeItem('merchant_info');
          Toast.show({
            icon: 'fail',
            content: '登录已过期，请重新登录',
          });
          // 延迟跳转，让Toast显示
          setTimeout(() => {
            window.location.href = '/login';
          }, 1500);
          break;

        case 403:
          Toast.show({
            icon: 'fail',
            content: '没有权限访问',
          });
          break;

        case 404:
          Toast.show({
            icon: 'fail',
            content: '请求的资源不存在',
          });
          break;

        case 500:
          Toast.show({
            icon: 'fail',
            content: '服务器错误，请稍后重试',
          });
          break;

        default:
          Toast.show({
            icon: 'fail',
            content: data?.message || '请求失败，请重试',
          });
      }
    } else if (error.request) {
      // 请求已发出但没有收到响应
      Toast.show({
        icon: 'fail',
        content: '网络连接失败，请检查网络',
      });
    } else {
      // 请求配置出错
      Toast.show({
        icon: 'fail',
        content: '请求配置错误',
      });
    }

    console.error('API Error:', error);
    return Promise.reject(error);
  }
);

export default client;
