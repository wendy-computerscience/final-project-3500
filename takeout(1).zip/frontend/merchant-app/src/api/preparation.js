import client from './client';

/**
 * 获取备餐看板订单列表
 * @param {string} merchantId - 商家ID
 * @returns {Promise<Array>} 订单列表
 */
export const getKanbanOrders = async (merchantId = 'm_001') => {
  const response = await client.get('/preparation/kanban', {
    params: { merchantId }
  });
  return response;
};

/**
 * 更新订单备餐状态
 * @param {string} orderId - 订单ID
 * @param {string} status - 状态
 * @returns {Promise<Object>} 更新结果
 */
export const updateOrderStatus = async (orderId, status) => {
  const response = await client.put(`/preparation/order/${orderId}/status`, {
    status
  });
  return response;
};

/**
 * 获取备餐统计数据
 * @param {string} merchantId - 商家ID
 * @param {string} timeRange - 时间范围
 * @returns {Promise<Object>} 统计数据
 */
export const getStatistics = async (merchantId = 'm_001', timeRange = 'today') => {
  const response = await client.get('/preparation/statistics', {
    params: { merchantId, timeRange }
  });
  return response;
};

/**
 * 获取备餐瓶颈分析
 * @param {string} merchantId - 商家ID
 * @returns {Promise<Object>} 瓶颈分析数据
 */
export const getBottleneckAnalysis = async (merchantId = 'm_001') => {
  const response = await client.get('/preparation/bottleneck', {
    params: { merchantId }
  });
  return response;
};
