import client from './client';

/**
 * 获取每日统计数据
 * @param {string} merchantId - 商家ID
 * @param {string} date - 日期（YYYY-MM-DD格式）
 * @returns {Promise<Object>} 统计数据
 */
export const getDailyStats = async (merchantId, date) => {
  const response = await client.get(`/merchants/${merchantId}/statistics/daily`, {
    params: { date },
  });
  return response;
};

/**
 * 获取时间段统计数据
 * @param {string} merchantId - 商家ID
 * @param {string} startDate - 开始日期
 * @param {string} endDate - 结束日期
 * @returns {Promise<Object>} 统计数据
 */
export const getRangeStats = async (merchantId, startDate, endDate) => {
  const response = await client.get(`/merchants/${merchantId}/statistics/range`, {
    params: { startDate, endDate },
  });
  return response;
};

/**
 * 获取热销菜品排行
 * @param {string} merchantId - 商家ID
 * @param {string} timeRange - 时间范围（today/week/month）
 * @param {number} limit - 返回数量限制
 * @returns {Promise<Array>} 热销菜品列表
 */
export const getHotDishes = async (merchantId, timeRange = 'week', limit = 10) => {
  const response = await client.get(`/merchants/${merchantId}/statistics/hot-dishes`, {
    params: { timeRange, limit },
  });
  return response;
};

/**
 * 获取营业额趋势
 * @param {string} merchantId - 商家ID
 * @param {string} period - 周期（day/week/month）
 * @param {number} count - 返回周期数
 * @returns {Promise<Array>} 趋势数据
 */
export const getRevenueTrend = async (merchantId, period = 'day', count = 7) => {
  const response = await client.get(`/merchants/${merchantId}/statistics/revenue-trend`, {
    params: { period, count },
  });
  return response;
};

/**
 * 获取订单量趋势
 * @param {string} merchantId - 商家ID
 * @param {string} period - 周期（day/week/month）
 * @param {number} count - 返回周期数
 * @returns {Promise<Array>} 趋势数据
 */
export const getOrderTrend = async (merchantId, period = 'day', count = 7) => {
  const response = await client.get(`/merchants/${merchantId}/statistics/order-trend`, {
    params: { period, count },
  });
  return response;
};

/**
 * 获取用户增长数据
 * @param {string} merchantId - 商家ID
 * @param {string} timeRange - 时间范围（week/month/year）
 * @returns {Promise<Object>} 用户增长数据
 */
export const getUserGrowth = async (merchantId, timeRange = 'month') => {
  const response = await client.get(`/merchants/${merchantId}/statistics/user-growth`, {
    params: { timeRange },
  });
  return response;
};

/**
 * 获取商家总览数据
 * @param {string} merchantId - 商家ID
 * @returns {Promise<Object>} 总览数据（订单总数、总营业额、客单价等）
 */
export const getOverview = async (merchantId) => {
  const response = await client.get(`/merchants/${merchantId}/statistics/overview`);
  return response;
};

/**
 * 获取高峰时段分析
 * @param {string} merchantId - 商家ID
 * @param {string} timeRange - 时间范围（week/month）
 * @returns {Promise<Array>} 高峰时段数据
 */
export const getPeakHours = async (merchantId, timeRange = 'week') => {
  const response = await client.get(`/merchants/${merchantId}/statistics/peak-hours`, {
    params: { timeRange },
  });
  return response;
};

/**
 * 获取客户分析数据
 * @param {string} merchantId - 商家ID
 * @returns {Promise<Object>} 客户分析数据（新老客户比例、复购率等）
 */
export const getCustomerAnalysis = async (merchantId) => {
  const response = await client.get(`/merchants/${merchantId}/statistics/customer-analysis`);
  return response;
};
