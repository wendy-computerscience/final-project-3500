import client from './client';

/**
 * 获取订单列表
 * @param {string} merchantId - 商家ID
 * @param {Object} params - 查询参数（状态、分页等）
 * @returns {Promise<Object>} 订单列表
 */
export const getOrders = async (merchantId, params = {}) => {
  const response = await client.get(`/merchants/${merchantId}/orders`, {
    params,
  });
  return response;
};

/**
 * 获取订单详情
 * @param {string} merchantId - 商家ID
 * @param {string} orderId - 订单ID
 * @returns {Promise<Object>} 订单详情
 */
export const getOrderDetail = async (merchantId, orderId) => {
  const response = await client.get(`/merchants/${merchantId}/orders/${orderId}`);
  return response;
};

/**
 * 接受订单
 * @param {string} merchantId - 商家ID
 * @param {string} orderId - 订单ID
 * @param {number} estimatedTime - 预计备餐时间（分钟）
 * @returns {Promise<Object>} 操作结果
 */
export const acceptOrder = async (merchantId, orderId, estimatedTime) => {
  const response = await client.post(`/merchants/${merchantId}/orders/${orderId}/accept`, {
    estimatedTime,
  });
  return response;
};

/**
 * 拒绝订单
 * @param {string} merchantId - 商家ID
 * @param {string} orderId - 订单ID
 * @param {string} reason - 拒绝原因
 * @returns {Promise<Object>} 操作结果
 */
export const rejectOrder = async (merchantId, orderId, reason) => {
  const response = await client.post(`/merchants/${merchantId}/orders/${orderId}/reject`, {
    reason,
  });
  return response;
};

/**
 * 完成备餐
 * @param {string} merchantId - 商家ID
 * @param {string} orderId - 订单ID
 * @returns {Promise<Object>} 操作结果
 */
export const completePreparation = async (merchantId, orderId) => {
  const response = await client.post(`/merchants/${merchantId}/orders/${orderId}/complete-prep`);
  return response;
};

/**
 * 确认骑手取餐
 * @param {string} merchantId - 商家ID
 * @param {string} orderId - 订单ID
 * @returns {Promise<Object>} 操作结果
 */
export const confirmPickup = async (merchantId, orderId) => {
  const response = await client.post(`/merchants/${merchantId}/orders/${orderId}/confirm-pickup`);
  return response;
};

/**
 * 获取订单统计数据
 * @param {string} merchantId - 商家ID
 * @param {string} timeRange - 时间范围（today/week/month）
 * @returns {Promise<Object>} 统计数据
 */
export const getOrderStats = async (merchantId, timeRange = 'today') => {
  const response = await client.get(`/merchants/${merchantId}/orders/stats`, {
    params: { timeRange },
  });
  return response;
};

/**
 * 批量处理订单
 * @param {string} merchantId - 商家ID
 * @param {Array<string>} orderIds - 订单ID数组
 * @param {string} action - 操作类型（accept/reject）
 * @param {Object} data - 额外数据
 * @returns {Promise<Object>} 操作结果
 */
export const batchProcessOrders = async (merchantId, orderIds, action, data = {}) => {
  const response = await client.post(`/merchants/${merchantId}/orders/batch`, {
    orderIds,
    action,
    ...data,
  });
  return response;
};
