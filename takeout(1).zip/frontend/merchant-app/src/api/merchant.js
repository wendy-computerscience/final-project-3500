import client from './client';

/**
 * 商家登录（账号密码登录）
 * @param {string} username - 登录账号
 * @param {string} password - 密码
 * @returns {Promise<Object>} 登录结果包含token和商家信息
 */
export const login = async (username, password) => {
  const response = await client.post('/merchants/login', {
    username,
    password
  });
  return response;
};

/**
 * 商家入驻申请
 * @param {Object} applicationData - 申请数据
 * @returns {Promise<Object>} 申请结果
 */
export const register = async (applicationData) => {
  const response = await client.post('/merchants/register', applicationData);
  return response;
};

/**
 * 获取申请状态
 * @param {string} merchantId - 商家ID
 * @returns {Promise<Object>} 申请状态信息
 */
export const getApplicationStatus = async (merchantId) => {
  const response = await client.get(`/merchants/application/${merchantId}`);
  return response;
};

/**
 * 获取商家信息
 * @param {string} merchantId - 商家ID
 * @returns {Promise<Object>} 商家详细信息
 */
export const getMerchantInfo = async (merchantId) => {
  const response = await client.get(`/merchants/${merchantId}`);
  return response;
};

/**
 * 更新商家信息
 * @param {string} merchantId - 商家ID
 * @param {Object} data - 要更新的数据
 * @returns {Promise<Object>} 更新结果
 */
export const updateMerchantInfo = async (merchantId, data) => {
  const response = await client.put(`/merchants/${merchantId}`, data);
  return response;
};

/**
 * 商家登出
 * @returns {Promise<Object>} 登出结果
 */
export const logout = async () => {
  // 清除本地存储
  localStorage.removeItem('merchant_token');
  localStorage.removeItem('merchant_info');
  return { success: true };
};
