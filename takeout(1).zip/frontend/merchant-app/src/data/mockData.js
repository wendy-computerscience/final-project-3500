// Mock data for merchant app

// Generate mock orders with different statuses
export const generateMockOrders = () => {
  const statuses = ['pending', 'preparing', 'ready', 'delivering', 'completed'];
  const customerNames = ['John Smith', 'Emma Johnson', 'Michael Brown', 'Sarah Davis', 'David Wilson', 'Lisa Anderson', 'James Taylor', 'Anna Martinez'];
  const addresses = [
    '123 Main St, Apt 4B',
    '456 Oak Ave, Suite 200',
    '789 Pine Rd, Floor 3',
    '321 Elm Street',
    '654 Maple Drive, Unit 5',
    '987 Cedar Lane',
    '147 Birch Court',
    '258 Spruce Way'
  ];

  const dishItems = [
    { name: 'Kung Pao Chicken', price: 15.99 },
    { name: 'Sweet and Sour Pork', price: 14.50 },
    { name: 'Beef Fried Rice', price: 12.99 },
    { name: 'Spring Rolls', price: 6.99 },
    { name: 'Hot and Sour Soup', price: 5.99 },
    { name: 'Mapo Tofu', price: 11.99 },
    { name: 'Peking Duck', price: 28.99 },
    { name: 'Dumplings', price: 8.99 }
  ];

  const orders = [];
  let orderId = 1001;

  statuses.forEach((status, statusIndex) => {
    const count = status === 'pending' ? 3 : status === 'preparing' ? 5 : status === 'ready' ? 2 : status === 'delivering' ? 4 : 8;

    for (let i = 0; i < count; i++) {
      const customerIndex = (statusIndex * count + i) % customerNames.length;
      const numItems = Math.floor(Math.random() * 3) + 1;
      const items = [];
      let totalAmount = 0;

      for (let j = 0; j < numItems; j++) {
        const dish = dishItems[(customerIndex + j) % dishItems.length];
        const quantity = Math.floor(Math.random() * 2) + 1;
        items.push({
          name: dish.name,
          quantity,
          price: dish.price
        });
        totalAmount += dish.price * quantity;
      }

      const createdAt = new Date();
      createdAt.setHours(createdAt.getHours() - (5 - statusIndex) * 2 - i);

      orders.push({
        orderId: orderId++,
        customerName: customerNames[customerIndex],
        customerPhone: `138${Math.floor(Math.random() * 100000000).toString().padStart(8, '0')}`,
        customerAddress: addresses[customerIndex],
        items,
        totalAmount: parseFloat(totalAmount.toFixed(2)),
        status,
        isUrgent: Math.random() > 0.7,
        notes: Math.random() > 0.6 ? 'Extra spicy please' : '',
        createdAt: createdAt.toISOString(),
        estimatedPrepTime: 25 + Math.floor(Math.random() * 20),
        actualStartTime: status !== 'pending' ? createdAt.getTime() + 60000 : null,
        estimatedDeliveryTime: status === 'delivering' || status === 'completed' ? new Date(createdAt.getTime() + 3600000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : null,
        courierPhone: status === 'delivering' || status === 'completed' ? `139${Math.floor(Math.random() * 100000000).toString().padStart(8, '0')}` : null,
        rating: status === 'completed' ? Math.floor(Math.random() * 2) + 4 : null,
        remark: status === 'completed' && Math.random() > 0.5 ? 'Great food!' : null
      });
    }
  });

  return orders;
};

// Generate mock menu items
export const generateMockMenuItems = () => {
  const categories = ['Hot Dishes', 'Seafood', 'Meat', 'Cold Dishes', 'Soup', 'Staple Food'];
  const menuItems = [
    // Hot Dishes
    { name: 'Kung Pao Chicken', category: 'Hot Dishes', price: 15.99, description: 'Spicy chicken with peanuts and vegetables', image: 'https://via.placeholder.com/150', available: true, spicy: true },
    { name: 'Mapo Tofu', category: 'Hot Dishes', price: 11.99, description: 'Spicy tofu with minced meat', image: 'https://via.placeholder.com/150', available: true, spicy: true },
    { name: 'Szechuan Eggplant', category: 'Hot Dishes', price: 12.50, description: 'Stir-fried eggplant in spicy sauce', image: 'https://via.placeholder.com/150', available: true, spicy: true },

    // Seafood
    { name: 'Sweet and Sour Fish', category: 'Seafood', price: 18.99, description: 'Deep-fried fish with sweet and sour sauce', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Garlic Shrimp', category: 'Seafood', price: 22.99, description: 'Shrimp sautéed with garlic', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Steamed Fish', category: 'Seafood', price: 24.99, description: 'Whole fish steamed with ginger and soy sauce', image: 'https://via.placeholder.com/150', available: false, spicy: false },

    // Meat
    { name: 'Sweet and Sour Pork', category: 'Meat', price: 14.50, description: 'Crispy pork in sweet and sour sauce', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Peking Duck', category: 'Meat', price: 28.99, description: 'Roasted duck with pancakes and sauce', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Mongolian Beef', category: 'Meat', price: 17.99, description: 'Beef with scallions in savory sauce', image: 'https://via.placeholder.com/150', available: true, spicy: false },

    // Cold Dishes
    { name: 'Cucumber Salad', category: 'Cold Dishes', price: 6.99, description: 'Fresh cucumber with garlic dressing', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Spicy Tofu Skin', category: 'Cold Dishes', price: 7.50, description: 'Marinated tofu skin with chili oil', image: 'https://via.placeholder.com/150', available: true, spicy: true },

    // Soup
    { name: 'Hot and Sour Soup', category: 'Soup', price: 5.99, description: 'Traditional spicy and tangy soup', image: 'https://via.placeholder.com/150', available: true, spicy: true },
    { name: 'Egg Drop Soup', category: 'Soup', price: 4.99, description: 'Light chicken broth with eggs', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Wonton Soup', category: 'Soup', price: 6.99, description: 'Pork wontons in clear broth', image: 'https://via.placeholder.com/150', available: true, spicy: false },

    // Staple Food
    { name: 'Beef Fried Rice', category: 'Staple Food', price: 12.99, description: 'Fried rice with beef and vegetables', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Vegetable Lo Mein', category: 'Staple Food', price: 10.99, description: 'Soft noodles with mixed vegetables', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Pork Dumplings', category: 'Staple Food', price: 8.99, description: '8 pieces of steamed or pan-fried dumplings', image: 'https://via.placeholder.com/150', available: true, spicy: false },
    { name: 'Spring Rolls', category: 'Staple Food', price: 6.99, description: '4 pieces of crispy spring rolls', image: 'https://via.placeholder.com/150', available: true, spicy: false }
  ];

  return menuItems.map((item, index) => ({
    ...item,
    id: index + 1,
    sales: Math.floor(Math.random() * 100) + 10,
    stock: Math.floor(Math.random() * 50) + 10,
    prepTime: Math.floor(Math.random() * 15) + 10
  }));
};

// Generate mock statistics
export const generateMockStatistics = (date = new Date()) => {
  return {
    orderCount: Math.floor(Math.random() * 50) + 30,
    totalRevenue: parseFloat((Math.random() * 2000 + 1500).toFixed(2)),
    avgPrice: parseFloat((Math.random() * 20 + 25).toFixed(2)),
    goodRating: parseFloat((Math.random() * 10 + 88).toFixed(1)),
    peakHour: `${Math.floor(Math.random() * 3) + 11}:00-${Math.floor(Math.random() * 3) + 12}:00`,
    hotDishes: [
      { name: 'Kung Pao Chicken', sales: 45, revenue: 719.55 },
      { name: 'Beef Fried Rice', sales: 38, revenue: 493.62 },
      { name: 'Sweet and Sour Pork', sales: 32, revenue: 464.00 },
      { name: 'Peking Duck', sales: 18, revenue: 521.82 },
      { name: 'Mapo Tofu', sales: 28, revenue: 335.72 }
    ],
    trendData: Array.from({ length: 7 }, (_, i) => {
      const trendDate = new Date(date);
      trendDate.setDate(trendDate.getDate() - (6 - i));
      const month = String(trendDate.getMonth() + 1).padStart(2, '0');
      const day = String(trendDate.getDate()).padStart(2, '0');
      return {
        date: `${month}-${day}`,
        orders: Math.floor(Math.random() * 40) + 25,
        revenue: Math.floor(Math.random() * 4000) + 2500,
        rating: (Math.random() * 15 + 78).toFixed(1)
      };
    })
  };
};

// Generate preparation kanban data
export const generateKanbanData = (orders) => {
  const preparingOrders = orders.filter(o => o.status === 'preparing');

  return preparingOrders.map(order => ({
    orderId: order.orderId,
    items: order.items,
    priority: order.isUrgent ? 'urgent' : Math.random() > 0.5 ? 'high' : 'normal',
    estimatedTime: order.estimatedPrepTime,
    elapsedTime: order.actualStartTime ? Math.floor((Date.now() - order.actualStartTime) / 60000) : 0,
    status: 'PREPARING',
    station: order.items[0].name.includes('Rice') || order.items[0].name.includes('Noodles') ? 'Wok Station' : order.items[0].name.includes('Soup') ? 'Soup Station' : 'Main Kitchen'
  }));
};
