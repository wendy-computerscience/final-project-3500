import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterApplicationPage from './pages/RegisterApplicationPage';
import OrderManagePage from './pages/OrderManagePage';
import PreparationPage from './pages/PreparationPage';
import StatisticsPage from './pages/StatisticsPage';
import MenuManagePage from './pages/MenuManagePage';
import ProfilePage from './pages/ProfilePage';
import MainLayout from './components/MainLayout';
import useMerchantStore from './store/merchantStore';
import './index.css';

// 路由保护组件
const ProtectedRoute = ({ children }) => {
  const { isLoggedIn } = useMerchantStore();
  if (!isLoggedIn) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register-application" element={<RegisterApplicationPage />} />
        <Route element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }>
          <Route path="/orders" element={<OrderManagePage />} />
          <Route path="/preparation" element={<PreparationPage />} />
          <Route path="/menu" element={<MenuManagePage />} />
          <Route path="/statistics" element={<StatisticsPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/" element={<Navigate to="/orders" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
