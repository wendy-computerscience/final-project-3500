import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { generateMockOrders, generateMockMenuItems } from '../data/mockData';

const useMerchantStore = create(
  persist(
    (set, get) => ({
      // 登录状态
      isLoggedIn: false,
      token: null,

      // 商家信息
      merchant: {
        id: '',
        name: '',
        phone: '',
        shopName: '',
        address: '',
        categories: [],
        status: 'pending' // pending/approved/rejected
      },

      // 订单列表
      orders: [],

      // 菜品列表
      menuItems: [],

      // 初始化 mock 数据
      initializeMockData: () => {
        set({
          orders: generateMockOrders(),
          menuItems: generateMockMenuItems()
        });
      },

      // 登录
      login: (merchantData) => {
        set({
          isLoggedIn: true,
          token: merchantData.token,
          merchant: {
            ...merchantData,
            status: merchantData.status || 'approved'
          }
        });
        // 登录后初始化 mock 数据
        get().initializeMockData();
      },

      // 登出
      logout: () =>
        set({
          isLoggedIn: false,
          token: null,
          merchant: {
            id: '',
            name: '',
            phone: '',
            shopName: '',
            address: '',
            categories: [],
            status: 'pending'
          }
        }),

      // 更新商家信息
      updateMerchant: (data) =>
        set((state) => ({
          merchant: { ...state.merchant, ...data }
        })),

      // 设置订单列表
      setOrders: (orders) => set({ orders }),

      // 更新单个订单
      updateOrder: (orderId, updates) =>
        set((state) => ({
          orders: state.orders.map((order) =>
            order.orderId === orderId ? { ...order, ...updates } : order
          )
        })),

      // 设置菜品列表
      setMenuItems: (items) => set({ menuItems: items }),

      // 添加菜品
      addMenuItem: (item) =>
        set((state) => ({
          menuItems: [...state.menuItems, item]
        })),

      // 更新菜品
      updateMenuItem: (itemId, updates) =>
        set((state) => ({
          menuItems: state.menuItems.map((item) =>
            item.id === itemId ? { ...item, ...updates } : item
          )
        })),

      // 删除菜品
      deleteMenuItem: (itemId) =>
        set((state) => ({
          menuItems: state.menuItems.filter((item) => item.id !== itemId)
        }))
    }),
    {
      name: 'merchant-storage'
    }
  )
);

export default useMerchantStore;
