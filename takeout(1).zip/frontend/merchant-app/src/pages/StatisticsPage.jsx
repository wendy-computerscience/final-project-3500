import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Row,
  Col,
  Statistic,
  Button,
  Space,
  Table,
  Progress,
  Empty,
  Spin,
  message
} from 'antd';
import {
  ShoppingOutlined,
  DollarOutlined,
  StarOutlined,
  RiseOutlined,
  ReloadOutlined,
  FireOutlined
} from '@ant-design/icons';
import useMerchantStore from '../store/merchantStore';
import { getDailyStats, getHotDishes } from '../api/statistics';
import './StatisticsPage.css';

const StatisticsPage = () => {
  const { t } = useTranslation();
  const { merchant } = useMerchantStore();
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(false);

  // Load statistics from backend API
  const loadStatistics = async () => {
    if (!merchant?.id) {
      message.warning(t('statistics.pleaseLogin') || '请先登录');
      return;
    }

    try {
      setLoading(true);

      // 获取今日统计数据
      const today = new Date().toISOString().split('T')[0];
      const dailyStatsResponse = await getDailyStats(merchant.id, today);

      // 获取热销菜品（最近7天）
      const hotDishesResponse = await getHotDishes(merchant.id, 'week', 5);

      if (dailyStatsResponse.success && hotDishesResponse.success) {
        // 生成最近7天的趋势数据（简单模拟，后续可从后端获取）
        const trendData = [];
        for (let i = 6; i >= 0; i--) {
          const date = new Date();
          date.setDate(date.getDate() - i);
          const dateStr = `${date.getMonth() + 1}/${date.getDate()}`;
          trendData.push({
            date: dateStr,
            orders: Math.floor(Math.random() * 30 + 30), // 模拟数据
            revenue: Math.floor(Math.random() * 3000 + 3000) // 模拟数据
          });
        }

        setStatistics({
          orderCount: dailyStatsResponse.data.orderCount,
          totalRevenue: parseFloat(dailyStatsResponse.data.totalRevenue),
          avgPrice: parseFloat(dailyStatsResponse.data.avgPrice),
          goodRating: parseFloat(dailyStatsResponse.data.goodRating),
          peakHour: dailyStatsResponse.data.peakHour,
          hotDishes: hotDishesResponse.data || [],
          trendData: trendData
        });
      } else {
        throw new Error(t('statistics.loadError') || '加载统计数据失败');
      }
    } catch (error) {
      console.error('Failed to load statistics:', error);
      message.error(error.message || t('statistics.loadError') || '加载统计数据失败');
    } finally {
      setLoading(false);
    }
  };

  // Initialize on mount
  useEffect(() => {
    if (merchant?.id) {
      loadStatistics();
    }
  }, [merchant?.id]);

  // Hot dishes table columns
  const dishColumns = [
    {
      title: t('statistics.rank'),
      key: 'rank',
      width: 60,
      render: (_, record, index) => (
        <span className="rank-badge">
          {index === 0 && <FireOutlined className="rank-icon-fire" />}
          #{index + 1}
        </span>
      )
    },
    {
      title: t('statistics.dishName'),
      dataIndex: 'name',
      key: 'name',
      render: (text) => <span className="dish-name">{text}</span>
    },
    {
      title: t('statistics.sales'),
      dataIndex: 'sales',
      key: 'sales',
      align: 'center',
      render: (text) => <span className="sales-count">{text} {t('statistics.portions')}</span>
    },
    {
      title: t('statistics.revenue'),
      dataIndex: 'revenue',
      key: 'revenue',
      align: 'center',
      render: (text) => <span className="revenue-amount">¥{text}</span>
    },
    {
      title: t('statistics.rating'),
      dataIndex: 'rating',
      key: 'rating',
      align: 'center',
      width: 120,
      render: (rating) => (
        <div className="rating-display">
          <StarOutlined className="rating-star" />
          <span className="rating-value">{rating}</span>
        </div>
      )
    }
  ];

  if (!statistics && !loading) {
    return <Spin className="statistics-loading" />;
  }

  return (
    <div className="statistics-page">
      {/* Page header */}
      <div className="statistics-header">
        <div>
          <h1 className="statistics-title">{t('statistics.title')}</h1>
          <p style={{ color: '#666', margin: '8px 0 0 0', fontSize: '14px' }}>
            {new Date().toLocaleDateString('en-US', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </p>
        </div>
        <Button
          icon={<ReloadOutlined />}
          onClick={() => loadStatistics()}
          loading={loading}
        >
          {t('statistics.refresh')}
        </Button>
      </div>

      <Spin spinning={loading}>
        {statistics && (
          <>
            {/* Key metrics cards */}
            <Row gutter={[16, 16]} className="statistics-metrics">
              {/* Order count */}
              <Col xs={24} sm={12} lg={6}>
                <Card className="metric-card metric-card-orders">
                  <div className="metric-content">
                    <div className="metric-icon-wrapper orders-icon">
                      <ShoppingOutlined className="metric-icon" />
                    </div>
                    <div className="metric-info">
                      <div className="metric-label">{t('statistics.todayOrders')}</div>
                      <div className="metric-value">{statistics.orderCount}</div>
                      <div className="metric-trend">
                        <RiseOutlined className="trend-icon-up" />
                        <span className="trend-text">{t('statistics.vsYesterday', { percent: '+12%' })}</span>
                      </div>
                    </div>
                  </div>
                </Card>
              </Col>

              {/* Revenue */}
              <Col xs={24} sm={12} lg={6}>
                <Card className="metric-card metric-card-revenue">
                  <div className="metric-content">
                    <div className="metric-icon-wrapper revenue-icon">
                      <DollarOutlined className="metric-icon" />
                    </div>
                    <div className="metric-info">
                      <div className="metric-label">{t('statistics.revenue')}</div>
                      <div className="metric-value">¥{statistics.totalRevenue}</div>
                      <div className="metric-trend">
                        <RiseOutlined className="trend-icon-up" />
                        <span className="trend-text">{t('statistics.vsYesterday', { percent: '+8%' })}</span>
                      </div>
                    </div>
                  </div>
                </Card>
              </Col>

              {/* Average price */}
              <Col xs={24} sm={12} lg={6}>
                <Card className="metric-card metric-card-avg-price">
                  <div className="metric-content">
                    <div className="metric-icon-wrapper avg-price-icon">
                      <DollarOutlined className="metric-icon" />
                    </div>
                    <div className="metric-info">
                      <div className="metric-label">{t('statistics.avgOrderValue')}</div>
                      <div className="metric-value">¥{statistics.avgPrice}</div>
                      <div className="metric-trend">
                        <RiseOutlined className="trend-icon-stable" />
                        <span className="trend-text">{t('statistics.stable')}</span>
                      </div>
                    </div>
                  </div>
                </Card>
              </Col>

              {/* Good rating */}
              <Col xs={24} sm={12} lg={6}>
                <Card className="metric-card metric-card-rating">
                  <div className="metric-content">
                    <div className="metric-icon-wrapper rating-icon">
                      <StarOutlined className="metric-icon" />
                    </div>
                    <div className="metric-info">
                      <div className="metric-label">{t('statistics.goodRating')}</div>
                      <div className="metric-value">{statistics.goodRating}%</div>
                      <Progress
                        percent={parseFloat(statistics.goodRating)}
                        strokeColor="#667eea"
                        showInfo={false}
                        className="rating-progress"
                      />
                    </div>
                  </div>
                </Card>
              </Col>
            </Row>

            {/* Hot dishes ranking */}
            <Row gutter={[16, 16]} className="statistics-content">
              <Col xs={24}>
                <Card className="hot-dishes-card">
                  <div className="card-header">
                    <h2 className="card-title">
                      <FireOutlined className="card-icon" />
                      {t('statistics.topDishes')}
                    </h2>
                  </div>
                  {statistics.hotDishes && statistics.hotDishes.length > 0 ? (
                    <Table
                      columns={dishColumns}
                      dataSource={statistics.hotDishes}
                      pagination={false}
                      className="dishes-table"
                      rowKey="id"
                    />
                  ) : (
                    <Empty description={t('statistics.noDishData')} />
                  )}
                </Card>
              </Col>
            </Row>

            {/* Trend analysis */}
            <Row gutter={[16, 16]} className="statistics-content">
              <Col xs={24} lg={12}>
                <Card className="trend-card">
                  <div className="card-header">
                    <h2 className="card-title">Order Trend (Last 7 Days)</h2>
                  </div>
                  <div className="trend-content">
                    {statistics.trendData && statistics.trendData.map((item, index) => (
                      <div key={index} className="trend-item">
                        <div className="trend-date">{item.date}</div>
                        <div className="trend-bar-wrapper">
                          <div
                            className="trend-bar"
                            style={{
                              width: `${(item.orders / 65) * 100}%`
                            }}
                          >
                            <span className="trend-bar-value">{item.orders}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </Col>

              <Col xs={24} lg={12}>
                <Card className="trend-card">
                  <div className="card-header">
                    <h2 className="card-title">Revenue Trend (Last 7 Days)</h2>
                  </div>
                  <div className="trend-content">
                    {statistics.trendData && statistics.trendData.map((item, index) => (
                      <div key={index} className="trend-item">
                        <div className="trend-date">{item.date}</div>
                        <div className="trend-bar-wrapper">
                          <div
                            className="trend-bar trend-bar-revenue"
                            style={{
                              width: `${(item.revenue / 6500) * 100}%`
                            }}
                          >
                            <span className="trend-bar-value">¥{item.revenue}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </Col>
            </Row>

            {/* Other information */}
            <Row gutter={[16, 16]} className="statistics-content">
              <Col xs={24} sm={12}>
                <Card className="info-card">
                  <div className="info-item">
                    <span className="info-label">Peak Hours</span>
                    <span className="info-value">{statistics.peakHour}</span>
                  </div>
                </Card>
              </Col>
              <Col xs={24} sm={12}>
                <Card className="info-card">
                  <div className="info-item">
                    <span className="info-label">Avg Delivery Time</span>
                    <span className="info-value">32 minutes</span>
                  </div>
                </Card>
              </Col>
            </Row>
          </>
        )}
      </Spin>
    </div>
  );
};

export default StatisticsPage;
