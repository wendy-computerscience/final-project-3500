import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Row,
  Col,
  Statistic,
  Tag,
  Button,
  Alert,
  Space,
  message
} from 'antd';
import {
  ClockCircleOutlined,
  CheckCircleOutlined,
  WarningOutlined,
  ReloadOutlined
} from '@ant-design/icons';
import useMerchantStore from '../store/merchantStore';

const PreparationPage = () => {
  const { t } = useTranslation();
  const { orders, updateOrder } = useMerchantStore();
  const [kanban, setKanban] = useState({ pending: [], preparing: [], ready: [], pickedUp: [] });
  const [stats, setStats] = useState(null);
  const [bottleneck, setBottleneck] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchData = () => {
    try {
      setLoading(true);

      // 按状态分组订单
      const grouped = {
        pending: [],
        preparing: [],
        ready: [],
        pickedUp: []
      };

      orders.forEach(order => {
        if (order.status === 'pending') {
          grouped.pending.push({
            orderId: order.orderId,
            items: order.items.map(item => `${item.name} x${item.quantity}`),
            priority: order.isUrgent ? 'urgent' : Math.random() > 0.5 ? 'high' : 'normal',
            estimatedTime: order.estimatedPrepTime,
            actualStartTime: order.actualStartTime,
            status: 'PENDING',
            notes: order.notes
          });
        } else if (order.status === 'preparing') {
          grouped.preparing.push({
            orderId: order.orderId,
            items: order.items.map(item => `${item.name} x${item.quantity}`),
            priority: order.isUrgent ? 'urgent' : Math.random() > 0.5 ? 'high' : 'normal',
            estimatedTime: order.estimatedPrepTime,
            actualStartTime: order.actualStartTime,
            status: 'PREPARING',
            notes: order.notes
          });
        } else if (order.status === 'ready') {
          grouped.ready.push({
            orderId: order.orderId,
            items: order.items.map(item => `${item.name} x${item.quantity}`),
            priority: order.isUrgent ? 'urgent' : 'normal',
            estimatedTime: order.estimatedPrepTime,
            actualStartTime: order.actualStartTime,
            status: 'READY',
            notes: order.notes
          });
        } else if (order.status === 'delivering' || order.status === 'completed') {
          grouped.pickedUp.push({
            orderId: order.orderId,
            items: order.items.map(item => `${item.name} x${item.quantity}`),
            priority: 'normal',
            estimatedTime: order.estimatedPrepTime,
            actualStartTime: order.actualStartTime,
            status: 'PICKED_UP',
            notes: order.notes
          });
        }
      });

      setKanban(grouped);

      // 计算统计数据
      const preparingOrders = orders.filter(o => o.status === 'preparing');
      const totalPrepTime = preparingOrders.reduce((sum, o) => {
        if (o.actualStartTime) {
          return sum + Math.floor((Date.now() - o.actualStartTime) / 60000);
        }
        return sum;
      }, 0);

      const avgPrepTime = preparingOrders.length > 0 ? Math.round(totalPrepTime / preparingOrders.length) : 0;
      const onTimeOrders = preparingOrders.filter(o => {
        if (o.actualStartTime) {
          const elapsed = Math.floor((Date.now() - o.actualStartTime) / 60000);
          return elapsed <= o.estimatedPrepTime;
        }
        return true;
      });

      setStats({
        totalOrders: grouped.pending.length + grouped.preparing.length,
        pendingOrders: grouped.pending.length,
        averagePrepTime: avgPrepTime,
        onTimeRate: preparingOrders.length > 0 ? Math.round((onTimeOrders.length / preparingOrders.length) * 100) : 100
      });

      // 瓶颈分析
      const bottlenecks = [];
      if (grouped.pending.length > 5) {
        bottlenecks.push({
          message: `High pending orders: ${grouped.pending.length} orders waiting`,
          suggestion: 'Consider prioritizing urgent orders or adding kitchen staff'
        });
      }
      if (avgPrepTime > 25) {
        bottlenecks.push({
          message: `Average prep time is ${avgPrepTime} minutes`,
          suggestion: 'Review kitchen workflow to improve efficiency'
        });
      }

      setBottleneck(bottlenecks.length > 0 ? { bottlenecks } : null);
    } catch (error) {
      message.error(t('preparation.loadError'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval);
  }, [orders]);

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      // 模拟延迟
      await new Promise(resolve => setTimeout(resolve, 300));

      const statusMap = {
        'PREPARING': 'preparing',
        'READY': 'ready',
        'PICKED_UP': 'delivering'
      };

      const updates = { status: statusMap[newStatus] };
      if (newStatus === 'PREPARING') {
        updates.actualStartTime = Date.now();
      }

      updateOrder(orderId, updates);
      message.success(t('preparation.updateSuccess'));
      fetchData();
    } catch (error) {
      message.error(t('preparation.updateError'));
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      PENDING: 'orange',
      PREPARING: 'blue',
      READY: 'green',
      PICKED_UP: 'default'
    };
    return colors[status] || 'default';
  };

  const getPriorityColor = (priority) => {
    const colors = {
      urgent: 'red',
      high: 'orange',
      normal: 'default'
    };
    return colors[priority] || 'default';
  };

  const renderOrderCard = (order) => (
    <Card
      key={order.orderId}
      size="small"
      className="mb-3"
      style={{ marginBottom: 12 }}
      title={
        <Space>
          <span>#{order.orderId}</span>
          <Tag color={getPriorityColor(order.priority)}>
            {order.priority === 'urgent' ? t('preparation.urgent') : order.priority === 'high' ? t('preparation.high') : t('preparation.normal')}
          </Tag>
        </Space>
      }
      extra={
        <Space>
          {order.status === 'PENDING' && (
            <Button
              type="primary"
              size="small"
              onClick={() => handleStatusChange(order.orderId, 'PREPARING')}
            >
              {t('preparation.startPrep')}
            </Button>
          )}
          {order.status === 'PREPARING' && (
            <Button
              type="primary"
              size="small"
              onClick={() => handleStatusChange(order.orderId, 'READY')}
            >
              {t('preparation.complete')}
            </Button>
          )}
          {order.status === 'READY' && (
            <Button
              size="small"
              onClick={() => handleStatusChange(order.orderId, 'PICKED_UP')}
            >
              {t('preparation.pickedUp')}
            </Button>
          )}
        </Space>
      }
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ fontSize: 13 }}>
          {order.items.map((item, idx) => (
            <div key={idx}>• {item}</div>
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#666' }}>
          <span>{t('preparation.estimated')}: {order.estimatedTime} min</span>
          {order.actualStartTime && (
            <span>
              {t('preparation.elapsed')}: {Math.round((Date.now() - order.actualStartTime) / 60000)} min
            </span>
          )}
        </div>
        {order.notes && (
          <Alert message={order.notes} type="warning" showIcon size="small" />
        )}
      </div>
    </Card>
  );

  if (loading && !kanban) {
    return <div style={{ padding: 32, textAlign: 'center' }}>{t('preparation.loading')}</div>;
  }

  return (
    <div style={{ padding: 24, background: '#f5f5f5', minHeight: '100vh' }}>
      <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ fontSize: 24, fontWeight: 'bold', margin: 0 }}>{t('preparation.title')}</h1>
        <Button icon={<ReloadOutlined />} onClick={fetchData} loading={loading}>
          {t('preparation.refresh')}
        </Button>
      </div>

      {/* 统计卡片 */}
      {stats && (
        <Row gutter={16} style={{ marginBottom: 24 }}>
          <Col span={6}>
            <Card>
              <Statistic
                title={t('preparation.totalOrders')}
                value={stats.totalOrders}
                prefix={<ClockCircleOutlined />}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic
                title={t('preparation.pending')}
                value={stats.pendingOrders}
                valueStyle={{ color: '#ff7742' }}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic
                title={t('preparation.avgTime')}
                value={stats.averagePrepTime}
                suffix={t('preparation.minutes')}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic
                title={t('preparation.onTimeRate')}
                value={stats.onTimeRate}
                suffix="%"
                prefix={<CheckCircleOutlined />}
                valueStyle={{ color: stats.onTimeRate >= 90 ? '#3f8600' : '#cf1322' }}
              />
            </Card>
          </Col>
        </Row>
      )}

      {/* 瓶颈分析 */}
      {bottleneck && bottleneck.bottlenecks && bottleneck.bottlenecks.length > 0 && (
        <Alert
          style={{ marginBottom: 24 }}
          message={t('preparation.bottleneckAlert')}
          description={
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {bottleneck.bottlenecks.map((b, idx) => (
                <div key={idx}>
                  <div style={{ fontWeight: 600, color: '#cf1322' }}>{b.message}</div>
                  <div style={{ fontSize: 13 }}>{b.suggestion}</div>
                </div>
              ))}
            </div>
          }
          type="warning"
          showIcon
          icon={<WarningOutlined />}
        />
      )}

      {/* 看板 */}
      {kanban && (
        <Row gutter={16}>
          <Col span={6}>
            <Card
              title={`${t('preparation.pendingTitle')} (${kanban.pending.length})`}
              style={{ background: '#fff7e6' }}
              styles={{ header: { background: '#ffa940', color: 'white' } }}
            >
              <div style={{ maxHeight: 600, overflowY: 'auto' }}>
                {kanban.pending.length > 0 ? (
                  kanban.pending.map(renderOrderCard)
                ) : (
                  <div style={{ textAlign: 'center', padding: 20, color: '#999' }}>{t('orderManage.emptyOrders')}</div>
                )}
              </div>
            </Card>
          </Col>
          <Col span={6}>
            <Card
              title={`${t('preparation.preparingTitle')} (${kanban.preparing.length})`}
              style={{ background: '#e6f7ff' }}
              styles={{ header: { background: '#1890ff', color: 'white' } }}
            >
              <div style={{ maxHeight: 600, overflowY: 'auto' }}>
                {kanban.preparing.length > 0 ? (
                  kanban.preparing.map(renderOrderCard)
                ) : (
                  <div style={{ textAlign: 'center', padding: 20, color: '#999' }}>{t('orderManage.emptyOrders')}</div>
                )}
              </div>
            </Card>
          </Col>
          <Col span={6}>
            <Card
              title={`${t('preparation.readyTitle')} (${kanban.ready.length})`}
              style={{ background: '#f6ffed' }}
              styles={{ header: { background: '#52c41a', color: 'white' } }}
            >
              <div style={{ maxHeight: 600, overflowY: 'auto' }}>
                {kanban.ready.length > 0 ? (
                  kanban.ready.map(renderOrderCard)
                ) : (
                  <div style={{ textAlign: 'center', padding: 20, color: '#999' }}>{t('orderManage.emptyOrders')}</div>
                )}
              </div>
            </Card>
          </Col>
          <Col span={6}>
            <Card
              title={`${t('preparation.completedTitle')} (${kanban.pickedUp.length})`}
              style={{ background: '#fafafa' }}
              styles={{ header: { background: '#8c8c8c', color: 'white' } }}
            >
              <div style={{ maxHeight: 600, overflowY: 'auto' }}>
                {kanban.pickedUp.length > 0 ? (
                  kanban.pickedUp.map(renderOrderCard)
                ) : (
                  <div style={{ textAlign: 'center', padding: 20, color: '#999' }}>{t('orderManage.emptyOrders')}</div>
                )}
              </div>
            </Card>
          </Col>
        </Row>
      )}
    </div>
  );
};

export default PreparationPage;
