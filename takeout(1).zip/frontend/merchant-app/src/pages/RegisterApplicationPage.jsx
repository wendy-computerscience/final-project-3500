import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Form,
  Input,
  Button,
  message,
  Card,
  Checkbox
} from 'antd';
import {
  ArrowLeftOutlined,
  UserOutlined,
  LockOutlined,
  ShopOutlined,
  PhoneOutlined
} from '@ant-design/icons';
import axios from 'axios';
import './RegisterApplicationPage.css';

const RegisterApplicationPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  // Handle registration
  const handleRegister = async (values) => {
    try {
      setLoading(true);

      // Call real API
      const response = await axios.post('http://localhost:3001/api/merchants/register', {
        username: values.username,
        password: values.password,
        business_name: values.business_name,
        contact_phone: values.contact_phone
      });

      if (response.data.success) {
        message.success(t('register.registerSuccess'));

        // Navigate to login page after successful registration
        setTimeout(() => {
          navigate('/login');
        }, 1500);
      } else {
        message.error(response.data.message || t('register.registerFailed'));
      }
    } catch (error) {
      console.error('Registration failed:', error);

      // Handle different error types
      if (error.response) {
        // Server responded with error
        message.error(error.response.data.message || t('register.registerFailed'));
      } else if (error.request) {
        // Request made but no response
        message.error(t('login.networkError'));
      } else {
        message.error(t('register.registerFailed'));
      }
    } finally {
      setLoading(false);
    }
  };

  // Back to login
  const handleBack = () => {
    navigate('/login');
  };

  return (
    <div className="register-application-page">
      <div className="register-container">
        {/* Header */}
        <div className="register-header">
          <Button
            icon={<ArrowLeftOutlined />}
            type="text"
            onClick={handleBack}
            className="back-button"
          >
            {t('register.backToLogin')}
          </Button>
          <h1>{t('register.title')}</h1>
          <p>{t('register.subtitle')}</p>
        </div>

        {/* Form card */}
        <Card className="form-card">
          <Form
            form={form}
            layout="vertical"
            onFinish={handleRegister}
            size="large"
          >
            {/* Username */}
            <Form.Item
              name="username"
              label={t('register.username')}
              rules={[
                { required: true, message: t('register.usernameRequired') },
                { min: 3, message: t('register.usernameTooShort') }
              ]}
            >
              <Input
                prefix={<UserOutlined />}
                placeholder={t('register.usernamePlaceholder')}
              />
            </Form.Item>

            {/* Password */}
            <Form.Item
              name="password"
              label={t('register.password')}
              rules={[
                { required: true, message: t('register.passwordRequired') },
                { min: 6, message: t('register.passwordTooShort') }
              ]}
            >
              <Input.Password
                prefix={<LockOutlined />}
                placeholder={t('register.passwordPlaceholder')}
              />
            </Form.Item>

            {/* Confirm Password */}
            <Form.Item
              name="confirmPassword"
              label={t('register.confirmPassword')}
              dependencies={['password']}
              rules={[
                { required: true, message: t('register.confirmPasswordRequired') },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    if (!value || getFieldValue('password') === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(new Error(t('register.passwordMismatch')));
                  },
                }),
              ]}
            >
              <Input.Password
                prefix={<LockOutlined />}
                placeholder={t('register.confirmPasswordPlaceholder')}
              />
            </Form.Item>

            {/* Business Name */}
            <Form.Item
              name="business_name"
              label={t('register.businessName')}
              rules={[
                { required: true, message: t('register.businessNameRequired') }
              ]}
            >
              <Input
                prefix={<ShopOutlined />}
                placeholder={t('register.businessNamePlaceholder')}
              />
            </Form.Item>

            {/* Contact Phone */}
            <Form.Item
              name="contact_phone"
              label={t('register.contactPhone')}
              rules={[
                { required: true, message: t('register.contactPhoneRequired') },
                { pattern: /^1[3-9]\d{9}$/, message: t('register.phoneFormatError') }
              ]}
            >
              <Input
                prefix={<PhoneOutlined />}
                placeholder={t('register.contactPhonePlaceholder')}
              />
            </Form.Item>

            {/* Terms Agreement */}
            <Form.Item
              name="agreement"
              valuePropName="checked"
              rules={[
                {
                  validator: (_, value) =>
                    value ? Promise.resolve() : Promise.reject(new Error(t('register.mustAgreeToTerms'))),
                },
              ]}
            >
              <Checkbox>{t('register.agreeToTerms')}</Checkbox>
            </Form.Item>

            {/* Submit Button */}
            <Form.Item>
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                disabled={loading}
                block
                size="large"
              >
                {loading ? t('register.registering') : t('register.registerButton')}
              </Button>
            </Form.Item>
          </Form>
        </Card>
      </div>
    </div>
  );
};

export default RegisterApplicationPage;
