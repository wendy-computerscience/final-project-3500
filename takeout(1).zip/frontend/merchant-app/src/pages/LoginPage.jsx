import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Form,
  Input,
  Button,
  Toast,
  Tabs,
  Card
} from 'antd-mobile';
import {
  ShopOutlined,
  SafetyCertificateOutlined,
  UserOutlined,
  LockOutlined
} from '@ant-design/icons';
import useMerchantStore from '../store/merchantStore';
import { login as merchantLogin } from '../api/merchant';
import './LoginPage.css';

const LoginPage = () => {
  const navigate = useNavigate();
  const { login } = useMerchantStore();
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  // 登录处理 - 调用真实后端API
  const handleLogin = async () => {
    // 验证输入
    if (!username) {
      Toast.show({ icon: 'fail', content: t('login.enterUsername') || '请输入账号' });
      return;
    }

    if (!password) {
      Toast.show({ icon: 'fail', content: t('login.enterPassword') || '请输入密码' });
      return;
    }

    if (username.length < 3) {
      Toast.show({ icon: 'fail', content: t('login.usernameTooShort') || '账号至少3个字符' });
      return;
    }

    if (password.length < 6) {
      Toast.show({ icon: 'fail', content: t('login.passwordTooShort') || '密码至少6个字符' });
      return;
    }

    try {
      setLoading(true);

      // 调用真实登录API
      const response = await merchantLogin(username, password);

      if (response.success && response.data) {
        const { token, merchant } = response.data;

        // 保存token到localStorage
        localStorage.setItem('merchant_token', token);
        localStorage.setItem('merchant_info', JSON.stringify(merchant));

        // 更新store
        login({
          id: merchant.id || merchant.merchantId,
          name: merchant.business_name || merchant.businessName || merchant.name,
          phone: merchant.phone,
          username: merchant.username,
          email: merchant.email,
          status: merchant.status,
          businessLicense: merchant.business_license || merchant.businessLicense,
          address: merchant.address,
          token
        });

        Toast.show({ icon: 'success', content: t('login.loginSuccess') || '登录成功' });

        // 跳转到订单管理页面
        navigate('/orders');
      } else {
        Toast.show({ icon: 'fail', content: response.message || t('login.loginFailed') || '登录失败' });
      }
    } catch (error) {
      console.error('Login error:', error);
      Toast.show({
        icon: 'fail',
        content: error.response?.data?.message || error.message || t('login.networkError') || '网络错误，请稍后重试'
      });
    } finally {
      setLoading(false);
    }
  };

  // 入驻申请
  const handleRegister = () => {
    navigate('/register-application');
  };

  return (
    <div className="login-page">
      {/* 装饰性背景元素 */}
      <div className="bg-decoration">
        <div className="circle circle-1"></div>
        <div className="circle circle-2"></div>
        <div className="circle circle-3"></div>
      </div>

      <div className="login-container">
        {/* Logo和标题区域 */}
        <div className="login-header">
          <div className="logo-wrapper">
            <ShopOutlined className="logo-icon" />
          </div>
          <h1 className="app-name">{t('login.platformTitle')}</h1>
          <p className="app-desc">{t('login.platformSubtitle')}</p>
        </div>

        {/* 登录卡片 */}
        <Card className="login-card">
          <Tabs
            activeKey={activeTab}
            onChange={setActiveTab}
          >
            <Tabs.Tab title={t('login.loginTab')} key="login">
              <Form className="login-form">
                {/* 账号输入 */}
                <Form.Item>
                  <div className="input-wrapper">
                    <UserOutlined className="input-icon" />
                    <Input
                      placeholder={t('login.usernamePlaceholder') || '请输入账号'}
                      value={username}
                      onChange={setUsername}
                      className="modern-input"
                    />
                  </div>
                </Form.Item>

                {/* 密码输入 */}
                <Form.Item>
                  <div className="input-wrapper">
                    <LockOutlined className="input-icon" />
                    <Input
                      placeholder={t('login.passwordPlaceholder') || '请输入密码'}
                      type="password"
                      value={password}
                      onChange={setPassword}
                      className="modern-input"
                    />
                  </div>
                </Form.Item>

                <Button
                  className="login-button"
                  color="primary"
                  size="large"
                  block
                  onClick={handleLogin}
                  loading={loading}
                  disabled={loading}
                >
                  {loading ? t('login.loggingIn') : t('login.loginNow')}
                </Button>
              </Form>
            </Tabs.Tab>

            <Tabs.Tab title={t('login.merchantRegisterSimple')} key="register">
              <div className="register-content">
                <div className="register-icon-wrapper">
                  <SafetyCertificateOutlined className="register-icon" />
                </div>
                <h3 className="register-title">{t('login.quickRegister')}</h3>
                <p className="register-desc">
                  {t('login.welcomeDesc')}
                </p>
                <Button
                  className="register-button"
                  color="primary"
                  size="large"
                  block
                  onClick={handleRegister}
                >
                  {t('login.registerNow')}
                </Button>
              </div>
            </Tabs.Tab>
          </Tabs>
        </Card>

        {/* 底部信息 */}
        <div className="login-footer">
          <p>{t('login.footer')}</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
