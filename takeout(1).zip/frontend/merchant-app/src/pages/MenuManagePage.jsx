import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Table,
  Button,
  Space,
  Tag,
  Modal,
  Form,
  Input,
  InputNumber,
  Switch,
  Select,
  message,
  Popconfirm,
  Image
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  AppstoreOutlined
} from '@ant-design/icons';
import useMerchantStore from '../store/merchantStore';
import { getDishes, addDish, updateDish, deleteDish, getDishCategories } from '../api/dishes';
import CategoryManageModal from '../components/CategoryManageModal';
import './MenuManagePage.css';

const { TextArea } = Input;
const { Option } = Select;

const MenuManagePage = () => {
  const { t } = useTranslation();
  const { menuItems, setMenuItems, merchant } = useMerchantStore();

  const [categories, setCategories] = useState([]); // 动态分类列表
  const [categoryModalVisible, setCategoryModalVisible] = useState(false); // 分类管理弹窗

  const [loading, setLoading] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [form] = Form.useForm();
  const [selectedCategory, setSelectedCategory] = useState('all'); // 改为 'all'

  // 加载分类列表
  const loadCategories = async () => {
    try {
      const response = await getDishCategories(merchant.id);

      if (response.success && response.data) {
        setCategories(response.data);
      }
    } catch (error) {
      console.error('Failed to load categories:', error);
    }
  };

  // 从后端加载菜品列表
  const loadDishes = async () => {
    try {
      setLoading(true);

      const response = await getDishes(merchant.id);

      if (response.success && response.data) {
        setMenuItems(response.data);
      } else {
        throw new Error(response.message || t('menuManage.loadFailed'));
      }
    } catch (error) {
      console.error('Failed to load dishes:', error);
      message.error(error.message || t('menuManage.loadFailed'));
    } finally {
      setLoading(false);
    }
  };

  // 初始加载菜品和分类
  useEffect(() => {
    if (merchant?.id) {
      loadDishes();
      loadCategories();
    }
  }, [merchant?.id]);

  // 新增菜品
  const handleAdd = () => {
    setEditingItem(null);
    form.resetFields();
    setIsModalVisible(true);
  };

  // 编辑菜品
  const handleEdit = (record) => {
    setEditingItem(record);
    form.setFieldsValue({
      ...record,
      available: record.available
    });
    setIsModalVisible(true);
  };

  // 保存菜品
  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      if (editingItem) {
        // 更新菜品
        const response = await updateDish(merchant.id, editingItem.id, values);

        if (response.success) {
          message.success(t('menuManage.dishUpdated'));
          await loadDishes(); // 重新加载菜品列表
        } else {
          throw new Error(response.message || t('menuManage.updateFailed'));
        }
      } else {
        // 新增菜品
        const response = await addDish(merchant.id, values);

        if (response.success) {
          message.success(t('menuManage.dishAdded'));
          await loadDishes(); // 重新加载菜品列表
        } else {
          throw new Error(response.message || t('menuManage.addFailed'));
        }
      }

      setIsModalVisible(false);
      form.resetFields();
    } catch (error) {
      console.error('Save dish failed:', error);
      message.error(error.message || t('menuManage.saveFailed'));
    } finally {
      setLoading(false);
    }
  };

  // 删除菜品
  const handleDelete = async (id) => {
    try {
      const response = await deleteDish(merchant.id, id);

      if (response.success) {
        message.success(t('menuManage.dishDeleted'));
        await loadDishes(); // 重新加载菜品列表
      } else {
        throw new Error(response.message || t('menuManage.deleteFailed'));
      }
    } catch (error) {
      console.error('Delete dish failed:', error);
      message.error(error.message || t('menuManage.deleteFailed'));
    }
  };

  // 上下架
  const handleStatusChange = async (id, checked) => {
    try {
      const response = await updateDish(merchant.id, id, {
        status: checked ? 'available' : 'unavailable'
      });

      if (response.success) {
        message.success(checked ? t('menuManage.dishAvailable') : t('menuManage.dishUnavailable'));
        await loadDishes(); // 重新加载菜品列表
      } else {
        throw new Error(response.message || t('menuManage.statusUpdateFailed'));
      }
    } catch (error) {
      console.error('Toggle status failed:', error);
      message.error(error.message || t('menuManage.statusUpdateFailed'));
    }
  };

  // 显示所有菜品（移除了分类筛选）
  const filteredMenuList = menuItems;

  // 根据 category_id 获取分类名称
  const getCategoryName = (categoryId) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : t('menuManage.uncategorized') || '未分类';
  };

  // 表格列
  const columns = [
    {
      title: t('menuManage.image'),
      dataIndex: 'image',
      key: 'image',
      width: 80,
      render: (image) => (
        <Image
          src={image}
          width={60}
          height={60}
          style={{ borderRadius: '8px', objectFit: 'cover' }}
          placeholder
          fallback="https://via.placeholder.com/60"
        />
      )
    },
    {
      title: t('menuManage.dishName'),
      dataIndex: 'name',
      key: 'name',
      width: 150
    },
    {
      title: t('menuManage.category'),
      dataIndex: 'category_id',  // 使用 category_id
      key: 'category_id',
      width: 100,
      render: (category_id) => <Tag color="blue">{getCategoryName(category_id)}</Tag>
    },
    {
      title: t('menuManage.price'),
      dataIndex: 'price',
      key: 'price',
      width: 100,
      render: (price) => (
        <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#FF6B00' }}>
          ${parseFloat(price || 0).toFixed(2)}
        </div>
      )
    },
    {
      title: t('menuManage.stock'),
      dataIndex: 'stock',
      key: 'stock',
      width: 100,
      render: (stock) => (
        <span style={{ color: stock === 0 ? '#FF4D4F' : stock < 20 ? '#FF9500' : '#52C41A' }}>
          {stock} {t('menuManage.portions')}
        </span>
      )
    },
    {
      title: t('menuManage.sales'),
      dataIndex: 'sales',
      key: 'sales',
      width: 100,
      render: (sales) => <span>{sales} {t('menuManage.sold')}</span>
    },
    {
      title: t('menuManage.prepTime'),
      dataIndex: 'prepTime',
      key: 'prepTime',
      width: 100,
      render: (prepTime) => <span>{prepTime} {t('menuManage.minutes')}</span>
    },
    {
      title: t('menuManage.status'),
      dataIndex: 'available',
      key: 'available',
      width: 120,
      render: (available, record) => (
        <Switch
          checked={available}
          checkedChildren={t('menuManage.available')}
          unCheckedChildren={t('menuManage.unavailable')}
          onChange={(checked) => handleStatusChange(record.id, checked)}
        />
      )
    },
    {
      title: t('menuManage.actions'),
      key: 'action',
      width: 150,
      fixed: 'right',
      render: (_, record) => (
        <Space>
          <Button
            type="link"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
          >
            {t('common.edit')}
          </Button>
          <Popconfirm
            title={t('menuManage.confirmDelete')}
            onConfirm={() => handleDelete(record.id)}
            okText={t('common.yes')}
            cancelText={t('common.no')}
          >
            <Button type="link" danger icon={<DeleteOutlined />}>
              {t('common.delete')}
            </Button>
          </Popconfirm>
        </Space>
      )
    }
  ];

  return (
    <div className="menu-manage-page" style={{ padding: 24, background: '#f5f5f5', minHeight: '100vh' }}>
      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h2 style={{ margin: 0, fontSize: 20, fontWeight: 'bold' }}>{t('menuManage.title')}</h2>
          <Space>
            <Button
              icon={<AppstoreOutlined />}
              onClick={() => setCategoryModalVisible(true)}
            >
              {t('categoryManage.manage') || '分类管理'}
            </Button>
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAdd}>
              {t('menuManage.addDish')}
            </Button>
          </Space>
        </div>

        <Table
          columns={columns}
          dataSource={filteredMenuList}
          rowKey="id"
          loading={loading}
          pagination={{
            pageSize: 10,
            showTotal: (total) => `${t('menuManage.total')} ${total} ${t('menuManage.dishes')}`
          }}
          scroll={{ x: 1200 }}
        />
      </Card>

      {/* 新增/编辑弹窗 */}
      <Modal
        title={editingItem ? t('menuManage.editDish') : t('menuManage.addNewDish')}
        open={isModalVisible}
        onOk={handleSave}
        onCancel={() => {
          setIsModalVisible(false);
          form.resetFields();
        }}
        width={600}
        okText={t('common.save')}
        cancelText={t('common.cancel')}
        confirmLoading={loading}
      >
        <Form
          form={form}
          layout="vertical"
          initialValues={{
            available: true,
            stock: 100,
            prepTime: 15
          }}
        >
          <Form.Item
            name="name"
            label={t('menuManage.dishName')}
            rules={[{ required: true, message: t('menuManage.dishNameRequired') }]}
          >
            <Input placeholder={t('menuManage.dishNamePlaceholder')} />
          </Form.Item>

          <Form.Item
            name="category_id"
            label={t('menuManage.category')}
            rules={[{ required: true, message: t('menuManage.categoryRequired') }]}
          >
            <Select placeholder={t('menuManage.selectCategory')}>
              {categories.map(cat => (
                <Option key={cat.id} value={cat.id}>{cat.name}</Option>
              ))}
            </Select>
          </Form.Item>

          <Space style={{ width: '100%' }} size="large">
            <Form.Item
              name="price"
              label={t('menuManage.price')}
              rules={[{ required: true, message: t('menuManage.priceRequired') }]}
            >
              <InputNumber
                min={0}
                precision={2}
                prefix="$"
                placeholder={t('menuManage.pricePlaceholder')}
                style={{ width: 150 }}
              />
            </Form.Item>

            <Form.Item
              name="stock"
              label={t('menuManage.stock')}
              rules={[{ required: true, message: t('menuManage.stockRequired') }]}
            >
              <InputNumber
                min={0}
                placeholder={t('menuManage.stockPlaceholder')}
                style={{ width: 150 }}
              />
            </Form.Item>

            <Form.Item
              name="prepTime"
              label={t('menuManage.prepTimeLabel')}
              rules={[{ required: true, message: t('menuManage.prepTimeRequired') }]}
            >
              <InputNumber
                min={1}
                max={120}
                placeholder={t('menuManage.minutesPlaceholder')}
                style={{ width: 150 }}
              />
            </Form.Item>
          </Space>

          <Form.Item name="description" label={t('menuManage.description')}>
            <TextArea
              rows={3}
              placeholder={t('menuManage.descriptionPlaceholder')}
              maxLength={200}
              showCount
            />
          </Form.Item>

          <Form.Item name="image" label={t('menuManage.imageURL')}>
            <Input placeholder={t('menuManage.imageURLPlaceholder')} />
          </Form.Item>

          <Form.Item name="available" label={t('menuManage.availableForSale')} valuePropName="checked">
            <Switch checkedChildren={t('menuManage.available')} unCheckedChildren={t('menuManage.unavailable')} />
          </Form.Item>
        </Form>
      </Modal>

      {/* 分类管理弹窗 */}
      <CategoryManageModal
        visible={categoryModalVisible}
        onClose={() => setCategoryModalVisible(false)}
        merchantId={merchant?.id}
        onCategoriesUpdated={loadCategories}
      />
    </div>
  );
};

export default MenuManagePage;
