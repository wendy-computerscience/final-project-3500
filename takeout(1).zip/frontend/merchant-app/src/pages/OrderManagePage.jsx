import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Button,
  Divider,
  Toast,
  Dialog,
  Collapse,
  Tag,
  Loading
} from 'antd-mobile';
import {
  CheckOutline,
  CloseOutline,
  MessageOutline,
  DeleteOutline,
  CheckCircleOutline
} from 'antd-mobile-icons';
import useMerchantStore from '../store/merchantStore';
import { getOrders, acceptOrder, rejectOrder, completePreparation, confirmPickup } from '../api/orders';
import './OrderManagePage.css';

const OrderManagePage = () => {
  const { t } = useTranslation();
  const { orders, updateOrder, merchant, setOrders } = useMerchantStore();
  const [activeTab, setActiveTab] = useState('paid'); // 改为 'paid' - 已支付等待接单
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [ordersList, setOrdersList] = useState({
    paid: [],        // 已支付，等待商家接单
    preparing: [],   // 备餐中
    ready: [],       // 备餐完成，待取餐
    delivering: [],  // 配送中
    completed: []    // 已完成
  });

  // 从后端加载订单
  const loadOrders = async () => {
    try {
      setLoading(true);
      setError(null);

      // 调用后端 API 获取订单
      const response = await getOrders(merchant.id, { status: activeTab });

      if (response.success && response.data) {
        // 更新 store 中的订单数据 - 后端返回 { orders: [...], total, page, pageSize }
        setOrders(response.data.orders || []);
      } else {
        throw new Error(response.message || t('orderManage.loadFailed'));
      }
    } catch (err) {
      console.error('Failed to load orders:', err);
      setError(err.message || t('orderManage.loadFailed'));
      Toast.show({
        icon: 'fail',
        content: err.message || t('orderManage.loadFailed')
      });
    } finally {
      setLoading(false);
    }
  };

  // 从 store 加载订单并分组
  useEffect(() => {
    const grouped = {
      paid: [],        // 已支付，等待商家接单
      preparing: [],   // 备餐中
      ready: [],       // 备餐完成，待取餐
      delivering: [],  // 配送中
      completed: []    // 已完成
    };

    // 确保 orders 是数组
    const orderArray = Array.isArray(orders) ? orders : [];

    orderArray.forEach(order => {
      if (grouped[order.status]) {
        grouped[order.status].push(order);
      }
    });

    setOrdersList(grouped);
  }, [orders]);

  // 监听 activeTab 变化,重新加载订单
  useEffect(() => {
    if (merchant?.id) {
      loadOrders();
    }
  }, [activeTab, merchant?.id]);

  // 获取当前标签页的订单数据
  const getCurrentOrders = () => {
    return ordersList[activeTab] || [];
  };

  // 获取各状态的订单数量
  const getStatusCount = (status) => {
    return ordersList[status]?.length || 0;
  };

  // 接单处理
  const handleAcceptOrder = async (orderId) => {
    try {
      setLoading(true);

      // 调用后端 API 接单
      const response = await acceptOrder(merchant.id, orderId, 30); // 默认预计30分钟

      if (response.success) {
        Toast.show({
          icon: 'success',
          content: t('orderManage.acceptSuccess')
        });
        // 重新加载订单列表
        await loadOrders();
      } else {
        throw new Error(response.message || t('orderManage.acceptFailed'));
      }
    } catch (error) {
      console.error('Accept order failed:', error);
      Toast.show({ icon: 'fail', content: error.message || t('orderManage.acceptFailed') });
    } finally {
      setLoading(false);
    }
  };

  // 拒单处理
  const handleRejectOrder = (orderId) => {
    Dialog.confirm({
      title: t('orderManage.rejectOrder'),
      content: t('orderManage.confirmRejectOrder'),
      confirmText: t('orderManage.confirm'),
      cancelText: t('orderManage.cancel'),
      onConfirm: async () => {
        try {
          setLoading(true);

          // 调用后端 API 拒单
          const response = await rejectOrder(merchant.id, orderId, '商家拒绝接单');

          if (response.success) {
            Toast.show({
              icon: 'success',
              content: t('orderManage.orderRejected')
            });
            // 重新加载订单列表
            await loadOrders();
          } else {
            throw new Error(response.message || t('orderManage.rejectFailed'));
          }
        } catch (error) {
          console.error('Reject order failed:', error);
          Toast.show({ icon: 'fail', content: error.message || t('orderManage.rejectFailed') });
        } finally {
          setLoading(false);
        }
      }
    });
  };

  // 完成制作
  const handleCompletePrep = async (orderId) => {
    try {
      setLoading(true);

      // 调用后端 API 完成制作
      const response = await completePreparation(merchant.id, orderId);

      if (response.success) {
        Toast.show({
          icon: 'success',
          content: t('orderManage.dishReady')
        });
        // 重新加载订单列表
        await loadOrders();
      } else {
        throw new Error(response.message || t('orderManage.updateFailed'));
      }
    } catch (error) {
      console.error('Complete preparation failed:', error);
      Toast.show({ icon: 'fail', content: error.message || t('orderManage.updateFailed') });
    } finally {
      setLoading(false);
    }
  };

  // 取餐完成
  const handlePickupComplete = async (orderId) => {
    try {
      setLoading(true);

      // 调用后端 API 确认取餐
      const response = await confirmPickup(merchant.id, orderId);

      if (response.success) {
        Toast.show({
          icon: 'success',
          content: t('orderManage.orderPickup')
        });
        // 重新加载订单列表
        await loadOrders();
      } else {
        throw new Error(response.message || t('orderManage.updateFailed'));
      }
    } catch (error) {
      console.error('Pickup confirmation failed:', error);
      Toast.show({ icon: 'fail', content: error.message || t('orderManage.updateFailed') });
    } finally {
      setLoading(false);
    }
  };

  // 订单卡片组件
  const OrderCard = ({ order }) => {
    const calculatePrepTime = () => {
      if (!order.actualStartTime) return '--';
      const elapsed = Math.floor((Date.now() - order.actualStartTime) / 60000);
      return `${elapsed}/${order.estimatedPrepTime} min`;
    };

    const getUrgencyStyle = () => {
      return order.isUrgent ? { borderLeftColor: '#ff4d4f', borderLeftWidth: 4 } : {};
    };

    return (
      <Card className="order-card" style={getUrgencyStyle()}>
        <div className="order-card-header">
          <div className="order-id-section">
            <span className="order-id">#{order.order_no || order.id}</span>
            {order.isUrgent && (
              <Tag color="danger" fill="solid" style={{ fontSize: 10, padding: '0 4px' }}>
                {t('orderManage.urgent')}
              </Tag>
            )}
          </div>
          <Tag fill="outline" color="purple">
            ${order.totalAmount}
          </Tag>
        </div>

        <Divider style={{ margin: '8px 0' }} />

        {/* 客户信息 */}
        <div className="customer-info">
          <div className="customer-name">
            <span className="label">{t('orderManage.customer')}:</span>
            <span className="value">{order.customerName}</span>
          </div>
        </div>

        {/* 地址 */}
        <div className="customer-address">
          <span className="label">{t('orderManage.address')}:</span>
          <span className="value">{order.customerAddress}</span>
        </div>

        {/* 菜品列表 */}
        <Collapse
          items={[
            {
              key: 'items',
              title: `${t('orderManage.dishesDetail')} (${order.items?.length || 0})`,
              children: (
                <div className="items-list">
                  {order.items?.map((item, idx) => (
                    <div key={idx} className="item-row">
                      <span className="item-name">{item.name}</span>
                      <span className="item-qty">x{item.quantity}</span>
                      <span className="item-price">${item.price}</span>
                    </div>
                  ))}
                </div>
              )
            }
          ]}
        />

        {/* 备注 */}
        {order.notes && (
          <div className="order-notes">
            <span className="label">{t('orderManage.notes')}:</span>
            <span className="value">{order.notes}</span>
          </div>
        )}

        {/* 时间信息 */}
        <div className="time-info">
          {order.actualStartTime && (
            <div className="time-row">
              <span className="label">{t('orderManage.prepProgress')}:</span>
              <span className="value">{calculatePrepTime()}</span>
            </div>
          )}
          {order.estimatedDeliveryTime && (
            <div className="time-row">
              <span className="label">{t('orderManage.delivery')}:</span>
              <span className="value">{order.estimatedDeliveryTime}</span>
            </div>
          )}
          {order.remark && (
            <div className="time-row">
              <span className="label">{t('orderManage.review')}:</span>
              <span className="value rating">
                {'⭐'.repeat(order.rating)} {order.remark}
              </span>
            </div>
          )}
        </div>

        {/* 操作按钮 */}
        <div className="order-actions">
          {activeTab === 'paid' && (
            <>
              <Button
                className="action-btn accept-btn"
                size="small"
                block
                color="success"
                icon={<CheckOutline />}
                onClick={() => handleAcceptOrder(order.id)}
                loading={loading}
              >
                {t('orderManage.acceptOrder')}
              </Button>
              <Button
                className="action-btn reject-btn"
                size="small"
                block
                color="danger"
                icon={<CloseOutline />}
                onClick={() => handleRejectOrder(order.id)}
                disabled={loading}
              >
                {t('orderManage.reject')}
              </Button>
            </>
          )}

          {activeTab === 'preparing' && (
            <Button
              className="action-btn complete-btn"
              size="small"
              block
              color="success"
              icon={<CheckCircleOutline />}
              onClick={() => handleCompletePrep(order.id)}
              loading={loading}
            >
              {t('orderManage.completePrep')}
            </Button>
          )}

          {activeTab === 'ready' && (
            <>
              <Button
                className="action-btn pickup-btn"
                size="small"
                block
                color="success"
                icon={<CheckCircleOutline />}
                onClick={() => handlePickupComplete(order.id)}
                loading={loading}
              >
                {t('orderManage.confirmPickup')}
              </Button>
              <Button
                size="mini"
                fill="outline"
                color="primary"
                icon={<MessageOutline />}
              >
                {t('orderManage.notes')}
              </Button>
            </>
          )}

          {activeTab === 'completed' && (
            <Button
              size="mini"
              fill="outline"
              color="danger"
              icon={<DeleteOutline />}
            >
              {t('common.delete')}
            </Button>
          )}
        </div>
      </Card>
    );
  };

  const tabs = [
    {
      key: 'paid',
      title: <span>{t('orderManage.pending')}</span>
    },
    {
      key: 'preparing',
      title: <span>{t('orderManage.preparing')}</span>
    },
    {
      key: 'ready',
      title: <span>{t('orderManage.ready')}</span>
    },
    {
      key: 'delivering',
      title: <span>{t('orderManage.delivering')}</span>
    },
    {
      key: 'completed',
      title: <span>{t('orderManage.completed')}</span>
    }
  ];

  const currentOrders = getCurrentOrders();

  return (
    <div className="order-manage-page">
      {/* Tab标签页 */}
      <div className="tabs-container">
        <div className="custom-tabs">
          {tabs.map(tab => (
            <div
              key={tab.key}
              className={`tab-item ${activeTab === tab.key ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.title}
            </div>
          ))}
        </div>
      </div>

      {/* 订单列表 */}
      <div className="orders-container">
        {loading ? (
          <div className="loading-state">
            <Loading color="primary" />
            <p style={{ marginTop: 12, color: '#999' }}>{t('common.loading')}</p>
          </div>
        ) : currentOrders.length > 0 ? (
          <div className="orders-list">
            {currentOrders.map((order) => (
              <OrderCard key={order.id || order.orderId} order={order} />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-icon">📭</div>
            <p className="empty-text">{t('orderManage.noOrders')}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrderManagePage;
