import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Descriptions,
  Button,
  Space,
  Avatar,
  Tag,
  Modal,
  Form,
  Input,
  Upload,
  message,
  Divider,
  List,
  Switch,
  Spin
} from 'antd';
import {
  ShopOutlined,
  StarFilled,
  PhoneOutlined,
  EnvironmentOutlined,
  ClockCircleOutlined,
  EditOutlined,
  LogoutOutlined,
  BellOutlined,
  UploadOutlined,
  GlobalOutlined,
  DownOutlined,
  RightOutlined,
  CheckOutlined
} from '@ant-design/icons';
import useMerchantStore from '../store/merchantStore';
import { getMerchantInfo, updateMerchantInfo, logout as logoutAPI } from '../api/merchant';
import './ProfilePage.css';

const ProfilePage = () => {
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const { merchant, orders, updateMerchant, logout: logoutStore } = useMerchantStore();

  const [loading, setLoading] = useState(false);
  const [isEditModalVisible, setIsEditModalVisible] = useState(false);
  const [form] = Form.useForm();
  const [merchantData, setMerchantData] = useState(null);
  const [languageExpanded, setLanguageExpanded] = useState(false);

  // 语言选项
  const languageOptions = [
    { label: '中文', value: 'zh' },
    { label: 'English', value: 'en' }
  ];

  // 获取当前语言标签
  const getCurrentLanguageLabel = () => {
    const current = languageOptions.find(opt => opt.value === i18n.language);
    return current ? current.label : '中文';
  };

  // 切换语言
  const handleLanguageChange = (value) => {
    i18n.changeLanguage(value);
    localStorage.setItem('language', value);
    setLanguageExpanded(false);
    message.success(value === 'zh' ? '语言已切换为中文' : 'Language switched to English');
  };

  // Load merchant information
  useEffect(() => {
    const loadMerchantProfile = async () => {
      if (!merchant?.id) {
        return;
      }

      try {
        setLoading(true);

        // Call real API to get merchant profile
        const response = await getMerchantInfo(merchant.id);

        if (response.success && response.data) {
          // Calculate statistics from orders
          const totalOrders = orders.length;
          const completedOrders = orders.filter(o => o.rating);
          const avgRating = completedOrders.length > 0
            ? (completedOrders.reduce((sum, o) => sum + o.rating, 0) / completedOrders.length).toFixed(1)
            : (response.data.rating || 0);

          // Merge API data with calculated stats
          const enrichedData = {
            ...response.data,
            rating: avgRating,
            totalOrders: totalOrders,
            notificationEnabled: response.data.notificationEnabled !== undefined
              ? response.data.notificationEnabled
              : true
          };

          setMerchantData(enrichedData);
        } else {
          throw new Error(response.message || 'Failed to load merchant profile');
        }
      } catch (error) {
        console.error('Failed to load merchant profile:', error);
        message.error(error.message || t('profile.loadFailed') || 'Failed to load profile');

        // Fallback to store data if API fails
        setMerchantData({
          ...merchant,
          totalOrders: orders.length,
          rating: merchant.rating || 0,
          notificationEnabled: merchant.notificationEnabled !== undefined
            ? merchant.notificationEnabled
            : true
        });
      } finally {
        setLoading(false);
      }
    };

    loadMerchantProfile();
  }, [merchant?.id, orders, t]);

  // Edit modal
  const handleEdit = () => {
    form.setFieldsValue({
      name: merchantData.name,
      category: merchantData.category,
      phone: merchantData.phone,
      address: merchantData.address,
      businessHours: merchantData.businessHours,
      description: merchantData.description
    });
    setIsEditModalVisible(true);
  };

  // Save changes
  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      // Call real API to update merchant profile
      const response = await updateMerchantInfo(merchant.id, values);

      if (response.success) {
        // Update store
        updateMerchant({
          ...values,
          shopName: values.name
        });

        // Update local state
        setMerchantData(prev => ({
          ...prev,
          ...values
        }));

        message.success(t('profile.updateSuccess'));
        setIsEditModalVisible(false);
      } else {
        throw new Error(response.message || 'Update failed');
      }
    } catch (error) {
      console.error('Update failed:', error);
      message.error(error.message || t('profile.updateFailed') || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  // Logout
  const handleLogout = () => {
    Modal.confirm({
      title: t('profile.confirmLogoutTitle'),
      content: t('profile.confirmLogoutContent'),
      okText: t('profile.confirm'),
      cancelText: t('profile.cancel'),
      onOk: async () => {
        try {
          // Call logout API
          await logoutAPI();

          // Clear store
          logoutStore();

          // Navigate to login
          navigate('/login');

          message.success(t('profile.logoutSuccess'));
        } catch (error) {
          console.error('Logout error:', error);
          // Force logout even if error
          logoutStore();
          navigate('/login');
        }
      }
    });
  };

  // Toggle notification
  const handleNotificationToggle = (checked) => {
    updateMerchant({ notificationEnabled: checked });
    setMerchantData(prev => ({ ...prev, notificationEnabled: checked }));
    message.success(checked ? t('profile.notificationEnabled') : t('profile.notificationDisabled'));
  };

  // Menu items
  const menuItems = [
    {
      key: 'notification',
      icon: <BellOutlined />,
      title: t('profile.notificationTitle'),
      description: t('profile.notificationDesc'),
      extra: (
        <Switch
          checked={merchantData?.notificationEnabled}
          onChange={handleNotificationToggle}
        />
      )
    }
  ];

  // Loading state
  if (loading || !merchantData) {
    return (
      <div className="merchant-profile-page">
        <Card>
          <div style={{ textAlign: 'center', padding: '50px 0' }}>
            <Spin size="large" />
            <p style={{ marginTop: 20, color: '#999' }}>{t('common.loading')}</p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="merchant-profile-page">
      {/* Merchant info card */}
      <Card className="merchant-info-card">
        <div className="merchant-header">
          <div className="merchant-avatar-section">
            <Avatar
              size={80}
              src={merchantData.avatar}
              icon={<ShopOutlined />}
            />
            <div className="merchant-basic-info">
              <h2>{merchantData.name}</h2>
              <Space size={12}>
                <Tag color="blue">{merchantData.category}</Tag>
                <span className="merchant-rating">
                  <StarFilled style={{ color: '#FFB800', marginRight: 4 }} />
                  {merchantData.rating}
                </span>
                <Tag color={merchantData.status === 'active' ? 'green' : 'red'}>
                  {merchantData.status === 'active' ? t('profile.operating') : t('profile.closed')}
                </Tag>
              </Space>
            </div>
          </div>
          <Button
            type="primary"
            icon={<EditOutlined />}
            onClick={handleEdit}
          >
            {t('profile.editProfile')}
          </Button>
        </div>

        <Divider />

        <Descriptions column={2} styles={{ label: { fontWeight: 600 } }}>
          <Descriptions.Item
            label={<><PhoneOutlined /> {t('profile.phone')}</>}
          >
            {merchantData.phone}
          </Descriptions.Item>
          <Descriptions.Item
            label={<><ClockCircleOutlined /> {t('profile.businessHours')}</>}
          >
            {merchantData.businessHours}
          </Descriptions.Item>
          <Descriptions.Item
            label={<><EnvironmentOutlined /> {t('profile.address')}</>}
            span={2}
          >
            {merchantData.address}
          </Descriptions.Item>
          <Descriptions.Item
            label={t('profile.description')}
            span={2}
          >
            {merchantData.description}
          </Descriptions.Item>
          <Descriptions.Item
            label={t('profile.license')}
            span={2}
          >
            {merchantData.license}
          </Descriptions.Item>
        </Descriptions>

        <Divider />

        <div className="merchant-stats">
          <div className="stat-item">
            <div className="stat-value">{merchantData.totalOrders}</div>
            <div className="stat-label">{t('profile.totalOrders')}</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">{merchantData.rating}</div>
            <div className="stat-label">{t('profile.rating')}</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">98.5%</div>
            <div className="stat-label">{t('profile.goodRating')}</div>
          </div>
        </div>
      </Card>

      {/* Settings menu */}
      <Card className="menu-card" title={t('profile.settings')}>
        <List
          dataSource={menuItems}
          renderItem={item => (
            <List.Item
              key={item.key}
              onClick={item.onClick}
              style={{ cursor: item.onClick ? 'pointer' : 'default' }}
              extra={item.extra}
            >
              <List.Item.Meta
                avatar={<div className="menu-icon">{item.icon}</div>}
                title={item.title}
                description={item.description}
              />
            </List.Item>
          )}
        />

        {/* 语言设置（手风琴样式） */}
        <List.Item
          onClick={() => setLanguageExpanded(!languageExpanded)}
          style={{ cursor: 'pointer', borderTop: '1px solid #f0f0f0' }}
          extra={
            <Space>
              <span style={{ color: '#999', fontSize: '14px' }}>{getCurrentLanguageLabel()}</span>
              {languageExpanded ? <DownOutlined /> : <RightOutlined />}
            </Space>
          }
        >
          <List.Item.Meta
            avatar={<div className="menu-icon"><GlobalOutlined /></div>}
            title={t('profile.languageTitle')}
            description={t('profile.languageDesc')}
          />
        </List.Item>

        {languageExpanded && (
          <div style={{
            padding: '8px 16px 16px',
            backgroundColor: '#fafafa'
          }}>
            {languageOptions.map(option => (
              <div
                key={option.value}
                onClick={() => handleLanguageChange(option.value)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '12px 16px',
                  marginTop: '8px',
                  backgroundColor: i18n.language === option.value ? '#f0f5ff' : '#fff',
                  border: i18n.language === option.value ? '1.5px solid #1890ff' : '1px solid #e5e5e5',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
              >
                <span style={{
                  fontSize: '15px',
                  color: i18n.language === option.value ? '#1890ff' : '#333',
                  fontWeight: i18n.language === option.value ? '500' : 'normal'
                }}>
                  {option.label}
                </span>
                {i18n.language === option.value && (
                  <CheckOutlined style={{ fontSize: '16px', color: '#1890ff' }} />
                )}
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Logout */}
      <Card className="logout-card">
        <Button
          block
          size="large"
          danger
          icon={<LogoutOutlined />}
          onClick={handleLogout}
        >
          {t('profile.logout')}
        </Button>
      </Card>

      {/* Edit modal */}
      <Modal
        title={t('profile.editModalTitle')}
        open={isEditModalVisible}
        onOk={handleSave}
        onCancel={() => setIsEditModalVisible(false)}
        width={600}
        okText={t('common.save')}
        cancelText={t('common.cancel')}
        confirmLoading={loading}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            name="name"
            label={t('profile.shopName')}
            rules={[{ required: true, message: t('profile.shopNameRequired') }]}
          >
            <Input prefix={<ShopOutlined />} placeholder={t('profile.shopNamePlaceholder')} />
          </Form.Item>

          <Form.Item
            name="category"
            label={t('profile.category')}
            rules={[{ required: true, message: t('profile.categoryRequired') }]}
          >
            <Input placeholder={t('profile.categoryPlaceholder')} />
          </Form.Item>

          <Form.Item
            name="phone"
            label={t('profile.phone')}
            rules={[
              { required: true, message: t('profile.phoneRequired') },
              { pattern: /^1[3-9]\d{9}$/, message: t('profile.phonePattern') }
            ]}
          >
            <Input prefix={<PhoneOutlined />} placeholder={t('profile.phonePlaceholder')} />
          </Form.Item>

          <Form.Item
            name="address"
            label={t('profile.address')}
            rules={[{ required: true, message: t('profile.addressRequired') }]}
          >
            <Input prefix={<EnvironmentOutlined />} placeholder={t('profile.addressPlaceholder')} />
          </Form.Item>

          <Form.Item
            name="businessHours"
            label={t('profile.businessHours')}
            rules={[{ required: true, message: t('profile.businessHoursRequired') }]}
          >
            <Input prefix={<ClockCircleOutlined />} placeholder={t('profile.businessHoursPlaceholder')} />
          </Form.Item>

          <Form.Item name="description" label={t('profile.description')}>
            <Input.TextArea
              rows={3}
              placeholder={t('profile.descriptionPlaceholder')}
              maxLength={200}
              showCount
            />
          </Form.Item>

          <Form.Item label={t('profile.uploadAvatar')}>
            <Upload
              listType="picture-card"
              maxCount={1}
              beforeUpload={() => {
                message.info(t('profile.uploadInDevelopment'));
                return false;
              }}
            >
              <div>
                <UploadOutlined />
                <div style={{ marginTop: 8 }}>{t('profile.uploadAvatarText')}</div>
              </div>
            </Upload>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default ProfilePage;
