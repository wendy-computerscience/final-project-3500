import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Modal,
  Table,
  Button,
  Space,
  Form,
  Input,
  InputNumber,
  message,
  Popconfirm,
  Tag
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  UpOutlined,
  DownOutlined,
  SaveOutlined,
  CloseOutlined
} from '@ant-design/icons';
import {
  getDishCategories,
  createCategory,
  updateCategory,
  deleteCategory
} from '../api/dishes';

const CategoryManageModal = ({ visible, onClose, merchantId, onCategoriesUpdated }) => {
  const { t } = useTranslation();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [isAdding, setIsAdding] = useState(false);
  const [form] = Form.useForm();
  const [editForm] = Form.useForm();

  // 加载分类列表
  const loadCategories = async () => {
    try {
      setLoading(true);
      const response = await getDishCategories(merchantId);

      if (response.success && response.data) {
        setCategories(response.data);
      }
    } catch (error) {
      console.error('加载分类失败:', error);
      message.error(t('categoryManage.loadFailed') || '加载分类失败');
    } finally {
      setLoading(false);
    }
  };

  // 初始加载
  useEffect(() => {
    if (visible && merchantId) {
      loadCategories();
    }
  }, [visible, merchantId]);

  // 添加新分类
  const handleAdd = async () => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      const response = await createCategory(merchantId, {
        name: values.name,
        sort_order: values.sort_order || categories.length + 1
      });

      if (response.success) {
        message.success(t('categoryManage.addSuccess') || '分类添加成功');
        form.resetFields();
        setIsAdding(false);
        await loadCategories();
        onCategoriesUpdated && onCategoriesUpdated();
      }
    } catch (error) {
      console.error('添加分类失败:', error);
      if (error.errorFields) {
        // 表单验证错误
        return;
      }
      message.error(error.response?.data?.message || t('categoryManage.addFailed') || '添加分类失败');
    } finally {
      setLoading(false);
    }
  };

  // 开始编辑
  const handleEdit = (record) => {
    setEditingId(record.id);
    editForm.setFieldsValue({
      name: record.name,
      sort_order: record.sort_order
    });
  };

  // 保存编辑
  const handleSaveEdit = async (id) => {
    try {
      const values = await editForm.validateFields();
      setLoading(true);

      const response = await updateCategory(merchantId, id, values);

      if (response.success) {
        message.success(t('categoryManage.updateSuccess') || '分类更新成功');
        setEditingId(null);
        await loadCategories();
        onCategoriesUpdated && onCategoriesUpdated();
      }
    } catch (error) {
      console.error('更新分类失败:', error);
      if (error.errorFields) {
        return;
      }
      message.error(error.response?.data?.message || t('categoryManage.updateFailed') || '更新分类失败');
    } finally {
      setLoading(false);
    }
  };

  // 取消编辑
  const handleCancelEdit = () => {
    setEditingId(null);
    editForm.resetFields();
  };

  // 删除分类
  const handleDelete = async (id, dishCount) => {
    if (dishCount > 0) {
      message.warning(t('categoryManage.cannotDeleteWithDishes') || `该分类下还有 ${dishCount} 个菜品，无法删除`);
      return;
    }

    try {
      setLoading(true);
      const response = await deleteCategory(merchantId, id);

      if (response.success) {
        message.success(t('categoryManage.deleteSuccess') || '分类删除成功');
        await loadCategories();
        onCategoriesUpdated && onCategoriesUpdated();
      }
    } catch (error) {
      console.error('删除分类失败:', error);
      message.error(error.response?.data?.message || t('categoryManage.deleteFailed') || '删除分类失败');
    } finally {
      setLoading(false);
    }
  };

  // 上移分类
  const handleMoveUp = async (record, index) => {
    if (index === 0) return;

    const newCategories = [...categories];
    [newCategories[index], newCategories[index - 1]] = [newCategories[index - 1], newCategories[index]];

    try {
      setLoading(true);
      // 批量更新排序
      for (let i = 0; i < newCategories.length; i++) {
        await updateCategory(merchantId, newCategories[i].id, { sort_order: i + 1 });
      }

      message.success(t('categoryManage.sortSuccess') || '排序更新成功');
      await loadCategories();
      onCategoriesUpdated && onCategoriesUpdated();
    } catch (error) {
      console.error('更新排序失败:', error);
      message.error(t('categoryManage.sortFailed') || '更新排序失败');
    } finally {
      setLoading(false);
    }
  };

  // 下移分类
  const handleMoveDown = async (record, index) => {
    if (index === categories.length - 1) return;

    const newCategories = [...categories];
    [newCategories[index], newCategories[index + 1]] = [newCategories[index + 1], newCategories[index]];

    try {
      setLoading(true);
      for (let i = 0; i < newCategories.length; i++) {
        await updateCategory(merchantId, newCategories[i].id, { sort_order: i + 1 });
      }

      message.success(t('categoryManage.sortSuccess') || '排序更新成功');
      await loadCategories();
      onCategoriesUpdated && onCategoriesUpdated();
    } catch (error) {
      console.error('更新排序失败:', error);
      message.error(t('categoryManage.sortFailed') || '更新排序失败');
    } finally {
      setLoading(false);
    }
  };

  // 表格列定义
  const columns = [
    {
      title: t('categoryManage.sortOrder') || '排序',
      dataIndex: 'sort_order',
      key: 'sort_order',
      width: 80,
      render: (sort_order) => <Tag color="blue">{sort_order}</Tag>
    },
    {
      title: t('categoryManage.categoryName') || '分类名称',
      dataIndex: 'name',
      key: 'name',
      render: (text, record) => {
        if (editingId === record.id) {
          return (
            <Form form={editForm} component={false}>
              <Form.Item
                name="name"
                style={{ margin: 0 }}
                rules={[
                  { required: true, message: t('categoryManage.nameRequired') || '请输入分类名称' },
                  { max: 50, message: t('categoryManage.nameTooLong') || '分类名称不能超过50字' }
                ]}
              >
                <Input placeholder={t('categoryManage.namePlaceholder') || '输入分类名称'} />
              </Form.Item>
            </Form>
          );
        }
        return <span style={{ fontSize: 16, fontWeight: 500 }}>{text}</span>;
      }
    },
    {
      title: t('categoryManage.dishCount') || '菜品数量',
      dataIndex: 'dish_count',
      key: 'dish_count',
      width: 100,
      render: (count) => (
        <span style={{ color: count > 0 ? '#52C41A' : '#999' }}>
          {count} {t('categoryManage.dishes') || '个'}
        </span>
      )
    },
    {
      title: t('categoryManage.actions') || '操作',
      key: 'action',
      width: 300,
      render: (_, record, index) => {
        if (editingId === record.id) {
          return (
            <Space>
              <Button
                type="primary"
                size="small"
                icon={<SaveOutlined />}
                onClick={() => handleSaveEdit(record.id)}
                loading={loading}
              >
                {t('common.save') || '保存'}
              </Button>
              <Button
                size="small"
                icon={<CloseOutlined />}
                onClick={handleCancelEdit}
              >
                {t('common.cancel') || '取消'}
              </Button>
            </Space>
          );
        }

        return (
          <Space>
            <Button
              type="link"
              size="small"
              icon={<UpOutlined />}
              disabled={index === 0}
              onClick={() => handleMoveUp(record, index)}
            >
              {t('categoryManage.moveUp') || '上移'}
            </Button>
            <Button
              type="link"
              size="small"
              icon={<DownOutlined />}
              disabled={index === categories.length - 1}
              onClick={() => handleMoveDown(record, index)}
            >
              {t('categoryManage.moveDown') || '下移'}
            </Button>
            <Button
              type="link"
              size="small"
              icon={<EditOutlined />}
              onClick={() => handleEdit(record)}
            >
              {t('common.edit') || '编辑'}
            </Button>
            <Popconfirm
              title={t('categoryManage.confirmDelete') || '确定要删除这个分类吗？'}
              description={
                record.dish_count > 0
                  ? t('categoryManage.cannotDeleteWithDishes') || `该分类下还有 ${record.dish_count} 个菜品`
                  : t('categoryManage.deleteWarning') || '删除后无法恢复'
              }
              onConfirm={() => handleDelete(record.id, record.dish_count)}
              okText={t('common.yes') || '确定'}
              cancelText={t('common.no') || '取消'}
              okButtonProps={{ danger: true }}
              disabled={record.dish_count > 0}
            >
              <Button
                type="link"
                danger
                size="small"
                icon={<DeleteOutlined />}
                disabled={record.dish_count > 0}
              >
                {t('common.delete') || '删除'}
              </Button>
            </Popconfirm>
          </Space>
        );
      }
    }
  ];

  return (
    <Modal
      title={t('categoryManage.title') || '分类管理'}
      open={visible}
      onCancel={onClose}
      width={800}
      footer={[
        <Button key="close" onClick={onClose}>
          {t('common.close') || '关闭'}
        </Button>
      ]}
    >
      <Space direction="vertical" style={{ width: '100%' }} size="large">
        {/* 添加分类表单 */}
        {isAdding ? (
          <div style={{ padding: 16, background: '#f5f5f5', borderRadius: 8 }}>
            <Form
              form={form}
              layout="inline"
              onFinish={handleAdd}
            >
              <Form.Item
                name="name"
                rules={[
                  { required: true, message: t('categoryManage.nameRequired') || '请输入分类名称' },
                  { max: 50, message: t('categoryManage.nameTooLong') || '分类名称不能超过50字' }
                ]}
                style={{ flex: 1 }}
              >
                <Input
                  placeholder={t('categoryManage.namePlaceholder') || '输入分类名称'}
                  maxLength={50}
                />
              </Form.Item>
              <Form.Item>
                <Space>
                  <Button
                    type="primary"
                    htmlType="submit"
                    icon={<PlusOutlined />}
                    loading={loading}
                  >
                    {t('categoryManage.add') || '添加'}
                  </Button>
                  <Button onClick={() => {
                    setIsAdding(false);
                    form.resetFields();
                  }}>
                    {t('common.cancel') || '取消'}
                  </Button>
                </Space>
              </Form.Item>
            </Form>
          </div>
        ) : (
          <Button
            type="dashed"
            icon={<PlusOutlined />}
            onClick={() => setIsAdding(true)}
            block
          >
            {t('categoryManage.addCategory') || '添加新分类'}
          </Button>
        )}

        {/* 分类列表 */}
        <Table
          columns={columns}
          dataSource={categories}
          rowKey="id"
          loading={loading}
          pagination={false}
          size="middle"
        />
      </Space>
    </Modal>
  );
};

export default CategoryManageModal;
