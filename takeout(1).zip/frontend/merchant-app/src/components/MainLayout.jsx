import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { TabBar } from 'antd-mobile';
import {
  AppstoreOutline,
  FileOutline,
  UnorderedListOutline,
  PieOutline,
  UserOutline
} from 'antd-mobile-icons';
import './MainLayout.css';

const MainLayout = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const contentRef = useRef(null);

  // TabBar configuration
  const tabs = [
    {
      key: '/orders',
      title: t('nav.orders'),
      icon: <FileOutline />
    },
    {
      key: '/preparation',
      title: t('nav.preparation'),
      icon: <UnorderedListOutline />
    },
    {
      key: '/menu',
      title: t('nav.menu'),
      icon: <AppstoreOutline />
    },
    {
      key: '/statistics',
      title: t('nav.statistics'),
      icon: <PieOutline />
    },
    {
      key: '/profile',
      title: t('nav.profile'),
      icon: <UserOutline />
    }
  ];

  // Scroll to top on page change
  useEffect(() => {
    if (contentRef.current) {
      contentRef.current.scrollTo(0, 0);
    }
  }, [location.pathname]);

  // Get current active tab
  const getActiveKey = () => {
    const path = location.pathname;
    const activeTab = tabs.find(tab => path.startsWith(tab.key));
    return activeTab ? activeTab.key : '/orders';
  };

  // Handle tab change
  const handleTabChange = (key) => {
    navigate(key);
  };

  return (
    <div className="main-layout">
      {/* Main content area */}
      <div className="main-content" ref={contentRef}>
        <Outlet />
      </div>

      {/* Bottom TabBar */}
      <div className="main-tabbar">
        <TabBar activeKey={getActiveKey()} onChange={handleTabChange}>
          {tabs.map(item => (
            <TabBar.Item key={item.key} icon={item.icon} title={item.title} />
          ))}
        </TabBar>
      </div>
    </div>
  );
};

export default MainLayout;
