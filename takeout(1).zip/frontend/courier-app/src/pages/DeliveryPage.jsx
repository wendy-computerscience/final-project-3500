import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Card, Tag, Button, Empty, ProgressBar, Toast } from 'antd-mobile';
import {
  EnvironmentOutline,
  ClockCircleOutline,
  CheckCircleOutline
} from 'antd-mobile-icons';
import useCourierStore from '../store/courierStore';
import { getRiderOrders } from '../api/courier';
import './DeliveryPage.css';

const DeliveryPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { courier, acceptedOrders, optimizedRoute, currentTarget, setAcceptedOrders } = useCourierStore();
  const [loading, setLoading] = useState(true);

  // 加载骑手的配送中订单
  const loadDeliveryOrders = async () => {
    if (!courier?.id) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      // 获取配送中和待取餐的订单
      const response = await getRiderOrders(courier.id, 'delivering');

      if (response.success && response.data) {
        // 更新 store 中的订单数据
        const orders = response.data.orders || [];
        setAcceptedOrders(orders);
      }
    } catch (error) {
      console.error('加载配送订单失败:', error);
      Toast.show({
        icon: 'fail',
        content: '加载订单失败'
      });
    } finally {
      setLoading(false);
    }
  };

  // 首次加载
  useEffect(() => {
    loadDeliveryOrders();
  }, [courier?.id]);

  // 定时刷新订单状态（每30秒）
  useEffect(() => {
    if (!courier?.id) return;

    const interval = setInterval(() => {
      loadDeliveryOrders();
    }, 30000); // 30秒刷新一次

    return () => clearInterval(interval);
  }, [courier?.id]);

  // 如果没有接单,显示空状态
  if (acceptedOrders.length === 0) {
    return (
      <div className="delivery-page">
        <div className="page-header">
          <h1 className="page-title">{t('delivery.title')}</h1>
        </div>
        <div className="empty-container">
          <Empty
            description={t('delivery.noTasks')}
            imageStyle={{ width: 128 }}
          />
        </div>
      </div>
    );
  }

  // 计算进度
  const currentIndex = currentTarget && optimizedRoute
    ? optimizedRoute.sequence.findIndex(
        (s) => s.orderId === currentTarget.orderId && s.type === currentTarget.type
      )
    : -1;
  const totalSteps = optimizedRoute?.sequence.length || 0;
  const progress = totalSteps > 0 ? ((currentIndex + 1) / totalSteps) * 100 : 0;

  // 获取已完成和待完成的任务
  const completedSteps = currentIndex >= 0 ? currentIndex : 0;
  const remainingSteps = totalSteps > 0 ? Math.max(0, totalSteps - completedSteps - 1) : 0;

  return (
    <div className="delivery-page">
      {/* 页面头部 */}
      <div className="page-header">
        <h1 className="page-title">{t('delivery.title')}</h1>
        <div className="order-count">
          <span className="count-number">{acceptedOrders.length}</span>
          <span className="count-label">{t('delivery.orderCount')}</span>
        </div>
      </div>

      {/* 配送进度卡片 */}
      <div className="delivery-content">
        <Card className="progress-card">
          <div className="progress-header">
            <span className="progress-title">{t('delivery.deliveryProgress')}</span>
            <Tag color="primary">
              {t('delivery.currentStation', { current: completedSteps + 1, total: totalSteps })}
            </Tag>
          </div>
          <ProgressBar
            percent={progress}
            className="progress-bar"
          />
          <div className="progress-stats">
            <div className="stat-item">
              <span className="stat-value">{completedSteps}</span>
              <span className="stat-label">{t('delivery.completed')}</span>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-item">
              <span className="stat-value current">{currentTarget ? 1 : 0}</span>
              <span className="stat-label">{t('delivery.inProgress')}</span>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-item">
              <span className="stat-value">{remainingSteps}</span>
              <span className="stat-label">{t('delivery.pending')}</span>
            </div>
          </div>
        </Card>

        {/* 当前任务 */}
        {currentTarget && (
          <div className="current-task-section">
            <h3 className="section-title">
              <span className="title-icon">🎯</span>
              {t('delivery.currentTask')}
            </h3>
            <Card className="task-card current">
              <div className="task-header">
                <Tag color="success">
                  {currentTarget.type === 'PICKUP' ? t('delivery.pickingUp') : t('delivery.delivering')}
                </Tag>
                <span className="order-id">#{currentTarget.orderId}</span>
              </div>
              <div className="task-info">
                <div className="info-row">
                  <EnvironmentOutline className="info-icon" />
                  <span>
                    {currentTarget.type === 'PICKUP'
                      ? `${t('delivery.goingTo')} ${currentTarget.restaurantName || t('delivery.restaurant')}`
                      : `${t('delivery.goingTo')} ${currentTarget.address || t('delivery.deliveryAddress')}`}
                  </span>
                </div>
              </div>
              <Button
                color="primary"
                size="large"
                block
                onClick={() => navigate('/navigation')}
              >
                {t('delivery.viewMap')}
              </Button>
            </Card>
          </div>
        )}

        {/* 配送订单列表 */}
        <div className="orders-section">
          <h3 className="section-title">
            <span className="title-icon">📦</span>
            {t('delivery.deliveryOrders')}
          </h3>
          <div className="orders-list">
            {acceptedOrders.map((order) => {
              const pickupCompleted = optimizedRoute?.sequence.findIndex(
                (s) => s.orderId === order.orderId && s.type === 'PICKUP'
              ) < currentIndex;
              const deliveryCompleted = optimizedRoute?.sequence.findIndex(
                (s) => s.orderId === order.orderId && s.type === 'DELIVERY'
              ) < currentIndex;

              return (
                <Card key={order.orderId} className="order-card">
                  <div className="order-header">
                    <div className="restaurant-name">{order.restaurantName}</div>
                    {deliveryCompleted ? (
                      <Tag color="success">{t('delivery.completed')}</Tag>
                    ) : pickupCompleted ? (
                      <Tag color="primary">{t('delivery.delivering')}</Tag>
                    ) : (
                      <Tag color="warning">{t('orderDetail.status.pendingPickup')}</Tag>
                    )}
                  </div>

                  <div className="order-steps">
                    <div className={`step ${pickupCompleted ? 'completed' : ''}`}>
                      <div className="step-icon">
                        {pickupCompleted ? (
                          <CheckCircleOutline color="#00B578" />
                        ) : (
                          <EnvironmentOutline color="#FF8C00" />
                        )}
                      </div>
                      <div className="step-content">
                        <div className="step-title">{t('delivery.pickup')}</div>
                        <div className="step-desc">{order.restaurantName}</div>
                      </div>
                    </div>

                    <div className={`step ${deliveryCompleted ? 'completed' : ''}`}>
                      <div className="step-icon">
                        {deliveryCompleted ? (
                          <CheckCircleOutline color="#00B578" />
                        ) : (
                          <EnvironmentOutline color="#1677FF" />
                        )}
                      </div>
                      <div className="step-content">
                        <div className="step-title">{t('delivery.delivery')}</div>
                        <div className="step-desc">
                          {order.userAddress || `${order.userLat}, ${order.userLng}`}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="order-footer">
                    <div className="income-info">
                      <span className="income-label">{t('delivery.income')}</span>
                      <span className="income-value">{t('common.yuan')}{order.income}</span>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* 路径统计 */}
        {optimizedRoute && (
          <Card className="route-stats-card">
            <div className="stats-title">{t('delivery.routeStats')}</div>
            <div className="stats-grid">
              <div className="stats-item">
                <span className="stats-label">{t('delivery.totalDistance')}</span>
                <span className="stats-value">{optimizedRoute.totalDistance} {t('navigation.km')}</span>
              </div>
              <div className="stats-item">
                <span className="stats-label">{t('delivery.estimatedTime')}</span>
                <span className="stats-value">{optimizedRoute.estimatedTime} {t('navigation.minute')}</span>
              </div>
              {optimizedRoute.savings && (
                <div className="stats-item">
                  <span className="stats-label">{t('delivery.savedDistance')}</span>
                  <span className="stats-value highlight">
                    {optimizedRoute.savings.savedPercentage}%
                  </span>
                </div>
              )}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default DeliveryPage;
