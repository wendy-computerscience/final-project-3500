import { useState, useEffect } from 'react';
import { Tabs, Empty, Loading, Toast } from 'antd-mobile';
import { StarOutline } from 'antd-mobile-icons';
import useCourierStore from '../store/courierStore';
import { getRiderRanking } from '../api/courier';
import './RankingPage.css';

const RankingPage = () => {
  const { courier } = useCourierStore();
  const [period, setPeriod] = useState('today');
  const [rankings, setRankings] = useState([]);
  const [loading, setLoading] = useState(false);

  const loadRankings = async () => {
    try {
      setLoading(true);

      if (!courier?.id) {
        setRankings([]);
        return;
      }

      // GET /api/riders/ranking?period=...&type=orders&riderId=...
      const result = await getRiderRanking(period, 'orders', courier.id);

      if (result.success) {
        const list = result.data || [];
        const mapped = list.map((item) => ({
          id: item.id,
          rank: item.rank,
          name: item.name || `Rider ${item.id}`,
          avatar: item.avatar || 'https://via.placeholder.com/50',
          orders: Math.round(item.value || 0),
          rating: 0,
          income: 0,
          reasons: [],
          isMe: item.isMe
        }));
        setRankings(mapped);
      } else {
        Toast.show({ content: result.message || 'Failed to load rankings', icon: 'fail' });
      }
    } catch (error) {
      console.error('Failed to load rankings:', error);
      Toast.show({ content: 'Failed to load rankings', icon: 'fail' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRankings();
  }, [period, courier?.id]);

  const getRankColor = (rank) => {
    if (rank === 1) return '#FFD700';
    if (rank === 2) return '#C0C0C0';
    if (rank === 3) return '#CD7F32';
    return '#999';
  };

  const getRankBadge = (rank) => {
    if (rank === 1) return { emoji: '🥇', text: '1st', class: 'gold' };
    if (rank === 2) return { emoji: '🥈', text: '2nd', class: 'silver' };
    if (rank === 3) return { emoji: '🥉', text: '3rd', class: 'bronze' };
    return { emoji: '', text: `${rank}th`, class: 'normal' };
  };

  return (
    <div className="ranking-page">
      <div className="page-header">
        <div className="header-content">
          <StarOutline fontSize={24} color="#FFD700" />
          <h1>Courier Rankings</h1>
        </div>
        <p className="header-subtitle">Top performers this {period === 'today' ? 'day' : period === 'week' ? 'week' : 'month'}</p>
      </div>

      <Tabs activeKey={period} onChange={setPeriod} className="ranking-tabs">
        <Tabs.Tab title="📅 Today" key="today" />
        <Tabs.Tab title="📊 This Week" key="week" />
        <Tabs.Tab title="📈 This Month" key="month" />
      </Tabs>

      {loading ? (
        <div style={{ padding: '50px', textAlign: 'center' }}>
          <Loading />
        </div>
      ) : rankings.length === 0 ? (
        <Empty description="No ranking data available" />
      ) : (
        <div className="rankings-container">
          {rankings.map((item) => {
            const badge = getRankBadge(item.rank);
            return (
              <div
                key={item.id}
                className={`rank-card ${badge.class} ${item.isMe ? 'is-me' : ''}`}
              >
                {/* 排名徽章 */}
                <div className={`rank-badge-wrapper ${badge.class}`}>
                  {badge.emoji && <span className="rank-emoji">{badge.emoji}</span>}
                  <span className="rank-number">{badge.text}</span>
                </div>

                {/* 骑手信息区域 */}
                <div className="rank-main-content">
                  <img src={item.avatar} alt={item.name} className="rank-avatar" />

                  <div className="rank-info">
                    <div className="rank-name-row">
                      <span className="rank-name">{item.name}</span>
                      {item.isMe && <span className="me-badge">You</span>}
                    </div>

                    {/* 统计数据 */}
                    <div className="rank-stats">
                      <div className="stat-item">
                        <span className="stat-icon">📦</span>
                        <span className="stat-value">{item.orders.toFixed(0)}</span>
                        <span className="stat-label">orders</span>
                      </div>
                      <div className="stat-divider"></div>
                      <div className="stat-item">
                        <span className="stat-icon">⭐</span>
                        <span className="stat-value">{item.rating}</span>
                        <span className="stat-label">rating</span>
                      </div>
                      <div className="stat-divider"></div>
                      <div className="stat-item">
                        <span className="stat-icon">💰</span>
                        <span className="stat-value">¥{item.income}</span>
                        <span className="stat-label">earned</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default RankingPage;
