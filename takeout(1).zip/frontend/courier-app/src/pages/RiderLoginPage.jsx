import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Form,
  Input,
  Button,
  Toast
} from 'antd-mobile';
import { EyeInvisibleOutline, EyeOutline } from 'antd-mobile-icons';
import { useTranslation } from 'react-i18next';
import { riderLogin } from '../api/courier';
import useCourierStore from '../store/courierStore';
import './RiderLoginPage.css';

const RiderLoginPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { login } = useCourierStore();

  // 登录处理
  const handleLogin = async (values) => {
    const { username, password } = values;

    // 基本验证
    if (!username || !password) {
      Toast.show({
        icon: 'fail',
        content: t('riderLogin.fillRequired') || '请填写账号和密码'
      });
      return;
    }

    if (username.length < 3) {
      Toast.show({
        icon: 'fail',
        content: t('riderLogin.usernameTooShort') || '账号至少3个字符'
      });
      return;
    }

    if (password.length < 6) {
      Toast.show({
        icon: 'fail',
        content: t('riderLogin.passwordTooShort') || '密码至少6个字符'
      });
      return;
    }

    setLoading(true);

    try {
      // 调用登录API（账号密码登录）
      const result = await riderLogin(username, password);

      if (result.success) {
        Toast.show({
          icon: 'success',
          content: t('riderLogin.loginSuccess') || '登录成功!'
        });

        // 保存登录信息
        login({
          id: result.data.riderId,
          name: result.data.name || '',
          phone: result.data.phone || '',
          username: username,
          vehicle: result.data.vehicle || 'electric_bike',
          token: result.data.token,
          lat: null,
          lng: null
        });

        // 保留兼容性
        localStorage.setItem('riderId', result.data.riderId);
        localStorage.setItem('riderToken', result.data.token);

        // 跳转到主页
        setTimeout(() => {
          navigate('/orders-list');
        }, 500);
      } else {
        Toast.show({
          icon: 'fail',
          content: result.message || t('riderLogin.loginFailed') || '登录失败'
        });
      }
    } catch (error) {
      console.error('登录异常:', error);
      Toast.show({
        icon: 'fail',
        content: error.response?.data?.message || error.message || t('riderLogin.networkError') || '网络错误，请稍后再试'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rider-login-page">
      <div className="login-container">
        <div className="login-card">
          <h2 className="login-title">{t('riderLogin.title') || '骑手登录'}</h2>

          <Form
            form={form}
            onFinish={handleLogin}
            layout="vertical"
            footer={
              <>
                <Button
                  block
                  type="submit"
                  color="primary"
                  size="large"
                  loading={loading}
                  disabled={loading}
                >
                  {loading ? t('riderLogin.loggingIn') || '登录中...' : t('riderLogin.login') || '登录'}
                </Button>

                <div className="register-prompt">
                  <span>{t('riderLogin.register') || '还没有账号？'}</span>
                  <a onClick={() => navigate('/register')}>{t('riderLogin.registerNow') || '立即注册'}</a>
                </div>
              </>
            }
          >
            {/* 账号输入 */}
            <Form.Item
              name="username"
              label={t('riderLogin.usernameLabel') || '账号'}
              rules={[
                { required: true, message: t('riderLogin.usernameRequired') || '请输入账号' },
                { min: 3, message: t('riderLogin.usernameTooShort') || '账号至少3个字符' }
              ]}
            >
              <Input
                placeholder={t('riderLogin.usernamePlaceholder') || '请输入账号'}
                clearable
              />
            </Form.Item>

            {/* 密码输入 */}
            <Form.Item
              name="password"
              label={t('riderLogin.passwordLabel') || '密码'}
              rules={[
                { required: true, message: t('riderLogin.passwordRequired') || '请输入密码' },
                { min: 6, message: t('riderLogin.passwordTooShort') || '密码至少6个字符' }
              ]}
              extra={
                <div
                  onClick={() => setShowPassword(!showPassword)}
                  style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', marginTop: '8px' }}
                >
                  {showPassword ? <EyeOutline /> : <EyeInvisibleOutline />}
                </div>
              }
            >
              <Input
                placeholder={t('riderLogin.passwordPlaceholder') || '请输入密码'}
                type={showPassword ? 'text' : 'password'}
                clearable
              />
            </Form.Item>

            {/* 测试账号提示 */}
            <div style={{
              padding: '10px 12px',
              background: '#fffbe6',
              color: '#ad8b00',
              fontSize: '13px',
              borderRadius: '6px',
              marginBottom: '16px'
            }}>
              {t('riderLogin.testAccount') || '测试账号'}：<strong>rider001</strong> / <strong>rider123</strong>
            </div>
          </Form>
        </div>

        <div className="login-tips">
          <p>
            {t('riderLogin.agreement') || '登录即表示同意'}
            <a>{t('riderLogin.userAgreement') || '用户协议'}</a>
            {t('riderLogin.and') || '和'}
            <a>{t('riderLogin.privacyPolicy') || '隐私政策'}</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RiderLoginPage;
