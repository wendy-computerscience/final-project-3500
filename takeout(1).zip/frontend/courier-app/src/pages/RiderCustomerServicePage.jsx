import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  List,
  Card,
  Button,
  Collapse,
  NavBar,
  Toast
} from 'antd-mobile';
import {
  PhoneFill,
  MessageFill,
  QuestionCircleOutline
} from 'antd-mobile-icons';
import './RiderCustomerServicePage.css';

const RiderCustomerServicePage = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  // FAQ数据
  const faqData = [
    {
      key: '1',
      title: t('customerService.faq1Q'),
      content: t('customerService.faq1A')
    },
    {
      key: '2',
      title: t('customerService.faq2Q'),
      content: t('customerService.faq2A')
    },
    {
      key: '3',
      title: t('customerService.faq3Q'),
      content: t('customerService.faq3A')
    },
    {
      key: '4',
      title: t('customerService.faq4Q'),
      content: t('customerService.faq4A')
    },
    {
      key: '5',
      title: t('customerService.faq5Q'),
      content: t('customerService.faq5A')
    },
    {
      key: '6',
      title: t('customerService.faq6Q'),
      content: t('customerService.faq6A')
    }
  ];

  // 拨打电话
  const handleCall = () => {
    window.location.href = 'tel:4001234567';
  };

  // 在线客服
  const handleOnlineService = () => {
    Toast.show({
      content: t('customerService.connecting'),
      duration: 1000
    });
    // 这里可以集成在线客服系统
    setTimeout(() => {
      Toast.show({ content: t('customerService.onlineInDev') });
    }, 1000);
  };

  return (
    <div className="rider-customer-service-page">
      <NavBar onBack={() => navigate(-1)}>{t('customerService.title')}</NavBar>

      <div className="service-container">
        {/* 联系方式卡片 */}
        <Card className="contact-card">
          <div className="contact-header">
            <h3>{t('customerService.contactUs')}</h3>
            <p>{t('customerService.workingHours')}</p>
          </div>

          <div className="contact-methods">
            <div className="contact-method" onClick={handleOnlineService}>
              <div className="method-icon online">
                <MessageFill fontSize={28} color="white" />
              </div>
              <div className="method-info">
                <div className="method-title">{t('customerService.onlineService')}</div>
                <div className="method-desc">{t('customerService.onlineDesc')}</div>
              </div>
              <Button color="primary" size="small">{t('customerService.contact')}</Button>
            </div>

            <div className="contact-divider"></div>

            <div className="contact-method" onClick={handleCall}>
              <div className="method-icon phone">
                <PhoneFill fontSize={28} color="white" />
              </div>
              <div className="method-info">
                <div className="method-title">{t('customerService.hotline')}</div>
                <div className="method-desc">{t('customerService.hotlineNumber')}</div>
              </div>
              <Button color="primary" fill="outline" size="small">{t('customerService.call')}</Button>
            </div>
          </div>
        </Card>

        {/* 常见问题 */}
        <div className="faq-section">
          <div className="faq-header">
            <QuestionCircleOutline fontSize={20} color="#1677FF" />
            <h3>{t('customerService.faq')}</h3>
          </div>

          <Card className="faq-card">
            <Collapse accordion>
              {faqData.map(item => (
                <Collapse.Panel key={item.key} title={item.title}>
                  <div className="faq-content">{item.content}</div>
                </Collapse.Panel>
              ))}
            </Collapse>
          </Card>
        </div>

        {/* 反馈入口 */}
        <Card className="feedback-card">
          <div className="feedback-content">
            <div className="feedback-text">
              <h4>{t('customerService.noAnswer')}</h4>
              <p>{t('customerService.submitFeedback')}</p>
            </div>
            <Button
              color="primary"
              onClick={() => Toast.show({ content: t('customerService.feedbackInDev') })}
            >
              {t('customerService.feedback')}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default RiderCustomerServicePage;
