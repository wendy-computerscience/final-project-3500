import { useState, useEffect } from 'react';
import { Tabs, Button, Toast, Dialog, Form, Input, Loading } from 'antd-mobile';
import {
  PayCircleOutline,
  TruckOutline,
  GiftOutline,
  BankcardOutline,
  RightOutline,
  BillOutline,
  ReceivePaymentOutline
} from 'antd-mobile-icons';
import { getRiderIncome, createWithdrawal } from '../api/courier';
import useCourierStore from '../store/courierStore';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import './IncomePage.css';

const IncomePage = () => {
  const { t } = useTranslation();
  const { courier } = useCourierStore();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('today');
  const [incomeData, setIncomeData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [withdrawalVisible, setWithdrawalVisible] = useState(false);
  const [withdrawing, setWithdrawing] = useState(false);
  const [form] = Form.useForm();

  const loadIncomeData = async () => {
    if (!courier?.id) return;

    try {
      setLoading(true);
      const result = await getRiderIncome(courier.id, activeTab);

      if (result.success) {
        setIncomeData(result.data);
      } else {
        Toast.show({ content: result.message, icon: 'fail' });
      }
    } catch (error) {
      Toast.show({ content: t('common.networkError'), icon: 'fail' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadIncomeData();
  }, [courier?.id, activeTab]);

  const handleWithdraw = async () => {
    try {
      const values = await form.validateFields();
      setWithdrawing(true);

      const result = await createWithdrawal(courier.id, parseFloat(values.amount), {
        bankAccount: values.bankAccount,
        bankName: values.bankName || 'Bank',
        realName: values.realName || courier?.name
      });

      if (result.success) {
        Toast.show({ content: t('income.withdrawSuccess'), icon: 'success' });
        setWithdrawalVisible(false);
        form.resetFields();
        loadIncomeData();
      } else {
        Toast.show({ content: result.message, icon: 'fail' });
      }
    } catch (error) {
      console.error('提现失败:', error);
    } finally {
      setWithdrawing(false);
    }
  };

  const data = incomeData || { totalIncome: 0, totalOrders: 0, balance: 0, avgIncome: 0 };

  const periodLabels = {
    today: t('orders.today'),
    week: t('orders.week'),
    month: t('orders.month')
  };

  return (
    <div className="income-page">
      {/* 顶部收入卡片 */}
      <div className="income-header-card">
        <div className="header-bg-pattern"></div>
        <div className="header-content">
          <div className="balance-section">
            <div className="balance-label">
              <BankcardOutline /> {t('income.balance')}
            </div>
            <div className="balance-amount">
              <span className="currency">¥</span>
              <span className="amount">{data.balance?.toFixed(2) || '0.00'}</span>
            </div>
            <Button
              className="withdraw-btn"
              onClick={() => setWithdrawalVisible(true)}
            >
              <ReceivePaymentOutline /> {t('income.withdraw')}
            </Button>
          </div>
        </div>
      </div>

      {/* 时间段切换 */}
      <div className="period-tabs">
        <Tabs
          activeKey={activeTab}
          onChange={setActiveTab}
          style={{
            '--title-font-size': '14px',
            '--active-line-color': '#1677FF',
            '--active-title-color': '#1677FF',
          }}
        >
          <Tabs.Tab title={t('orders.today')} key="today" />
          <Tabs.Tab title={t('orders.week')} key="week" />
          <Tabs.Tab title={t('orders.month')} key="month" />
        </Tabs>
      </div>

      {loading ? (
        <div className="loading-wrapper">
          <Loading color="#1677FF" />
          <p>{t('common.loading')}</p>
        </div>
      ) : (
        <>
          {/* 收入统计卡片 */}
          <div className="stats-card">
            <div className="stats-grid">
              <div className="income-stat-box">
                <div className="income-stat-icon blue">
                  <PayCircleOutline color="#1677FF" fontSize={24} />
                </div>
                <div className="income-stat-info">
                  <div className="income-stat-value">¥{data.totalIncome?.toFixed(2) || '0.00'}</div>
                  <div className="income-stat-label blue">{t('income.periodIncome', { period: periodLabels[activeTab] })}</div>
                </div>
              </div>

              <div className="income-stat-box">
                <div className="income-stat-icon orange">
                  <TruckOutline color="#FF6B00" fontSize={24} />
                </div>
                <div className="income-stat-info">
                  <div className="income-stat-value">{data.totalOrders || 0}</div>
                  <div className="income-stat-label orange">{t('income.periodOrders', { period: periodLabels[activeTab] })}</div>
                </div>
              </div>

              <div className="income-stat-box">
                <div className="income-stat-icon green">
                  <GiftOutline color="#00B578" fontSize={24} />
                </div>
                <div className="income-stat-info">
                  <div className="income-stat-value">¥{data.avgIncome?.toFixed(2) || '0.00'}</div>
                  <div className="income-stat-label green">{t('income.avgPrice')}</div>
                </div>
              </div>
            </div>
          </div>

          {/* 快捷入口 */}
          <div className="quick-actions">
            <div
              className="action-item"
              onClick={() => navigate('/withdrawal-records')}
            >
              <div className="action-icon">
                <BillOutline fontSize={22} color="#1677FF" />
              </div>
              <div className="action-text">
                <span className="action-title">{t('income.withdrawRecords')}</span>
                <span className="action-desc">{t('income.withdrawRecordsDesc')}</span>
              </div>
              <RightOutline color="#ccc" />
            </div>
          </div>

          {/* 收入说明 */}
          <div className="income-tips">
            <div className="tips-title">{t('income.incomeTips')}</div>
            <div className="tips-content">
              <p>• {t('income.tip1')}</p>
              <p>• {t('income.tip2')}</p>
              <p>• {t('income.tip3')}</p>
              <p>• {t('income.tip4')}</p>
            </div>
          </div>
        </>
      )}

      {/* 提现弹窗 */}
      <Dialog
        visible={withdrawalVisible}
        title={t('income.withdrawTitle')}
        content={
          <div className="withdraw-form">
            <Form form={form} layout="vertical">
              <Form.Item
                name="amount"
                label={t('income.withdrawAmount')}
                rules={[
                  { required: true, message: t('income.withdrawAmountPlaceholder', { amount: '0' }) },
                ]}
              >
                <Input
                  placeholder={t('income.withdrawAmountPlaceholder', { amount: data.balance?.toFixed(2) || '0.00' })}
                  type="number"
                  prefix="¥"
                />
              </Form.Item>
              <Form.Item
                name="bankAccount"
                label={t('income.bankAccount')}
                rules={[{ required: true, message: t('income.bankAccountPlaceholder') }]}
              >
                <Input placeholder={t('income.bankAccountPlaceholder')} />
              </Form.Item>
              <Form.Item name="bankName" label={t('income.bankName')}>
                <Input placeholder={t('income.bankNamePlaceholder')} />
              </Form.Item>
              <Form.Item name="realName" label={t('income.cardHolder')}>
                <Input placeholder={courier?.name || t('riderAuth.fullNamePlaceholder')} />
              </Form.Item>
            </Form>
          </div>
        }
        actions={[
          {
            key: 'cancel',
            text: t('common.cancel'),
            onClick: () => setWithdrawalVisible(false)
          },
          {
            key: 'confirm',
            text: withdrawing ? t('income.withdrawing') : t('income.confirmWithdraw'),
            onClick: handleWithdraw,
            bold: true,
            disabled: withdrawing
          }
        ]}
      />
    </div>
  );
};

export default IncomePage;
