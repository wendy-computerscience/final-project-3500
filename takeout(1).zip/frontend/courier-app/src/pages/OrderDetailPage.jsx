import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { NavBar, Card, List, Tag, Button, Toast, Loading, Divider, Dialog } from 'antd-mobile';
import { LocationOutline, ClockCircleOutline, UserOutline, PhoneFill } from 'antd-mobile-icons';
import { getOrderDetail, confirmPickup, confirmDelivery } from '../api/courier';
import useCourierStore from '../store/courierStore';
import './OrderDetailPage.css';

const OrderDetailPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { orderId } = useParams();
  const { courier } = useCourierStore();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (courier?.id) {
      fetchOrderDetail();
    } else {
      Toast.show({ content: t('orderDetail.pleaseLogin') || '请先登录' });
      setTimeout(() => navigate('/login'), 1500);
    }
  }, [orderId, courier]);

  const fetchOrderDetail = async () => {
    try {
      setLoading(true);

      try {
        const result = await getOrderDetail(orderId, courier.id);

        if (result.success && result.data) {
          setOrder(result.data);
          return;
        }
      } catch (apiError) {
        // API失败，使用mock数据
      }

      // 使用mock数据
      const mockOrder = {
        id: orderId,
        order_no: `ORD${orderId}`,
        status: 'delivering',
        delivery_fee: '5.00',
        total_amount: '68.80',
        restaurant_name: '测试餐厅',
        restaurant_address: '深圳市南山区科技园',
        restaurant_phone: '0755-12345678',
        customer_name: '张三',
        customer_address: '深圳市南山区某某小区1栋101',
        customer_phone: '13800138000',
        items: [
          { dish_name: '宫保鸡丁', quantity: 1, subtotal: '28.00' },
          { dish_name: '麻婆豆腐', quantity: 1, subtotal: '18.00' },
          { dish_name: '米饭', quantity: 2, subtotal: '4.00' }
        ],
        created_at: new Date().toLocaleString(),
        accept_time: new Date(Date.now() - 600000).toLocaleString(),
        pickup_time: new Date(Date.now() - 300000).toLocaleString()
      };

      setOrder(mockOrder);
      Toast.show({
        content: '后端服务未运行，显示模拟数据',
        duration: 2000
      });

    } catch (error) {
      console.error('Fetch order detail error:', error);
      Toast.show({ content: error.message || t('orderDetail.loadFailed') });
    } finally {
      setLoading(false);
    }
  };

  const getStatusText = (status) => {
    const map = {
      pending_accept: { text: t('orderDetail.status.pendingAccept'), color: 'default' },
      preparing: { text: t('orderDetail.status.preparing'), color: 'primary' },
      ready: { text: '待取餐', color: 'warning' },
      pending_pickup: { text: t('orderDetail.status.pendingPickup'), color: 'warning' },
      delivering: { text: t('orderDetail.status.delivering'), color: 'warning' },
      completed: { text: t('orderDetail.status.completed'), color: 'success' },
      cancelled: { text: t('orderDetail.status.cancelled'), color: 'danger' }
    };
    return map[status] || map.pending_accept;
  };

  // 确认取餐
  const handleConfirmPickup = async () => {
    try {
      const result = await confirmPickup(orderId, courier.id);
      if (result.success) {
        Toast.show({ icon: 'success', content: '取餐成功' });
        // 重新加载订单详情
        await fetchOrderDetail();
      } else {
        Toast.show({ icon: 'fail', content: result.message || '取餐失败' });
      }
    } catch (error) {
      console.error('Confirm pickup error:', error);
      Toast.show({ icon: 'fail', content: '操作失败' });
    }
  };

  // 确认送达
  const handleConfirmDelivery = async () => {
    Dialog.confirm({
      content: '确认已将订单送达？',
      confirmText: '确认送达',
      cancelText: '取消',
      onConfirm: async () => {
        try {
          const result = await confirmDelivery(orderId, courier.id);
          if (result.success) {
            Toast.show({ icon: 'success', content: '订单已完成' });
            // 跳转回订单列表
            setTimeout(() => {
              navigate('/orders', { replace: true });
            }, 1000);
          } else {
            Toast.show({ icon: 'fail', content: result.message || '送达失败' });
          }
        } catch (error) {
          console.error('Confirm delivery error:', error);
          Toast.show({ icon: 'fail', content: '操作失败' });
        }
      }
    });
  };

  if (loading) {
    return (
      <div className="order-detail-page">
        <NavBar onBack={() => navigate(-1)}>{t('orderDetail.title')}</NavBar>
        <div style={{ padding: '50px', textAlign: 'center' }}>
          <Loading />
          <p style={{ marginTop: 16, color: '#999' }}>加载中...</p>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="order-detail-page">
        <NavBar onBack={() => navigate(-1)}>{t('orderDetail.title')}</NavBar>
        <div style={{ padding: '50px', textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>📦</div>
          <p style={{ color: '#999' }}>订单不存在或无权查看</p>
        </div>
      </div>
    );
  }

  const statusInfo = getStatusText(order.status);

  return (
    <div className="order-detail-page" style={{ paddingBottom: 80 }}>
      <NavBar onBack={() => navigate(-1)}>{t('orderDetail.title')}</NavBar>

      <Card className="status-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <Tag color={statusInfo.color}>{statusInfo.text}</Tag>
            <div style={{ marginTop: 8, fontSize: 12, color: '#999' }}>
              {t('orderDetail.orderNo')}：{order.order_no}
            </div>
          </div>
          <div style={{ fontSize: 24, fontWeight: 'bold', color: '#ff6b00' }}>
            {t('common.yuan')}{order.delivery_fee}
          </div>
        </div>
      </Card>

      <Card title={t('orderDetail.pickupAddress')}>
        <List>
          <List.Item prefix={<LocationOutline />} description={order.restaurant_address}>
            {order.restaurant_name}
          </List.Item>
          <List.Item prefix={<PhoneFill />}>
            {order.restaurant_phone}
          </List.Item>
        </List>
      </Card>

      <Card title={t('orderDetail.deliveryAddress')}>
        <List>
          <List.Item prefix={<LocationOutline />} description={order.customer_address}>
            {order.customer_name}
          </List.Item>
          <List.Item prefix={<PhoneFill />}>
            {order.customer_phone}
          </List.Item>
        </List>
      </Card>

      <Card title={t('orderDetail.orderItems')}>
        {order.items?.map((item, index) => (
          <div key={index} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0' }}>
            <span>{item.dish_name} x{item.quantity}</span>
            <span style={{ color: '#999' }}>{t('common.yuan')}{item.subtotal}</span>
          </div>
        ))}
        <Divider />
        <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
          <span>{t('orderDetail.totalAmount')}</span>
          <span style={{ color: '#ff6b00' }}>{t('common.yuan')}{order.total_amount}</span>
        </div>
      </Card>

      <Card title={t('orderDetail.timeInfo')}>
        <List>
          <List.Item prefix={<ClockCircleOutline />}>
            {t('orderDetail.orderTime')}：{order.created_at}
          </List.Item>
          {order.accept_time && (
            <List.Item prefix={<ClockCircleOutline />}>
              {t('orderDetail.acceptTime')}：{order.accept_time}
            </List.Item>
          )}
          {order.pickup_time && (
            <List.Item prefix={<ClockCircleOutline />}>
              {t('orderDetail.pickupTime')}：{order.pickup_time}
            </List.Item>
          )}
          {order.delivery_time && (
            <List.Item prefix={<ClockCircleOutline />}>
              {t('orderDetail.deliveryTime')}：{order.delivery_time}
            </List.Item>
          )}
        </List>
      </Card>

      {/* 底部操作按钮 */}
      {order.status === 'ready' && (
        <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, padding: 16, background: '#fff', boxShadow: '0 -2px 8px rgba(0,0,0,0.1)', zIndex: 1000 }}>
          <Button block color="primary" size="large" onClick={handleConfirmPickup}>
            确认取餐
          </Button>
        </div>
      )}

      {order.status === 'pending_pickup' && (
        <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, padding: 16, background: '#fff', boxShadow: '0 -2px 8px rgba(0,0,0,0.1)', zIndex: 1000 }}>
          <Button block color="primary" size="large" onClick={() => navigate('/navigation')}>
            开始配送
          </Button>
        </div>
      )}

      {order.status === 'delivering' && (
        <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, padding: 16, background: '#fff', boxShadow: '0 -2px 8px rgba(0,0,0,0.1)', zIndex: 1000 }}>
          <Button block color="success" size="large" onClick={handleConfirmDelivery}>
            确认送达
          </Button>
        </div>
      )}
    </div>
  );
};

export default OrderDetailPage;
