import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  List,
  Switch,
  Selector,
  Dialog,
  Toast,
  NavBar
} from 'antd-mobile';
import {
  RightOutline
} from 'antd-mobile-icons';
import './RiderSettingsPage.css';

const RiderSettingsPage = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [doNotDisturb, setDoNotDisturb] = useState(false);
  const [orderRange, setOrderRange] = useState(['5km']);

  const rangeOptions = [
    { label: t('settings.km3'), value: '3km' },
    { label: t('settings.km5'), value: '5km' },
    { label: t('settings.km10'), value: '10km' }
  ];

  // 清除缓存
  const handleClearCache = () => {
    Dialog.confirm({
      content: t('settings.confirmClear'),
      onConfirm: async () => {
        Toast.show({
          icon: 'loading',
          content: t('settings.clearing'),
          duration: 1000
        });

        setTimeout(() => {
          Toast.show({
            icon: 'success',
            content: t('settings.cacheCleared')
          });
        }, 1000);
      }
    });
  };

  // 免打扰模式切换
  const handleDoNotDisturbChange = (checked) => {
    setDoNotDisturb(checked);
    Toast.show({
      content: checked ? t('settings.doNotDisturbOn') : t('settings.doNotDisturbOff')
    });
  };

  return (
    <div className="rider-settings-page">
      <NavBar onBack={() => navigate(-1)}>{t('settings.title')}</NavBar>

      <div className="settings-container">
        {/* 个人信息 */}
        <div className="settings-section">
          <List header={t('settings.personalInfo')}>
            <List.Item
              onClick={() => Toast.show({ content: t('settings.personalInfoInDev') })}
              extra={<RightOutline />}
            >
              {t('settings.personalProfile')}
            </List.Item>
          </List>
        </div>

        {/* 账号安全 */}
        <div className="settings-section">
          <List header={t('settings.accountSecurity')}>
            <List.Item
              onClick={() => Toast.show({ content: t('settings.phoneChangeInDev') })}
              extra={
                <>
                  <span className="phone-number">138****1234</span>
                  <RightOutline />
                </>
              }
            >
              {t('settings.phone')}
            </List.Item>
            <List.Item
              onClick={() => Toast.show({ content: t('settings.passwordChangeInDev') })}
              extra={<RightOutline />}
            >
              {t('settings.changePassword')}
            </List.Item>
          </List>
        </div>

        {/* 接单设置 */}
        <div className="settings-section">
          <List header={t('settings.orderSettings')}>
            <List.Item>
              <div className="range-setting">
                <div className="setting-label">{t('settings.orderRange')}</div>
                <Selector
                  options={rangeOptions}
                  value={orderRange}
                  onChange={(value) => {
                    setOrderRange(value);
                    Toast.show({ content: t('settings.rangeSet', { range: value[0] }) });
                  }}
                  style={{ '--border-radius': '8px' }}
                />
              </div>
            </List.Item>

            <List.Item
              extra={
                <Switch
                  checked={doNotDisturb}
                  onChange={handleDoNotDisturbChange}
                />
              }
            >
              {t('settings.doNotDisturb')}
            </List.Item>
          </List>
        </div>

        {/* 通知设置 */}
        <div className="settings-section">
          <List header={t('settings.notifications')}>
            <List.Item
              onClick={() => Toast.show({ content: t('settings.notifSettingInDev') })}
              extra={<RightOutline />}
            >
              {t('settings.newOrderNotif')}
            </List.Item>
            <List.Item
              onClick={() => Toast.show({ content: t('settings.notifSettingInDev') })}
              extra={<RightOutline />}
            >
              {t('settings.systemNotif')}
            </List.Item>
          </List>
        </div>

        {/* 其他 */}
        <div className="settings-section">
          <List header={t('settings.other')}>
            <List.Item
              onClick={handleClearCache}
              extra={
                <>
                  <span className="cache-size">{t('settings.cacheSize')}</span>
                  <RightOutline />
                </>
              }
            >
              {t('settings.clearCache')}
            </List.Item>
            <List.Item
              onClick={() => Toast.show({ content: t('settings.aboutUsInDev') })}
              extra={
                <>
                  <span className="version">{t('settings.version')}</span>
                  <RightOutline />
                </>
              }
            >
              {t('settings.aboutUs')}
            </List.Item>
            <List.Item
              onClick={() => navigate('/customer-service')}
              extra={<RightOutline />}
            >
              {t('settings.contactService')}
            </List.Item>
          </List>
        </div>
      </div>
    </div>
  );
};

export default RiderSettingsPage;
