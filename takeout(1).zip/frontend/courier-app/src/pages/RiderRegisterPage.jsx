import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Form,
  Input,
  Button,
  Toast
} from 'antd-mobile';
import { EyeInvisibleOutline, EyeOutline } from 'antd-mobile-icons';
import { useTranslation } from 'react-i18next';
import { registerRider } from '../api/courier';
import './RiderRegisterPage.css';

const RiderRegisterPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // 注册处理
  const handleRegister = async (values) => {
    const { username, password, confirmPassword, realName, phone } = values;

    // 密码确认验证
    if (password !== confirmPassword) {
      Toast.show({
        icon: 'fail',
        content: t('register.passwordNotMatch') || '两次密码不一致'
      });
      return;
    }

    setLoading(true);

    try {
      // 调用注册API
      const result = await registerRider({
        username,
        password,
        realName,
        phone
      });

      if (result.success) {
        Toast.show({
          icon: 'success',
          content: t('register.success') || '注册成功！请登录',
          duration: 2000
        });

        // 跳转到登录页
        setTimeout(() => {
          navigate('/login', {
            state: {
              username: username
            }
          });
        }, 2000);
      } else {
        Toast.show({
          icon: 'fail',
          content: result.message || t('register.failed') || '注册失败'
        });
      }
    } catch (error) {
      console.error('注册异常:', error);
      Toast.show({
        icon: 'fail',
        content: error.response?.data?.message || error.message || t('common.networkError') || '网络错误，请稍后再试'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rider-register-page">
      <div className="register-container">
        <div className="register-header">
          <h2>{t('register.welcome') || '欢迎加入我们'}</h2>
          <p>{t('register.subtitle') || '成为骑手，开启新征程'}</p>
        </div>

        <Form
          form={form}
          onFinish={handleRegister}
          layout="vertical"
          footer={
            <Button
              block
              type="submit"
              color="primary"
              size="large"
              loading={loading}
              disabled={loading}
            >
              {loading ? t('register.registering') || '注册中...' : t('register.submit') || '立即注册'}
            </Button>
          }
        >
          {/* 用户名 */}
          <Form.Item
            name="username"
            label={t('register.username') || '用户名'}
            rules={[
              { required: true, message: t('register.usernameRequired') || '请输入用户名' },
              { min: 3, message: t('register.usernameTooShort') || '用户名至少3个字符' },
              { max: 20, message: t('register.usernameTooLong') || '用户名最多20个字符' },
              { pattern: /^[a-zA-Z0-9_]+$/, message: t('register.usernameInvalid') || '用户名只能包含字母、数字和下划线' }
            ]}
          >
            <Input
              placeholder={t('register.usernamePlaceholder') || '请输入用户名'}
              clearable
            />
          </Form.Item>

          {/* 真实姓名 */}
          <Form.Item
            name="realName"
            label={t('register.realName') || '真实姓名'}
            rules={[
              { required: true, message: t('register.realNameRequired') || '请输入真实姓名' },
              { min: 2, message: t('register.realNameTooShort') || '真实姓名至少2个字符' }
            ]}
          >
            <Input
              placeholder={t('register.realNamePlaceholder') || '请输入真实姓名'}
              clearable
            />
          </Form.Item>

          {/* 手机号（可选） */}
          <Form.Item
            name="phone"
            label={t('register.phone') || '手机号（可选）'}
            rules={[
              {
                pattern: /^1[3-9]\d{9}$/,
                message: t('register.phoneInvalid') || '请输入正确的手机号'
              }
            ]}
          >
            <Input
              placeholder={t('register.phonePlaceholder') || '请输入手机号'}
              clearable
              maxLength={11}
            />
          </Form.Item>

          {/* 密码 */}
          <Form.Item
            name="password"
            label={t('register.password') || '密码'}
            rules={[
              { required: true, message: t('register.passwordRequired') || '请输入密码' },
              { min: 6, message: t('register.passwordTooShort') || '密码至少6个字符' }
            ]}
            extra={
              <div
                onClick={() => setShowPassword(!showPassword)}
                style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', marginTop: '8px' }}
              >
                {showPassword ? <EyeOutline /> : <EyeInvisibleOutline />}
              </div>
            }
          >
            <Input
              placeholder={t('register.passwordPlaceholder') || '请输入密码'}
              type={showPassword ? 'text' : 'password'}
              clearable
            />
          </Form.Item>

          {/* 确认密码 */}
          <Form.Item
            name="confirmPassword"
            label={t('register.confirmPassword') || '确认密码'}
            rules={[
              { required: true, message: t('register.confirmPasswordRequired') || '请再次输入密码' }
            ]}
            extra={
              <div
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', marginTop: '8px' }}
              >
                {showConfirmPassword ? <EyeOutline /> : <EyeInvisibleOutline />}
              </div>
            }
          >
            <Input
              placeholder={t('register.confirmPasswordPlaceholder') || '请再次输入密码'}
              type={showConfirmPassword ? 'text' : 'password'}
              clearable
            />
          </Form.Item>

          {/* 提示信息 */}
          <div className="register-tips">
            <p style={{ fontSize: '13px', color: '#999', marginBottom: '16px' }}>
              {t('register.tips') || '注册后需要完成实名认证才能接单'}
            </p>
          </div>
        </Form>

        <div className="login-link">
          <span>{t('register.hasAccount') || '已有账号？'}</span>
          <a onClick={() => navigate('/login')}>{t('register.goLogin') || '立即登录'}</a>
        </div>
      </div>
    </div>
  );
};

export default RiderRegisterPage;
