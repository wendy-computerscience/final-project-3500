import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Tabs,
  Card,
  Tag,
  Empty,
  PullToRefresh,
  Skeleton,
  DatePicker,
  Toast
} from 'antd-mobile';
import {
  ClockCircleOutline,
  TruckOutline,
  CheckCircleOutline,
  EnvironmentOutline,
  CalendarOutline
} from 'antd-mobile-icons';
import { useTranslation } from 'react-i18next';
import useCourierStore from '../store/courierStore';
import { getRiderOrders } from '../api/courier';
import './OrdersPage.css';

const OrdersPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { courier } = useCourierStore();

  const [activeTab, setActiveTab] = useState('ongoing');
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(null);
  const [datePickerVisible, setDatePickerVisible] = useState(false);
  const [error, setError] = useState(null);
  const [retrying, setRetrying] = useState(false);

  // Map backend order status to UI status
  const statusConfig = {
    pickup: { label: t('delivery.confirmPickup'), color: 'warning', icon: <ClockCircleOutline /> },
    delivering: { label: t('delivery.title'), color: 'primary', icon: <TruckOutline /> },
    completed: { label: t('orders.completed'), color: 'success', icon: <CheckCircleOutline /> },
    cancelled: { label: t('orders.cancelled'), color: 'default', icon: <ClockCircleOutline /> }
  };

  const mapOrderStatus = (status) => {
    switch (status) {
      case 'preparing':
      case 'pending_pickup':
        return 'pickup';
      case 'delivering':
        return 'delivering';
      case 'completed':
        return 'completed';
      case 'canceled':
      case 'cancelled':
        return 'cancelled';
      default:
        return 'delivering';
    }
  };

  // Load orders from API
  const loadOrders = async () => {
    if (!courier?.id) {
      setOrders([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const result = await getRiderOrders(courier.id, null, 1, 50);

      if (result.success) {
        const raw = result.data?.orders || [];

        let mapped = raw.map((o) => ({
          id: o.id,
          restaurantName: o.restaurant_name || t('orders.unknownRestaurant'),
          customerAddress: o.delivery_address || '',
          amount: parseFloat(o.total_amount || o.final_amount || 0),
          income: parseFloat(o.delivery_fee || 0),
          status: mapOrderStatus(o.status),
          createTime: o.created_at,
          completedTime: o.delivery_time || null,
          distance: o.distance_km ? parseFloat(o.distance_km) : 0
        }));

        // 如果选择了日期，进行前端过滤
        if (selectedDate) {
          const selectedDateStr = selectedDate.toISOString().split('T')[0];
          mapped = mapped.filter(order => {
            if (!order.createTime) return false;
            const orderDateStr = new Date(order.createTime).toISOString().split('T')[0];
            return orderDateStr === selectedDateStr;
          });
        }

        setOrders(mapped);
        setError(null);
      } else {
        // 改进：捕获API错误
        setError({
          message: result.message,
          type: 'api_error'
        });
      }
    } catch (err) {
      // 改进：捕获网络错误
      console.error('Failed to load orders:', err);
      setError({
        message: err.message || t('common.networkError') || '网络错误',
        type: 'network_error'
      });
    } finally {
      setLoading(false);
      setRetrying(false);
    }
  };

  useEffect(() => {
    loadOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, selectedDate, courier?.id]);

  const onRefresh = async () => {
    await loadOrders();
  };

  // 新增：处理重试
  const handleRetry = async () => {
    setRetrying(true);
    await loadOrders();
  };

  // Filter orders by tab
  const getFilteredOrders = () => {
    const base = orders;

    if (activeTab === 'ongoing') {
      return base.filter(
        (order) => order.status === 'pickup' || order.status === 'delivering'
      );
    }

    return base.filter(
      (order) => order.status === 'completed' || order.status === 'cancelled'
    );
  };

  const formatTime = (timeStr) => {
    if (!timeStr) return '';
    const date = new Date(timeStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    const timePart = timeStr.split(' ')[1] || '';
    if (days === 0) return `${t('orders.today')} ${timePart}`;
    if (days === 1) return `${t('orders.yesterday') || t('orders.today')} ${timePart}`;
    return timeStr;
  };

  const renderOrderCard = (order) => {
    const config = statusConfig[order.status] || statusConfig.delivering;

    return (
      <Card
        key={order.id}
        className="order-card"
        onClick={() => navigate(`/order/${order.id}`)}
      >
        {/* header */}
        <div className="order-header">
          <div className="restaurant-name">{order.restaurantName}</div>
          <Tag color={config.color} fill="outline">
            {config.label}
          </Tag>
        </div>

        {/* address */}
        <div className="order-address">
          <EnvironmentOutline fontSize={14} />
          <span>{order.customerAddress}</span>
        </div>

        {/* info */}
        <div className="order-info">
          <div className="info-item">
            <span className="label">{t('orderDetail.totalAmount')}</span>
            <span className="value">¥{order.amount.toFixed(2)}</span>
          </div>
          <div className="info-item">
            <span className="label">{t('orders.earnings')}</span>
            <span className="value income">¥{order.income.toFixed(2)}</span>
          </div>
          <div className="info-item">
            <span className="label">{t('orderList.deliveryDistance')}</span>
            <span className="value">{order.distance}km</span>
          </div>
        </div>

        {/* time */}
        <div className="order-time">
          <ClockCircleOutline fontSize={12} />
          <span>
            {t('orderDetail.acceptTime')}: {formatTime(order.createTime)}
          </span>
          {order.completedTime && (
            <>
              <span className="divider">|</span>
              <span>
                {t('orderDetail.deliveryTime')}: {formatTime(order.completedTime)}
              </span>
            </>
          )}
        </div>
      </Card>
    );
  };

  const filteredOrders = getFilteredOrders();

  return (
    <div className="orders-page">
      {/* header */}
      <div className="page-header">
        <h1 className="page-title">{t('orders.title')}</h1>
        <div
          className="date-filter"
          onClick={() => setDatePickerVisible(true)}
        >
          <CalendarOutline fontSize={16} />
          <span>
            {selectedDate
              ? selectedDate.toLocaleDateString()
              : t('orders.all')}
          </span>
        </div>
      </div>

      {/* tabs */}
      <div className="tabs-wrapper">
        <Tabs
          activeKey={activeTab}
          onChange={setActiveTab}
          style={{
            '--title-font-size': '15px',
            '--active-line-color': '#1677FF'
          }}
        >
          <Tabs.Tab title={t('tasks.inProgress')} key="ongoing" />
          <Tabs.Tab title={t('orders.all')} key="history" />
        </Tabs>
      </div>

      {/* list */}
      <div className="orders-content">
        <PullToRefresh onRefresh={onRefresh}>
          {loading ? (
            <div className="loading-skeleton">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="order-card">
                  <Skeleton.Title animated />
                  <Skeleton.Paragraph lineCount={3} animated />
                </Card>
              ))}
            </div>
          ) : error ? (
            <div className="error-container" style={{ padding: '40px 20px', textAlign: 'center' }}>
              <ErrorBlock
                status="default"
                title={t('common.loadFailed') || '加载失败'}
                description={error.message}
              />
              <Button
                block
                size="large"
                color="primary"
                onClick={handleRetry}
                loading={retrying}
                style={{ marginTop: '16px' }}
              >
                {retrying ? (t('common.retrying') || '正在重试') : (t('common.retry') || '重试')}
              </Button>
            </div>
          ) : filteredOrders.length > 0 ? (
            <div className="orders-list">
              {filteredOrders.map(renderOrderCard)}
            </div>
          ) : (
            <div className="empty-wrapper">
              <Empty
                description={
                  activeTab === 'ongoing'
                    ? t('delivery.noTasks')
                    : t('tasks.noTasks')
                }
              />
            </div>
          )}
        </PullToRefresh>
      </div>

      {/* date picker */}
      <DatePicker
        visible={datePickerVisible}
        onClose={() => setDatePickerVisible(false)}
        onConfirm={(date) => {
          setSelectedDate(date);
          setDatePickerVisible(false);
        }}
      />
    </div>
  );
};

export default OrdersPage;

