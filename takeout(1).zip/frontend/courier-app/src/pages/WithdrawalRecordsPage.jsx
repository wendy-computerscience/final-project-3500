import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { NavBar, List, Tag, Loading, ErrorBlock, PullToRefresh } from 'antd-mobile';
import { useTranslation } from 'react-i18next';
import { getWithdrawalRecords } from '../api/courier';
import useCourierStore from '../store/courierStore';
import './WithdrawalRecordsPage.css';

const WithdrawalRecordsPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { courier } = useCourierStore();

  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // 加载提现记录
  const loadRecords = async () => {
    if (!courier?.id) {
      setError('Rider information not available');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const result = await getWithdrawalRecords(courier.id);

      if (result.success) {
        setRecords(result.data?.records || []);
        setError(null);
      } else {
        setError(result.message);
      }
    } catch (err) {
      console.error('Failed to load withdrawal records:', err);
      setError('Failed to load records');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRecords();
  }, [courier?.id]);

  // 下拉刷新
  const handleRefresh = async () => {
    await loadRecords();
  };

  // 状态标签配置
  const getStatusTag = (status) => {
    const statusMap = {
      pending: { color: 'warning', text: t('withdrawal.statusPending') },
      processing: { color: 'primary', text: t('withdrawal.statusProcessing') },
      completed: { color: 'success', text: t('withdrawal.statusCompleted') },
      failed: { color: 'danger', text: t('withdrawal.statusFailed') }
    };
    return statusMap[status] || statusMap.pending;
  };

  // 格式化日期
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="withdrawal-records-page">
        <NavBar onBack={() => navigate(-1)}>{t('withdrawal.records')}</NavBar>
        <div className="loading-container">
          <Loading size="large" />
          <p>{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="withdrawal-records-page">
        <NavBar onBack={() => navigate(-1)}>{t('withdrawal.records')}</NavBar>
        <ErrorBlock status="default" title={t('common.loadFailed')} description={error} />
      </div>
    );
  }

  return (
    <div className="withdrawal-records-page">
      <NavBar onBack={() => navigate(-1)}>{t('withdrawal.records')}</NavBar>

      <PullToRefresh onRefresh={handleRefresh}>
        {records.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">💰</div>
            <p className="empty-title">{t('withdrawal.noRecords')}</p>
            <p className="empty-desc">{t('withdrawal.noRecordsDesc')}</p>
          </div>
        ) : (
          <List>
            {records.map((record) => {
              const statusConfig = getStatusTag(record.status);
              return (
                <List.Item
                  key={record.id}
                  description={
                    <div className="record-details">
                      <div className="record-time">{formatDate(record.createTime)}</div>
                      {record.bankAccount && (
                        <div className="record-bank">
                          {t('withdrawal.account')}: {record.bankAccount}
                        </div>
                      )}
                      {record.status === 'failed' && record.reason && (
                        <div className="record-reason">
                          {t('withdrawal.reason')}: {record.reason}
                        </div>
                      )}
                    </div>
                  }
                  extra={
                    <Tag color={statusConfig.color}>{statusConfig.text}</Tag>
                  }
                >
                  <div className="record-amount">${record.amount.toFixed(2)}</div>
                </List.Item>
              );
            })}
          </List>
        )}
      </PullToRefresh>
    </div>
  );
};

export default WithdrawalRecordsPage;
