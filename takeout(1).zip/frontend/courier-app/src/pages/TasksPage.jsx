import { useState, useEffect } from 'react';
import { Card, Tag, ProgressBar, Empty, Tabs, Toast, Button, Loading } from 'antd-mobile';
import { StarFill, GiftOutline, CheckCircleOutline } from 'antd-mobile-icons';
import { getRiderTasks, claimTaskReward } from '../api/courier';
import useCourierStore from '../store/courierStore';
import { useTranslation } from 'react-i18next';
import './TasksPage.css';

const TasksPage = () => {
  const { t } = useTranslation();
  const { courier } = useCourierStore();
  const [activeTab, setActiveTab] = useState('daily');
  const [tasks, setTasks] = useState({ daily: [], weekly: [] });
  const [loading, setLoading] = useState(false);
  const [totalEarned, setTotalEarned] = useState(0);

  // 获取任务列表
  const fetchTasks = async () => {
    try {
      setLoading(true);

      // 获取每日任务和每周任务
      const dailyResult = await getRiderTasks(courier.id, 'daily');
      const weeklyResult = await getRiderTasks(courier.id, 'weekly');

      if (dailyResult.success && weeklyResult.success) {
        setTasks({
          daily: dailyResult.data || [],
          weekly: weeklyResult.data || []
        });

        // 计算今日已领取奖励
        const earned = [...(dailyResult.data || []), ...(weeklyResult.data || [])]
          .filter(task => task.status === 'completed')
          .reduce((sum, task) => sum + parseFloat(task.reward || 0), 0);
        setTotalEarned(earned);
      } else {
        Toast.show({
          content: dailyResult.message || weeklyResult.message || t('common.loading'),
          icon: 'fail'
        });
      }
    } catch (error) {
      console.error('获取任务失败:', error);
      Toast.show({ content: t('common.loading'), icon: 'fail' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (courier?.id) {
      fetchTasks();
    }
  }, [courier?.id]);

  // 领取任务奖励
  const handleClaimReward = async (taskId) => {
    try {
      const result = await claimTaskReward(courier.id, taskId);

      if (result.success) {
        Toast.show({ content: t('tasks.rewardAmount', { amount: result.data.reward }), icon: 'success' });
        fetchTasks(); // 刷新任务列表
      } else {
        Toast.show({ content: result.message, icon: 'fail' });
      }
    } catch (error) {
      console.error('领取奖励失败:', error);
      Toast.show({ content: t('common.loading'), icon: 'fail' });
    }
  };

  // 获取当前任务列表
  const getCurrentTasks = () => {
    return tasks[activeTab] || [];
  };

  // 渲染任务卡片
  const renderTaskCard = (task) => {
    const isInProgress = task.status === 'inprogress';
    const isClaimable = task.status === 'claimable';
    const isCompleted = task.status === 'completed';

    const progressPercent = isInProgress || isClaimable
      ? (task.progressCurrent / task.progressTarget) * 100
      : 100;

    return (
      <Card key={task.id} className={`task-card ${task.status}`}>
        <div className="task-header">
          <div className="task-title">
            {t(task.titleKey) || task.titleKey}
          </div>
          {isCompleted && <Tag color="success">{t('tasks.completed')}</Tag>}
          {isClaimable && <Tag color="warning">{t('tasks.claimable')}</Tag>}
          {isInProgress && <Tag color="primary">{t('tasks.inProgress')}</Tag>}
        </div>

        <div className="task-desc">
          {t(task.descriptionKey) || task.descriptionKey}
        </div>

        {!isCompleted && (
          <div className="task-progress">
            <ProgressBar
              percent={progressPercent}
              style={{
                '--fill-color': isClaimable ? '#FF6B00' : '#1677FF',
                '--track-width': '8px'
              }}
            />
            <div className="progress-text">
              {task.progressCurrent}/{task.progressTarget}
            </div>
          </div>
        )}

        <div className="task-footer">
          <div className="task-reward">
            <GiftOutline fontSize={16} color="#FF6B00" />
            <span>{t('tasks.reward')}: ¥{task.reward}</span>
          </div>

          {isClaimable && (
            <Button
              color="primary"
              size="small"
              onClick={() => handleClaimReward(task.id)}
            >
              {t('tasks.claimReward')}
            </Button>
          )}

          {isCompleted && (
            <div className="completed-badge">
              <CheckCircleOutline fontSize={16} color="#52C41A" />
              <span>{t('tasks.claimed')}</span>
            </div>
          )}
        </div>
      </Card>
    );
  };

  const currentTasks = getCurrentTasks();

  return (
    <div className="tasks-page">
      <div className="page-header">
        <h1 className="page-title">{t('tasks.title')}</h1>
        <div className="total-rewards">
          <StarFill fontSize={20} color="#FFD700" />
          <span>{t('tasks.todayEarned')}: ¥{totalEarned.toFixed(2)}</span>
        </div>
      </div>

      <Tabs activeKey={activeTab} onChange={setActiveTab}>
        <Tabs.Tab title={t('tasks.daily')} key="daily" />
        <Tabs.Tab title={t('tasks.weekly')} key="weekly" />
      </Tabs>

      <div className="tasks-container">
        {loading ? (
          <div className="loading-container">
            <Loading />
          </div>
        ) : currentTasks.length === 0 ? (
          <Empty description={t('tasks.noTasks')} />
        ) : (
          <div className="tasks-list">
            {currentTasks.map(task => renderTaskCard(task))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TasksPage;
