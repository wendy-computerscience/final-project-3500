import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Button,
  Steps,
  Result,
  NavBar,
  Toast
} from 'antd-mobile';
import {
  CheckCircleFill,
  CloseCircleFill,
  ClockCircleFill
} from 'antd-mobile-icons';
import useCourierStore from '../store/courierStore';
import { getRiderAuthStatus } from '../api/courier';
import './AuditStatusPage.css';

const AuditStatusPage = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { courier } = useCourierStore();

  const [auditData, setAuditData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const riderId = courier?.id || localStorage.getItem('riderId');
    if (!riderId) {
      setLoading(false);
      return;
    }

    const fetchStatus = async () => {
      try {
        const result = await getRiderAuthStatus(riderId);
        if (result.success) {
          const {
            authStatus,
            realName,
            submittedAt,
            reviewedAt,
            approvedAt,
            rejectReason,
            rejectDetails,
            expectedDays = 3
          } = result.data;

          // 计算预期审核完成时间
          const expectedTime = submittedAt ? new Date(
            new Date(submittedAt).getTime() + expectedDays * 24 * 60 * 60 * 1000
          ).toLocaleDateString() : '';

          // 计算步骤时间和状态
          const steps = [
            {
              key: 'step1',
              status: 'finish',
              time: submittedAt,
              label: '已提交'
            },
            {
              key: 'step2',
              status: authStatus === 'pending' ? 'process' : 'finish',
              time: reviewedAt || '',
              label: authStatus === 'pending' ? '待审核中' : '已审核',
              expectedTime: authStatus === 'pending' ? expectedTime : ''
            },
            {
              key: 'step3',
              status: authStatus === 'approved' ? 'finish' : 'wait',
              time: approvedAt || '',
              label: authStatus === 'approved' ? '已通过' : '待通过'
            }
          ];

          setAuditData({
            status: authStatus,
            realName,
            submitTime: submittedAt,
            reviewedAt,
            rejectReason: rejectReason || '',
            rejectDetails: rejectDetails || '',
            expectedDays,
            expectedTime,
            steps
          });
        } else {
          Toast.show({
            icon: 'fail',
            content: result.message || t('auditStatus.loadFailed')
          });
        }
      } catch (error) {
        console.error('Failed to load audit status:', error);
        Toast.show({
          icon: 'fail',
          content: t('auditStatus.loadFailed')
        });
      } finally {
        setLoading(false);
      }
    };

    fetchStatus();
  }, [courier?.id, t]);

  const renderPendingStatus = () => (
    <div className="status-container">
      <Result
        status="waiting"
        title={t('auditStatus.pending')}
        description={t('auditStatus.pendingDesc')}
        icon={<ClockCircleFill style={{ fontSize: 64, color: '#FF9500' }} />}
      />

      <Card className="info-card">
        <div className="info-item">
          <span className="info-label">{t('auditStatus.submitTime')}</span>
          <span className="info-value">{auditData?.submitTime}</span>
        </div>

        {/* 新增：预期审核完成时间 */}
        {auditData?.expectedTime && (
          <div className="info-item">
            <span className="info-label">{t('auditStatus.expectedReviewTime') || '预计审核完成'}</span>
            <span className="info-value highlight" style={{ color: '#FF9500', fontWeight: 600 }}>
              {auditData.expectedTime}
            </span>
          </div>
        )}

        {/* 新增：温馨提示 */}
        <div className="tip-text" style={{ marginTop: '12px', fontSize: '13px', color: '#666', lineHeight: '1.6' }}>
          {t('auditStatus.pendingTip') || `我们将在${auditData?.expectedDays || 3}个工作日内完成审核，请耐心等待。`}
        </div>
      </Card>

      <div className="steps-card">
        <div className="steps-title">{t('auditStatus.auditProgress')}</div>
        <Steps direction="vertical" current={1}>
          {auditData?.steps.map((step, index) => (
            <Steps.Step
              key={step.key}
              title={`${t(`auditStatus.step${index + 1}`)} - ${step.label}`}
              description={
                step.time
                  ? `${t('auditStatus.completedAt') || '完成时间'}: ${step.time}`
                  : (step.expectedTime ? `${t('auditStatus.expectedBefore') || '预计'}: ${step.expectedTime}` : '')
              }
              status={step.status}
            />
          ))}
        </Steps>
      </div>
    </div>
  );

  const renderApprovedStatus = () => (
    <div className="status-container">
      <Result
        status="success"
        title={t('auditStatus.approved')}
        description={t('auditStatus.approvedDesc')}
        icon={<CheckCircleFill style={{ fontSize: 64, color: '#52C41A' }} />}
      />

      <Card className="welcome-card">
        <h3>{t('auditStatus.welcomeTitle')}</h3>
        <p>{t('auditStatus.welcomeDesc')}</p>
      </Card>

      <div className="action-section">
        <Button
          block
          size="large"
          color="primary"
          onClick={() => navigate('/orders-list')}
        >
          {t('auditStatus.startOrders')}
        </Button>
      </div>
    </div>
  );

  const renderRejectedStatus = () => (
    <div className="status-container">
      <Result
        status="error"
        title={t('auditStatus.rejected')}
        description={t('auditStatus.rejectedDesc')}
        icon={<CloseCircleFill style={{ fontSize: 64, color: '#FF4D4F' }} />}
      />

      {/* 改进：详细反馈卡片 */}
      <Card className="reason-card">
        <div className="reason-title">{t('auditStatus.rejectReason') || '拒绝原因'}</div>
        <div className="reason-content">
          {auditData?.rejectReason || t('auditStatus.defaultRejectReason') || '您提交的信息未通过审核'}
        </div>

        {/* 新增：如果有详细反馈，显示 */}
        {auditData?.rejectDetails && (
          <div className="reason-details" style={{ marginTop: '12px', padding: '8px', backgroundColor: '#fff7f0', borderRadius: '4px' }}>
            <div className="details-label" style={{ fontSize: '13px', color: '#666', marginBottom: '4px' }}>
              {t('auditStatus.details') || '详细说明'}:
            </div>
            <div className="details-content" style={{ fontSize: '14px', color: '#333', lineHeight: '1.6' }}>
              {auditData.rejectDetails}
            </div>
          </div>
        )}

        {/* 新增：显示审核时间 */}
        {auditData?.reviewedAt && (
          <div className="reviewed-time" style={{ marginTop: '12px', fontSize: '12px', color: '#999' }}>
            <span className="time-label">{t('auditStatus.reviewedAt') || '审核时间'}:</span>
            <span className="time-value" style={{ marginLeft: '8px' }}>{auditData.reviewedAt}</span>
          </div>
        )}
      </Card>

      {/* 新增：改进建议 */}
      <Card className="tips-card" style={{ marginTop: '16px' }}>
        <h4 style={{ fontSize: '15px', fontWeight: 600, marginBottom: '12px' }}>
          {t('auditStatus.improvementTips') || '改进建议'}
        </h4>
        <ul style={{ paddingLeft: '20px', margin: 0, fontSize: '13px', lineHeight: '1.8', color: '#666' }}>
          <li>{t('auditStatus.tip1') || '请确保提交的证件照片清晰完整'}</li>
          <li>{t('auditStatus.tip2') || '请确保个人信息真实有效'}</li>
          <li>{t('auditStatus.tip3') || '请按要求补充完整所需材料'}</li>
        </ul>
      </Card>

      <div className="action-section">
        <Button
          block
          size="large"
          color="primary"
          onClick={() => navigate('/auth')}
        >
          {t('auditStatus.resubmit') || '重新提交认证'}
        </Button>
      </div>
    </div>
  );

  const renderContent = () => {
    if (loading) {
      return null;
    }
    if (!auditData) {
      return renderPendingStatus();
    }
    switch (auditData.status) {
      case 'approved':
        return renderApprovedStatus();
      case 'rejected':
        return renderRejectedStatus();
      case 'pending':
      default:
        return renderPendingStatus();
    }
  };

  return (
    <div className="audit-status-page">
      <NavBar onBack={() => navigate(-1)}>{t('auditStatus.title')}</NavBar>

      <div className="audit-container">{renderContent()}</div>
    </div>
  );
};

export default AuditStatusPage;

