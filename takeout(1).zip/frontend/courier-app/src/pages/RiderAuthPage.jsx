import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Form,
  Input,
  Button,
  Steps,
  Selector,
  ImageUploader,
  DatePicker,
  Toast,
  NavBar
} from 'antd-mobile';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import useCourierStore from '../store/courierStore';
import { submitRiderAuth } from '../api/courier';
import './RiderAuthPage.css';

const RiderAuthPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { courier } = useCourierStore();

  const [currentStep, setCurrentStep] = useState(0);
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const [idFrontFiles, setIdFrontFiles] = useState([]);
  const [idBackFiles, setIdBackFiles] = useState([]);
  const [idHoldFiles, setIdHoldFiles] = useState([]);
  const [healthCertFiles, setHealthCertFiles] = useState([]);
  const [vehiclePhotoFiles, setVehiclePhotoFiles] = useState([]);

  const vehicleTypeOptions = [
    { label: t('riderAuth.scooter'), value: 'scooter' },
    { label: t('riderAuth.motorcycle'), value: 'motorcycle' },
    { label: t('riderAuth.bicycle'), value: 'bicycle' }
  ];

  // local preview uploader (no real upload)
  const localPreviewUpload = async (file) => ({
    url: URL.createObjectURL(file)
  });

  const renderStep1 = () => (
    <div className="auth-step">
      <div className="step-header">
        <h3 className="step-title">{t('riderAuth.step1')}</h3>
        <p className="step-desc">
          {t('riderAuth.step1Desc') || '请填写真实姓名和身份证号'}
        </p>
      </div>

      <Form.Item
        name="fullName"
        label={t('riderAuth.fullName')}
        rules={[
          {
            required: true,
            message: t('riderAuth.fullNameRequired') || '请输入真实姓名'
          }
        ]}
      >
        <Input
          placeholder={t('riderAuth.fullNamePlaceholder') || '请输入真实姓名'}
          clearable
        />
      </Form.Item>

      <Form.Item
        name="idNumber"
        label={t('riderAuth.idNumber')}
        rules={[
          {
            required: true,
            message: t('riderAuth.idNumberRequired') || '请输入身份证号'
          },
          {
            pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
            message: t('riderAuth.idNumberInvalid') || '请输入正确的身份证号'
          }
        ]}
      >
        <Input
          placeholder={t('riderAuth.idNumberPlaceholder') || '请输入身份证号'}
          clearable
          maxLength={18}
        />
      </Form.Item>

      <Form.Item label={t('riderAuth.idFront')}>
        <ImageUploader
          value={idFrontFiles}
          onChange={setIdFrontFiles}
          maxCount={1}
          upload={localPreviewUpload}
        />
      </Form.Item>

      <Form.Item label={t('riderAuth.idBack')}>
        <ImageUploader
          value={idBackFiles}
          onChange={setIdBackFiles}
          maxCount={1}
          upload={localPreviewUpload}
        />
      </Form.Item>

      <Form.Item label={t('riderAuth.idHold')}>
        <ImageUploader
          value={idHoldFiles}
          onChange={setIdHoldFiles}
          maxCount={1}
          upload={localPreviewUpload}
        />
      </Form.Item>
    </div>
  );

  const renderStep2 = () => (
    <div className="auth-step">
      <div className="step-header">
        <h3 className="step-title">{t('riderAuth.step2')}</h3>
        <p className="step-desc">
          {t('riderAuth.step2Desc') || '从事食品配送需要提供有效健康证'}
        </p>
      </div>

      <Form.Item
        name="healthCertExpiry"
        label={t('riderAuth.healthCertExpiry')}
        rules={[
          {
            required: true,
            message:
              t('riderAuth.healthCertExpiryRequired') || '请选择健康证有效期'
          }
        ]}
        trigger="onConfirm"
        onClick={(e, ref) => {
          ref.current?.open();
        }}
      >
        <DatePicker min={new Date()}>
          {(value) =>
            value
              ? dayjs(value).format('YYYY-MM-DD')
              : t('riderAuth.selectExpiry') || '请选择有效期'
          }
        </DatePicker>
      </Form.Item>

      <Form.Item label={t('riderAuth.healthCert')} rules={[{ required: true }]}>
        <ImageUploader
          value={healthCertFiles}
          onChange={setHealthCertFiles}
          maxCount={1}
          upload={localPreviewUpload}
        />
      </Form.Item>
    </div>
  );

  const renderStep3 = () => (
    <div className="auth-step">
      <div className="step-header">
        <h3 className="step-title">{t('riderAuth.step3')}</h3>
        <p className="step-desc">
          {t('riderAuth.step3Desc') || '请填写您的配送车辆信息'}
        </p>
      </div>

      <Form.Item
        name="vehicleType"
        label={t('riderAuth.vehicleType')}
        rules={[
          {
            required: true,
            message:
              t('riderAuth.vehicleTypeRequired') || '请选择车辆类型'
          }
        ]}
      >
        <Selector options={vehicleTypeOptions} />
      </Form.Item>

      <Form.Item
        name="licensePlate"
        label={t('riderAuth.licensePlate')}
        rules={[
          {
            required: true,
            message:
              t('riderAuth.licensePlateRequired') || '请输入车牌号'
          }
        ]}
      >
        <Input
          placeholder={
            t('riderAuth.licensePlatePlaceholder') || '请输入车牌号'
          }
          clearable
        />
      </Form.Item>

      <Form.Item
        label={t('riderAuth.vehiclePhoto')}
        rules={[{ required: true }]}
      >
        <ImageUploader
          value={vehiclePhotoFiles}
          onChange={setVehiclePhotoFiles}
          maxCount={1}
          upload={localPreviewUpload}
        />
      </Form.Item>
    </div>
  );

  const getFieldsForStep = (step) => {
    switch (step) {
      case 0:
        return ['fullName', 'idNumber'];
      case 1:
        return ['healthCertExpiry'];
      case 2:
        return ['vehicleType', 'licensePlate'];
      default:
        return [];
    }
  };

  const handleNext = async () => {
    try {
      const fields = getFieldsForStep(currentStep);
      await form.validateFields(fields);

      if (currentStep === 0) {
        if (
          !idFrontFiles.length ||
          !idBackFiles.length ||
          !idHoldFiles.length
        ) {
          Toast.show({
            content:
              t('riderAuth.uploadAllIdPhotos') || '请上传所有身份证照片'
          });
          return;
        }
      } else if (currentStep === 1) {
        if (!healthCertFiles.length) {
          Toast.show({
            content:
              t('riderAuth.uploadHealthCert') || '请上传健康证照片'
          });
          return;
        }
      }

      setCurrentStep((s) => s + 1);
    } catch (e) {
      console.error('Validation failed:', e);
    }
  };

  const handlePrev = () => {
    setCurrentStep((s) => s - 1);
  };

  const handleSubmit = async () => {
    try {
      const fields = getFieldsForStep(2);
      await form.validateFields(fields);

      if (!vehiclePhotoFiles.length) {
        Toast.show({
          content:
            t('riderAuth.uploadVehiclePhoto') || '请上传车辆照片'
        });
        return;
      }

      const riderId = courier?.id || localStorage.getItem('riderId');
      if (!riderId) {
        Toast.show({
          content: t('common.notLoggedIn') || '请先登录'
        });
        return;
      }

      setLoading(true);

      const values = form.getFieldsValue();
      const authData = {
        riderId,
        realName: values.fullName,
        idCard: values.idNumber,
        healthCert: {
          expiry: values.healthCertExpiry
        },
        vehicleInfo: {
          type: values.vehicleType,
          plate: values.licensePlate
        }
      };

      const result = await submitRiderAuth(authData);

      if (result.success) {
        Toast.show({
          icon: 'success',
          content:
            result.data?.message ||
            t('riderAuth.submitSuccess') ||
            '提交成功，等待审核',
          duration: 2000
        });

        // 延迟导航，给用户看到成功提示的时间
        setTimeout(() => {
          navigate('/audit-status', {
            state: {
              fromSubmit: true,
              submitTime: new Date().toLocaleString()
            }
          });
        }, 2000);
      } else {
        // 改进：显示更详细的错误信息
        const errorMessage = result.data?.details ||
                            result.message ||
                            t('riderAuth.submitFailed') ||
                            '提交失败，请重试';

        Toast.show({
          icon: 'fail',
          content: errorMessage,
          duration: 3000
        });

        // 如果是字段验证错误，显示详细信息
        if (result.data?.fieldErrors) {
          console.error('字段验证错误:', result.data.fieldErrors);
        }
      }
    } catch (e) {
      console.error('Submit failed:', e);
      Toast.show({
        icon: 'fail',
        content: e.message || t('riderAuth.submitFailed') || '提交失败，请重试',
        duration: 3000
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rider-auth-page">
      <NavBar onBack={() => navigate(-1)}>
        {t('riderAuth.title')}
      </NavBar>

      <div className="auth-container">
        <div className="steps-container">
          <Steps current={currentStep}>
            <Steps.Step title={t('riderAuth.step1')} />
            <Steps.Step title={t('riderAuth.step2')} />
            <Steps.Step title={t('riderAuth.step3')} />
          </Steps>
        </div>

        <div className="form-container">
          <Form form={form} layout="vertical">
            {currentStep === 0 && renderStep1()}
            {currentStep === 1 && renderStep2()}
            {currentStep === 2 && renderStep3()}
          </Form>
        </div>

        <div className="action-buttons">
          {currentStep > 0 && (
            <Button
              block
              size="large"
              fill="outline"
              onClick={handlePrev}
            >
              {t('riderAuth.prevStep')}
            </Button>
          )}

          {currentStep < 2 && (
            <Button
              block
              size="large"
              color="primary"
              onClick={handleNext}
            >
              {t('riderAuth.nextStep')}
            </Button>
          )}

          {currentStep === 2 && (
            <Button
              block
              size="large"
              color="primary"
              onClick={handleSubmit}
              loading={loading}
            >
              {t('riderAuth.submitAudit')}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default RiderAuthPage;

