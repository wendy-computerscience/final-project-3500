import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Tag,
  Button,
  Loading,
  ErrorBlock,
  Tabs,
  PullToRefresh,
  Toast,
  Badge,
  Space
} from 'antd-mobile';
import {
  EnvironmentOutline,
  ClockCircleOutline,
  CheckCircleOutline
} from 'antd-mobile-icons';
import { getRecommendedOrders, optimizeRoute, acceptOrder as acceptOrderAPI, getPredictiveNotification } from '../api/courier';
import useCourierStore from '../store/courierStore';
import './OrderListPage.css';

const OrderListPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { courier, isLoggedIn, acceptOrder, acceptMultipleOrders, setOptimizedRoute, setCurrentTarget } =
    useCourierStore();

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [sortBy, setSortBy] = useState('smart');
  const [selectedOrders, setSelectedOrders] = useState([]);

  // 检查登录状态，未登录重定向
  useEffect(() => {
    if (!courier || !isLoggedIn) {
      console.warn('骑手未登录，重定向到登录页');
      navigate('/login', { replace: true });
    }
  }, [courier, isLoggedIn, navigate]);

  // 获取推荐订单
  const fetchOrders = async () => {
    // 添加防御性检查
    if (!courier) {
      console.error('骑手信息未初始化');
      return;
    }

    try {
      setLoading(true);
      const result = await getRecommendedOrders(
        courier.id,
        courier.lat,
        courier.lng,
        sortBy
      );

      if (result.success) {
        setOrders(result.data);
        setError(null);
      } else {
        setError(result.message);
      }
    } catch (err) {
      console.error('获取订单失败:', err);
      setError('Failed to load orders');
    } finally {
      setLoading(false);
    }
  };

  // 初始加载 - 只在 sortBy 或 courier.id 变化时重新获取
  useEffect(() => {
    if (courier?.id) {  // 只依赖 courier.id，而不是整个 courier 对象
      fetchOrders();
    }
  }, [sortBy, courier?.id]);

  // 获取预测性派单通知
  const checkPredictiveNotification = async () => {
    if (!courier?.id || !courier?.lat || !courier?.lng) {
      return;
    }

    try {
      const result = await getPredictiveNotification(courier.id, courier.lat, courier.lng);

      if (result.success && result.data) {
        const notification = result.data;
        // 如果有推荐订单，显示通知
        if (notification.hasRecommendation) {
          Toast.show({
            icon: 'success',
            content: `New orders nearby! ${notification.message || ''}`,
            duration: 3000
          });
          // 刷新订单列表
          fetchOrders();
        }
      }
    } catch (error) {
      console.error('获取预测通知失败:', error);
    }
  };

  // 骑手位置更新时，检查预测性通知（节流：每30秒最多检查一次）
  const lastCheckTime = useRef(0);
  useEffect(() => {
    if (courier?.lat && courier?.lng) {
      const now = Date.now();
      // 节流：30秒内只检查一次
      if (now - lastCheckTime.current > 30000) {
        lastCheckTime.current = now;
        checkPredictiveNotification();
      }
    }
  }, [courier?.lat, courier?.lng]);

  // 切换选择订单
  const toggleOrderSelection = (orderId) => {
    setSelectedOrders((prev) =>
      prev.includes(orderId)
        ? prev.filter((id) => id !== orderId)
        : [...prev, orderId]
    );
  };

  // 接单
  const handleAcceptOrder = async (order) => {
    try {
      // 调用API函数
      const result = await acceptOrderAPI(order.orderId, courier.id);

      if (result.success) {
        acceptOrder(order);  // 更新本地状态
        Toast.show({ icon: 'success', content: 'Order accepted successfully' });
        setOrders((prev) => prev.filter((o) => o.orderId !== order.orderId));
      } else {
        Toast.show({ icon: 'fail', content: result.message || 'Failed to accept order' });
      }
    } catch (error) {
      console.error('接单失败:', error);
      Toast.show({ icon: 'fail', content: 'Failed to accept order' });
    }
  };

  // 批量接单
  const handleAcceptMultiple = async () => {
    if (selectedOrders.length === 0) {
      Toast.show({
        icon: 'fail',
        content: 'Please select at least one order'
      });
      return;
    }

    const ordersToAccept = orders.filter((o) =>
      selectedOrders.includes(o.orderId)
    );

    // 优化路径
    try {
      Toast.show({
        icon: 'loading',
        content: 'Optimizing route...',
        duration: 0
      });

      const routeOrders = ordersToAccept.map((o) => ({
        orderId: o.orderId,
        pickupLat: o.restaurantLat,
        pickupLng: o.restaurantLng,
        dropLat: o.userLat,
        dropLng: o.userLng,
        prepTime: 5
      }));

      const result = await optimizeRoute(routeOrders, courier.lat, courier.lng);

      Toast.clear();

      if (result.success) {
        acceptMultipleOrders(ordersToAccept);
        setOptimizedRoute(result.data);
        setCurrentTarget(result.data.sequence[0]);

        Toast.show({
          icon: 'success',
          content: `Successfully accepted ${ordersToAccept.length} orders`
        });

        // 跳转到导航页
        navigate('/navigation');
      } else {
        Toast.show({
          icon: 'fail',
          content: 'Failed to optimize route'
        });
      }
    } catch (err) {
      Toast.clear();
      console.error('批量接单失败:', err);
      Toast.show({
        icon: 'fail',
        content: 'Failed to accept multiple orders'
      });
    }
  };

  // 下拉刷新
  const handleRefresh = async () => {
    await fetchOrders();
  };

  const renderOrderCard = (order) => {
    const isSelected = selectedOrders.includes(order.orderId);

    return (
      <div
        key={order.orderId}
        className={`order-card-wrapper ${isSelected ? 'selected' : ''}`}
        onClick={() => toggleOrderSelection(order.orderId)}
      >
        <div className="order-card-container">
          {/* 选中指示器 */}
          {isSelected && (
            <div className="selected-indicator">
              <CheckCircleOutline fontSize={20} color="#fff" />
            </div>
          )}

          {/* 订单内容 */}
          <div className="order-card-content">
            <div className="order-title">
              <h3>{order.restaurantName}</h3>
            </div>

            {/* 标签组 */}
            {order.tags && order.tags.length > 0 && (
              <div className="order-tags-group">
                {order.tags.map((tag, index) => {
                  // 标签翻译映射
                  const tagMap = {
                    '顺路': 'On Route',
                    '高收入': 'High Pay',
                    '餐已备好': 'Food Ready',
                    '新订单': 'New Order',
                    '紧急': 'Urgent'
                  };

                  const translatedTag = tagMap[tag] || tag;

                  // 标签样式判断
                  const tagClass =
                    tag.includes('顺路') || translatedTag.includes('Route')
                      ? 'tag-success'
                      : tag.includes('高收入') || translatedTag.includes('High Pay')
                      ? 'tag-warning'
                      : tag.includes('餐已备好') || translatedTag.includes('Ready')
                      ? 'tag-primary'
                      : 'tag-default';

                  return (
                    <span key={index} className={`order-tag ${tagClass}`}>
                      {translatedTag}
                    </span>
                  );
                })}
              </div>
            )}

            {/* 距离和时间信息 */}
            <div className="order-info-row">
              <div className="info-item">
                <EnvironmentOutline className="info-icon" />
                <span>{order.pickupDistance}km · {order.deliveryDistance}km</span>
              </div>
              <div className="info-item">
                <ClockCircleOutline className="info-icon" />
                <span>{order.estimatedTime} min</span>
              </div>
              <div className="info-item income-item">
                <span className="income-value">¥{order.income}</span>
              </div>
            </div>

            {/* 操作按钮 */}
            <div className="order-actions-row">
              {order.isMock ? (
                <Button
                  className="btn-accept btn-demo"
                  disabled
                >
                  Demo Only
                </Button>
              ) : (
                <Button
                  className="btn-accept"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleAcceptOrder(order);
                  }}
                >
                  Accept
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="loading-container">
        <Loading size="large" color="#1677FF" />
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="order-list-page-new">
      {/* 顶部信息栏 */}
      <div className="top-bar">
        <div className="top-bar-content">
          <div className="page-title-section">
            <h1>Available Orders</h1>
            <Badge content={orders.length} className="order-count-badge" />
          </div>
          <div className="courier-info">
            <span className="courier-name">{courier?.name || 'Courier'}</span>
          </div>
        </div>
      </div>

      {/* 筛选标签 */}
      <div className="filter-tabs">
        <Tabs
          activeKey={sortBy}
          onChange={setSortBy}
        >
          <Tabs.Tab title="💡 Smart" key="smart" />
          <Tabs.Tab title="📍 Distance" key="distance" />
          <Tabs.Tab title="💰 Income" key="income" />
        </Tabs>
      </div>

      {/* 订单列表区域 */}
      <div className="orders-area">
        <PullToRefresh onRefresh={handleRefresh}>
          <div className="orders-container">
            {error ? (
              <ErrorBlock status="default" title="Load Failed" description={error} />
            ) : orders.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">📦</div>
                <p className="empty-title">No Orders Available</p>
                <p className="empty-desc">Pull down to refresh</p>
              </div>
            ) : (
              <>
                {/* 统计信息卡片 */}
                <div className="stats-banner">
                  <div className="stat-box">
                    <div className="stat-value">{orders.length}</div>
                    <div className="stat-label">Available</div>
                  </div>
                  <div className="stat-divider"></div>
                  <div className="stat-box">
                    <div className="stat-value selected-color">{selectedOrders.length}</div>
                    <div className="stat-label">Selected</div>
                  </div>
                  <div className="stat-divider"></div>
                  <div className="stat-box">
                    <div className="stat-value">
                      ¥{orders.reduce((sum, o) => sum + o.income, 0).toFixed(0)}
                    </div>
                    <div className="stat-label">Total Income</div>
                  </div>
                </div>

                {/* 订单卡片列表 */}
                <div className="orders-grid">
                  {orders.map((order) => renderOrderCard(order))}
                </div>
              </>
            )}
          </div>
        </PullToRefresh>
      </div>

      {/* 底部批量接单按钮 */}
      {selectedOrders.length > 0 && (
        <div className="bottom-action-bar">
          <div className="action-bar-content">
            <div className="action-info">
              <span className="action-count">Selected: {selectedOrders.length} orders</span>
              <span className="action-income">
                Est. Income: ¥
                {orders
                  .filter((o) => selectedOrders.includes(o.orderId))
                  .reduce((sum, o) => sum + o.income, 0)
                  .toFixed(1)}
              </span>
            </div>
            <Button
              className="batch-accept-btn"
              onClick={handleAcceptMultiple}
            >
              Accept All
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderListPage;
