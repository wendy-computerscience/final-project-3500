import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, Polyline, Popup } from 'react-leaflet';
import {
  NavBar,
  Button,
  Dialog,
  Toast
} from 'antd-mobile';
import {
  EnvironmentOutline,
  ClockCircleOutline,
  CheckCircleOutline
} from 'antd-mobile-icons';
import useCourierStore from '../store/courierStore';
import { updateCourierLocation, confirmPickup, confirmDelivery } from '../api/courier';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './NavigationPage.css';

// 修复 Leaflet 默认图标问题
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png'
});

// 自定义图标
const courierIcon = new L.Icon({
  iconUrl:
    'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
  shadowUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const pickupIcon = new L.Icon({
  iconUrl:
    'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const deliveryIcon = new L.Icon({
  iconUrl:
    'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const NavigationPage = () => {
  const navigate = useNavigate();
  const {
    courier,
    acceptedOrders,
    optimizedRoute,
    currentTarget,
    completeTarget,
    clearOrders
  } = useCourierStore();

  const mapRef = useRef(null);
  const [simulationInterval, setSimulationInterval] = useState(null);
  const [completedPoints, setCompletedPoints] = useState([]);
  // 使用固定的模拟坐标（深圳市中心）
  const [courierLocation, setCourierLocation] = useState({ lat: 22.547, lng: 114.085 });

  // 确保至少有6个点的路线序列
  const getRouteSequence = () => {
    if (!optimizedRoute || !optimizedRoute.sequence) return [];

    const sequence = [...optimizedRoute.sequence];

    // 如果少于6个点，生成模拟数据补充到6个
    while (sequence.length < 6) {
      const lastPoint = sequence[sequence.length - 1] || {
        lat: courierLocation.lat + 0.01,
        lng: courierLocation.lng + 0.01,
        orderId: 9999,
        type: 'DELIVERY'
      };

      sequence.push({
        orderId: 9999 + sequence.length,
        type: sequence.length % 2 === 0 ? 'PICKUP' : 'DELIVERY',
        lat: lastPoint.lat + (Math.random() - 0.5) * 0.02,
        lng: lastPoint.lng + (Math.random() - 0.5) * 0.02,
        restaurantName: `Restaurant ${sequence.length + 1}`,
        address: `Address ${sequence.length + 1}`
      });
    }

    return sequence;
  };

  const routeSequence = getRouteSequence();

  useEffect(() => {
    // 如果没有接单，返回接单页
    if (acceptedOrders.length === 0) {
      navigate('/orders-list', { replace: true });
    }
  }, [acceptedOrders, navigate]);

  useEffect(() => {
    // 自动调整地图视野
    if (mapRef.current && routeSequence.length > 0) {
      const bounds = [
        [courierLocation.lat, courierLocation.lng],
        ...routeSequence.map((s) => [s.lat, s.lng])
      ];
      mapRef.current.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [routeSequence, courierLocation]);

  // 模拟移动到目标点
  const simulateMovement = () => {
    if (!currentTarget) return;

    const targetLat = currentTarget.lat;
    const targetLng = currentTarget.lng;

    // 计算方向
    const deltaLat = targetLat - courierLocation.lat;
    const deltaLng = targetLng - courierLocation.lng;
    const distance = Math.sqrt(deltaLat ** 2 + deltaLng ** 2);

    if (distance < 0.001) {
      // 到达目标点
      handleArrival();
      return;
    }

    // 每次移动一小步（模拟速度 18km/h）
    const step = 0.0005; // 约50米
    const ratio = step / distance;

    const newLat = courierLocation.lat + deltaLat * ratio;
    const newLng = courierLocation.lng + deltaLng * ratio;

    setCourierLocation({ lat: newLat, lng: newLng });

    // 更新服务器位置 - 改进：添加错误处理和重试
    if (acceptedOrders[0]) {
      updateCourierLocation(acceptedOrders[0].orderId, courier.id, newLat, newLng)
        .then((result) => {
          if (!result.success) {
            console.warn('Failed to update courier location:', result.message);
            // 不中断导航流程，只记录警告
          }
        })
        .catch((error) => {
          console.error('Error updating courier location:', error);
          // 网络错误不中断导航，但应该重试
          setTimeout(() => {
            updateCourierLocation(acceptedOrders[0].orderId, courier.id, newLat, newLng)
              .catch(err => console.error('Retry failed:', err));
          }, 5000); // 5秒后重试
        });
    }
  };

  // 到达目标点
  const handleArrival = async () => {
    if (!currentTarget) return;

    const isPickup = currentTarget.type === 'PICKUP';
    const action = isPickup ? 'Pick up food' : 'Deliver order';

    Dialog.confirm({
      content: `Arrived at destination. ${action}?`,
      confirmText: 'Confirm',
      cancelText: 'Cancel',
      onConfirm: async () => {
        try {
          let result;
          // 调用对应的确认接口
          if (isPickup) {
            result = await confirmPickup(currentTarget.orderId, courier.id);
          } else {
            result = await confirmDelivery(currentTarget.orderId, courier.id);
          }

          if (result.success) {
            Toast.show({
              icon: 'success',
              content: `${action} completed!`
            });

            // 记录已完成的点
            setCompletedPoints(prev => [...prev, `${currentTarget.orderId}_${currentTarget.type}`]);

            completeTarget();

            // 如果所有任务完成
            if (
              !routeSequence.some(
                (s, index) =>
                  index >
                  routeSequence.findIndex(
                    (seq) =>
                      seq.orderId === currentTarget.orderId &&
                      seq.type === currentTarget.type
                  )
              )
            ) {
              Dialog.alert({
                content: 'All deliveries completed! Great job!',
                confirmText: 'OK',
                onConfirm: () => {
                  clearOrders();
                  navigate('/delivery', { replace: true });
                }
              });
            }
          } else {
            Toast.show({
              icon: 'fail',
              content: result.message || `${action} failed`
            });
          }
        } catch (error) {
          console.error(`${action} failed:`, error);
          Toast.show({
            icon: 'fail',
            content: `${action} failed`
          });
        }
      }
    });
  };

  // 开始模拟导航
  const startSimulation = () => {
    if (simulationInterval) {
      clearInterval(simulationInterval);
      setSimulationInterval(null);
      Toast.show({ content: 'Simulation paused' });
    } else {
      const interval = setInterval(simulateMovement, 1000); // 每秒移动一次
      setSimulationInterval(interval);
      Toast.show({ content: 'Simulation started' });
    }
  };

  useEffect(() => {
    return () => {
      if (simulationInterval) {
        clearInterval(simulationInterval);
      }
    };
  }, [simulationInterval]);

  if (!optimizedRoute || acceptedOrders.length === 0) {
    return (
      <div className="navigation-page">
        <NavBar onBack={() => navigate('/delivery')}>Navigation</NavBar>
        <div className="empty-container">
          <div className="empty-icon">🗺️</div>
          <div className="empty-title">No Active Deliveries</div>
          <div className="empty-desc">Please accept orders first to start navigation</div>
        </div>
      </div>
    );
  }

  // 构建路径（包含所有6个点）
  const pathPoints = [
    [courierLocation.lat, courierLocation.lng],
    ...routeSequence.map((s) => [s.lat, s.lng])
  ];

  // 计算进度
  const currentIndex = currentTarget
    ? routeSequence.findIndex(
        (s) =>
          s.orderId === currentTarget.orderId && s.type === currentTarget.type
      )
    : 0;
  const progress = ((currentIndex + 1) / routeSequence.length) * 100;

  return (
    <div className="navigation-page">
      <NavBar onBack={() => navigate('/delivery')}>Delivery Navigation</NavBar>

      {/* 地图区域 */}
      <div className="map-container">
        <MapContainer
          ref={mapRef}
          center={[courierLocation.lat, courierLocation.lng]}
          zoom={14}
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {/* 优化路径 - 蓝色线 */}
          <Polyline
            positions={pathPoints}
            color="#1677ff"
            weight={5}
            opacity={0.8}
            dashArray="10, 5"
          />

          {/* 骑手位置 */}
          <Marker position={[courierLocation.lat, courierLocation.lng]} icon={courierIcon}>
            <Popup>📍 My Location</Popup>
          </Marker>

          {/* 所有目标点（6个点） */}
          {routeSequence.map((point, index) => (
            <Marker
              key={`${point.orderId}_${point.type}`}
              position={[point.lat, point.lng]}
              icon={point.type === 'PICKUP' ? pickupIcon : deliveryIcon}
            >
              <Popup>
                <strong>Stop {index + 1}</strong><br />
                {point.type === 'PICKUP' ? '🍴 Pickup' : '📦 Delivery'}<br />
                Order #{point.orderId}
              </Popup>
            </Marker>
          ))}
        </MapContainer>

        {/* 顶部信息卡片 */}
        {currentTarget && (
          <div className="top-info-card">
            <div className="top-info-header">
              <div className="target-title">
                <span className="target-icon">
                  {currentTarget.type === 'PICKUP' ? '🍴' : '📦'}
                </span>
                {currentTarget.type === 'PICKUP' ? 'Going to Restaurant' : 'Delivering to Customer'}
              </div>
              <div className="station-tag">
                Stop {currentIndex + 1}/{routeSequence.length}
              </div>
            </div>

            <div className="order-id">Order #{currentTarget.orderId}</div>

            <div className="distance-time-row">
              <div className="distance-time-item">
                <EnvironmentOutline />
                <span>{(Math.random() * 2 + 0.5).toFixed(1)} km</span>
              </div>
              <div className="distance-time-item">
                <ClockCircleOutline />
                <span>{Math.floor(Math.random() * 10 + 5)} min</span>
              </div>
            </div>

            <div className="progress-bar-container">
              <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
            </div>
            <div className="progress-text">{Math.round(progress)}% Complete</div>
          </div>
        )}
      </div>

      {/* 底部信息面板 */}
      <div className="bottom-panel">
        {/* 路线序列卡片 */}
        <div className="route-sequence">
          {routeSequence.map((point, index) => {
            const isCompleted = completedPoints.includes(`${point.orderId}_${point.type}`);
            const isActive = currentTarget &&
              currentTarget.orderId === point.orderId &&
              currentTarget.type === point.type;

            return (
              <div
                key={`${point.orderId}_${point.type}`}
                className={`route-point ${point.type.toLowerCase()} ${
                  isCompleted ? 'completed' : ''
                } ${isActive ? 'active' : ''}`}
              >
                <div className="route-point-number">{index + 1}</div>
                <div className="route-point-label">
                  {point.type === 'PICKUP' ? 'Pickup' : 'Drop'}
                </div>
              </div>
            );
          })}
        </div>

        {/* 路径统计 */}
        <div className="stats-card">
          <div className="stats-row">
            <div className="stat-item">
              <span className="stat-label">Total:</span>
              <span className="stat-value">
                {optimizedRoute.totalDistance ? `${optimizedRoute.totalDistance.toFixed(1)} km` : 'Calculating...'}
              </span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Est. Time:</span>
              <span className="stat-value">
                {optimizedRoute.estimatedTime ? `${optimizedRoute.estimatedTime.toFixed(1)} min` : 'Calculating...'}
              </span>
            </div>
            {optimizedRoute.savings && (
              <div className="stat-item">
                <span className="stat-label">Saved:</span>
                <span className="stat-value savings">
                  {optimizedRoute.savings.savedPercentage}%
                </span>
              </div>
            )}
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="action-buttons">
          <button
            className={`btn-simulate ${simulationInterval ? 'paused' : ''}`}
            onClick={startSimulation}
          >
            {simulationInterval ? '⏸ Pause Simulation' : '▶️ Start Simulation'}
          </button>
          {currentTarget && (
            <button className="btn-arrive" onClick={handleArrival}>
              ✓ Arrived
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default NavigationPage;
