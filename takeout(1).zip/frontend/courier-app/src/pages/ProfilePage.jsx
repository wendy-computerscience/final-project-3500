import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import {
  Card,
  List,
  Dialog,
  Toast
} from 'antd-mobile';
import {
  UnorderedListOutline,
  StarFill,
  GiftOutline,
  MessageOutline,
  SetOutline,
  RightOutline,
  StarOutline,
  FileOutline
} from 'antd-mobile-icons';
import useCourierStore from '../store/courierStore';
import { riderLogout, getRiderIncome } from '../api/courier';
import LanguageSwitcher from '../components/LanguageSwitcher';
import { useTranslation } from 'react-i18next';
import './ProfilePage.css';

const ProfilePage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { courier } = useCourierStore();
  const [stats, setStats] = useState({
    todayOrders: 0,
    todayIncome: 0,
    onlineHours: 0
  });

  // 加载今日统计数据
  useEffect(() => {
    const loadStats = async () => {
      if (!courier?.id) return;

      try {
        const result = await getRiderIncome(courier.id, 'today');
        if (result.success && result.data) {
          setStats({
            todayOrders: result.data.totalOrders || 0,
            todayIncome: result.data.totalIncome || 0,
            onlineHours: result.data.onlineHours || 0
          });
        }
      } catch (error) {
        console.error('加载统计数据失败:', error);
      }
    };

    loadStats();
  }, [courier?.id]);

  // 处理菜单点击
  const handleMenuClick = (key) => {
    switch (key) {
      case 'tasks':
        navigate('/tasks');
        break;
      case 'ranking':
        navigate('/ranking');
        break;
      case 'orders':
        navigate('/orders');
        break;
      case 'income':
        navigate('/income');
        break;
      case 'auth':
        navigate('/auth');
        break;
      case 'service':
        navigate('/customer-service');
        break;
      case 'settings':
        navigate('/settings');
        break;
      default:
        break;
    }
  };

  // 退出登录
  const handleLogout = () => {
    Dialog.confirm({
      content: t('profile.confirmLogout'),
      onConfirm: async () => {
        try {
          // 调用退出登录接口
          const result = await riderLogout(courier.id);

          if (result.success) {
            console.log('退出登录成功');
            // 清除登录信息
            localStorage.removeItem('riderId');
            localStorage.removeItem('riderToken');
            // 显示成功提示
            Toast.show({
              icon: 'success',
              content: t('profile.logoutSuccess') || '已退出登录',
              duration: 1500
            });
            // 延迟跳转
            setTimeout(() => {
              navigate('/login');
            }, 1500);
          } else {
            // 改进：显示失败信息
            Toast.show({
              icon: 'fail',
              content: result.message || t('profile.logoutFailed') || '退出登录失败',
              duration: 2000
            });
          }
        } catch (error) {
          // 改进：显示异常信息
          console.error('退出登录失败:', error);
          Toast.show({
            icon: 'fail',
            content: t('common.networkError') || '退出登录失败',
            duration: 2000
          });
        }
      }
    });
  };

  return (
    <div className="courier-profile-page">
      {/* 骑手信息卡片 */}
      <Card className="courier-card">
        <div className="courier-info">
          {/* 头像 */}
          <div className="courier-avatar">
            <div className="avatar-placeholder">
              {courier.name.charAt(0)}
            </div>
          </div>

          {/* 骑手名和评分 */}
          <div className="courier-details">
            <div className="courier-name">{courier.name}</div>
            <div className="courier-rating">
              <StarOutline fontSize={12} color="#FFB800" />
              <span>{t('profile.rating')} 4.9</span>
              <span className="level-badge">{t('profile.rating')}</span>
            </div>
          </div>

          {/* 设置按钮 */}
          <div
            className="settings-icon"
            onClick={() => handleMenuClick('settings')}
          >
            <SetOutline fontSize={20} />
          </div>
        </div>

        {/* 今日数据 */}
        <div className="courier-stats">
          <div className="stat-item" onClick={() => handleMenuClick('orders')}>
            <div className="stat-value">{stats.todayOrders}</div>
            <div className="stat-label">{t('profile.todayOrders')}</div>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item" onClick={() => handleMenuClick('income')}>
            <div className="stat-value">¥{stats.todayIncome.toFixed(2)}</div>
            <div className="stat-label">{t('profile.todayIncome')}</div>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <div className="stat-value">{stats.onlineHours.toFixed(1)}h</div>
            <div className="stat-label">{t('delivery.currentTask')}</div>
          </div>
        </div>
      </Card>

      {/* 任务和排行 */}
      <Card className="feature-cards">
        <div className="feature-row">
          <div className="feature-item" onClick={() => handleMenuClick('tasks')}>
            <div className="feature-icon" style={{ background: 'linear-gradient(135deg, #FF6B00 0%, #FF8C00 100%)' }}>
              <GiftOutline fontSize={24} color="white" />
            </div>
            <div className="feature-text">
              <div className="feature-title">{t('profile.myTasks')}</div>
              <div className="feature-desc">3{t('tasks.inProgress')}</div>
            </div>
            <RightOutline fontSize={14} color="#999" />
          </div>

          <div className="feature-item" onClick={() => handleMenuClick('ranking')}>
            <div className="feature-icon" style={{ background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)' }}>
              <StarFill fontSize={24} color="white" />
            </div>
            <div className="feature-text">
              <div className="feature-title">{t('profile.ranking')}</div>
              <div className="feature-desc">{t('orders.today')}8{t('ranking.orders')}</div>
            </div>
            <RightOutline fontSize={14} color="#999" />
          </div>
        </div>
      </Card>

      {/* 功能菜单 */}
      <Card className="menu-card">
        <List>
          <List.Item
            prefix={<FileOutline fontSize={20} />}
            onClick={() => handleMenuClick('auth')}
            arrow
          >
            {t('profile.auth') || '实名认证'}
          </List.Item>
          <List.Item
            prefix={<UnorderedListOutline fontSize={20} />}
            onClick={() => handleMenuClick('orders')}
            arrow
          >
            {t('nav.myOrders')}
          </List.Item>
          <List.Item
            prefix={<MessageOutline fontSize={20} />}
            onClick={() => handleMenuClick('service')}
            arrow
          >
            {t('profile.customerService')}
          </List.Item>
          <List.Item
            prefix={<SetOutline fontSize={20} />}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
              <span>{t('settings.title')}</span>
              <LanguageSwitcher />
            </div>
          </List.Item>
          <List.Item
            prefix={<SetOutline fontSize={20} />}
            onClick={() => handleMenuClick('settings')}
            arrow
          >
            {t('profile.settings')}
          </List.Item>
        </List>
      </Card>

      {/* 退出登录按钮 */}
      <div className="logout-section">
        <div className="logout-button" onClick={handleLogout}>
          {t('profile.logout')}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
