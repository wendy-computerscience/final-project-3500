import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useCourierStore = create(
  persist(
    (set) => ({
      // 登录状态
      isLoggedIn: false,
      token: null,

      // 骑手信息（开发环境提供默认测试骑手）
      courier: process.env.NODE_ENV === 'development'
        ? {
            id: 1,
            name: '测试骑手',
            phone: '13800138001',
            vehicle: 'electric_bike'
          }
        : null,

      // Accepted orders
      acceptedOrders: [],

      // Optimized route plan
      optimizedRoute: null,

      // Current navigation target
      currentTarget: null,

      // 登录
      login: (courierData) =>
        set({
          isLoggedIn: true,
          token: courierData.token,
          courier: {
            id: courierData.id,
            name: courierData.name,
            phone: courierData.phone,
            vehicle: courierData.vehicle || 'electric_bike'
          }
        }),

      // 退出登录
      logout: () =>
        set({
          isLoggedIn: false,
          token: null,
          courier: null,
          acceptedOrders: [],
          optimizedRoute: null,
          currentTarget: null
        }),

      // Set / clear rider info (兼容旧代码)
      setCourier: (courier) =>
        set({
          courier,
          isLoggedIn: !!courier
        }),

      clearCourier: () =>
        set({
          isLoggedIn: false,
          token: null,
          courier: null,
          acceptedOrders: [],
          optimizedRoute: null,
          currentTarget: null
        }),

      // Accept a single order
      acceptOrder: (order) =>
        set((state) => ({
          acceptedOrders: [...state.acceptedOrders, order]
        })),

      // Accept multiple orders
      acceptMultipleOrders: (orders) =>
        set((state) => ({
          acceptedOrders: [...state.acceptedOrders, ...orders]
        })),

      // Set accepted orders (replace all)
      setAcceptedOrders: (orders) =>
        set({ acceptedOrders: orders }),

      // Set optimized route
      setOptimizedRoute: (route) =>
        set({ optimizedRoute: route }),

      // Set current navigation target
      setCurrentTarget: (target) =>
        set({ currentTarget: target }),

      // Mark current target as completed and move to next one
      completeTarget: () =>
        set((state) => {
          if (!state.optimizedRoute || !state.optimizedRoute.sequence) {
            return state;
          }

          const currentIndex = state.optimizedRoute.sequence.findIndex(
            (s) =>
              s.orderId === state.currentTarget?.orderId &&
              s.type === state.currentTarget?.type
          );

          if (currentIndex === -1) {
            return state;
          }

          const nextTarget =
            currentIndex < state.optimizedRoute.sequence.length - 1
              ? state.optimizedRoute.sequence[currentIndex + 1]
              : null;

          return {
            currentTarget: nextTarget
          };
        }),

      // Clear accepted orders and route
      clearOrders: () =>
        set({
          acceptedOrders: [],
          optimizedRoute: null,
          currentTarget: null
        })
    }),
    {
      name: 'courier-storage', // localStorage key
    }
  )
);

export default useCourierStore;
