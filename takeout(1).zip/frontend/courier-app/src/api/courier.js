import client from './client';

/**
 * 骑手登录（账号密码登录）
 * @param {string} username - 账号
 * @param {string} password - 密码
 */
export const riderLogin = async (username, password) => {
  try {
    const response = await client.post('/riders/login', { username, password });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('登录失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '登录失败'
    };
  }
};

/**
 * 骑手退出登录
 * @param {string} riderId - 骑手ID
 */
export const riderLogout = async (riderId) => {
  try {
    const response = await client.post('/riders/logout', { riderId });
    return { success: true, message: response.data.message };
  } catch (error) {
    console.error('退出登录失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '退出失败'
    };
  }
};

/**
 * 接单
 * @param {string} orderId - 订单ID
 * @param {string} riderId - 骑手ID
 */
export const acceptOrder = async (orderId, riderId) => {
  try {
    const response = await client.post(`/riders/orders/${orderId}/accept`, { riderId });
    return { success: true, message: response.data.message };
  } catch (error) {
    console.error('接单失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '接单失败'
    };
  }
};

/**
 * 确认取餐
 * @param {string} orderId - 订单ID
 * @param {string} riderId - 骑手ID
 */
export const confirmPickup = async (orderId, riderId) => {
  try {
    const response = await client.put(`/riders/orders/${orderId}/pickup`, { riderId });
    return { success: true, message: response.data.message };
  } catch (error) {
    console.error('确认取餐失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '取餐失败'
    };
  }
};

/**
 * 确认送达
 * @param {string} orderId - 订单ID
 * @param {string} riderId - 骑手ID
 */
export const confirmDelivery = async (orderId, riderId) => {
  try {
    const response = await client.put(`/riders/orders/${orderId}/deliver`, { riderId });
    return { success: true, message: response.data.message };
  } catch (error) {
    console.error('确认送达失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '送达失败'
    };
  }
};

/**
 * 获取骑手推荐订单列表
 * @param {string} courierId - 骑手ID
 * @param {number} lat - 骑手纬度
 * @param {number} lng - 骑手经度
 * @param {string} sortBy - 排序方式 (distance/income/smart)
 */
export const getRecommendedOrders = async (courierId, lat, lng, sortBy = 'smart') => {
  const response = await client.get('/dispatch/recommended-orders', {
    params: { courierId, lat, lng, sortBy }
  });
  return response.data;
};

/**
 * 获取预测性派单通知
 * @param {string} courierId - 骑手ID
 * @param {number} lat - 骑手纬度
 * @param {number} lng - 骑手经度
 */
export const getPredictiveNotification = async (courierId, lat, lng) => {
  try {
    const response = await client.get('/dispatch/predictive-notification', {
      params: { courierId, lat, lng }
    });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('获取预测通知失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '获取通知失败'
    };
  }
};

/**
 * 优化多订单配送路径
 * @param {array} orders - 订单列表
 * @param {number} courierLat - 骑手纬度
 * @param {number} courierLng - 骑手经度
 */
export const optimizeRoute = async (orders, courierLat, courierLng) => {
  const response = await client.post('/route/optimize', {
    orders,
    courierLat,
    courierLng
  });
  return response.data;
};

/**
 * 获取路径可视化数据
 * @param {object} optimizedRoute - 优化后的路径
 * @param {number} courierLat - 骑手纬度
 * @param {number} courierLng - 骑手经度
 */
export const getRouteVisualization = async (optimizedRoute, courierLat, courierLng) => {
  const response = await client.post('/route/visualization', {
    optimizedRoute,
    courierLat,
    courierLng
  });
  return response.data;
};

/**
 * 更新骑手位置
 * @param {string} orderId - 订单ID
 * @param {string} courierId - 骑手ID
 * @param {number} lat - 纬度
 * @param {number} lng - 经度
 */
export const updateCourierLocation = async (orderId, courierId, lat, lng) => {
  const response = await client.post(`/track/${orderId}`, {
    courierId,
    lat,
    lng
  });
  return response.data;
};

/**
 * 获取骑手收入统计
 * @param {string} riderId - 骑手ID
 * @param {string} period - 时间周期 (today/week/month)
 */
export const getRiderIncome = async (riderId, period = 'today') => {
  try {
    const response = await client.get('/riders/income', {
      params: { riderId, period }
    });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('获取收入统计失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '获取收入统计失败'
    };
  }
};

/**
 * 获取骑手任务列表
 * @param {string} riderId - 骑手ID
 * @param {string} taskType - 任务类型 (daily/weekly/all)
 */
export const getRiderTasks = async (riderId, taskType = 'daily') => {
  try {
    const response = await client.get('/riders/tasks', {
      params: { riderId }
    });

    // 过滤任务类型
    const allTasks = response.data.data || [];
    const filteredTasks = taskType === 'all'
      ? allTasks
      : allTasks.filter(task => task.taskType === taskType);

    return { success: true, data: filteredTasks };
  } catch (error) {
    console.error('获取任务列表失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '获取任务失败'
    };
  }
};

/**
 * 领取任务奖励
 * @param {string} riderId - 骑手ID
 * @param {string} taskId - 任务ID
 */
export const claimTaskReward = async (riderId, taskId) => {
  try {
    const response = await client.post(`/riders/tasks/${taskId}/claim`, {
      riderId
    });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('领取任务奖励失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '领取失败'
    };
  }
};

/**
 * 获取骑手排行榜
 * @param {string} period - 时间周期 (today/week/month)
 * @param {string} type - 排行类型 (orders/income/rating)
 * @param {string} riderId - 当前骑手ID (可选)
 */
export const getRiderRanking = async (period = 'today', type = 'orders', riderId = null) => {
  try {
    const response = await client.get('/riders/ranking', {
      params: { period, type, riderId }
    });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('获取排行榜失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '获取排行榜失败'
    };
  }
};

/**
 * 获取骑手订单列表
 * @param {string} riderId - 骑手ID
 * @param {string} status - 订单状态 (可选)
 * @param {number} page - 页码
 * @param {number} pageSize - 每页数量
 */
export const getRiderOrders = async (riderId, status = null, page = 1, pageSize = 10) => {
  try {
    const params = { riderId, page, pageSize };
    if (status) {
      params.status = status;
    }

    const response = await client.get('/riders/orders', { params });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('获取订单列表失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '获取订单失败'
    };
  }
};

/**
 * 获取订单详情
 * @param {string} orderId - 订单ID
 * @param {string} riderId - 骑手ID
 */
export const getOrderDetail = async (orderId, riderId) => {
  try {
    const response = await client.get(`/riders/orders/${orderId}`, {
      params: { riderId }
    });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('获取订单详情失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '获取详情失败'
    };
  }
};

/**
 * 创建提现申请
 * @param {string} riderId - 骑手ID
 * @param {number} amount - 提现金额
 * @param {object} bankInfo - 银行信息 {bankAccount, bankName, realName}
 */
export const createWithdrawal = async (riderId, amount, bankInfo) => {
  try {
    const response = await client.post('/riders/withdraw', {
      riderId,
      amount,
      ...bankInfo
    });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('提现申请失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '提现失败'
    };
  }
};

/**
 * 查询提现记录
 * @param {string} riderId - 骑手ID
 * @param {number} page - 页码
 * @param {number} pageSize - 每页数量
 */
export const getWithdrawalRecords = async (riderId, page = 1, pageSize = 20) => {
  try {
    const response = await client.get('/riders/withdraw/records', {
      params: { riderId, page, pageSize }
    });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('查询提现记录失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '查询失败'
    };
  }
};

/**
 * 提交骑手认证信息
 * @param {object} authData - 认证数据 { riderId, realName, idCard, healthCert, vehicleInfo }
 */
export const submitRiderAuth = async (authData) => {
  try {
    const response = await client.post('/riders/auth', authData);
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('提交骑手认证失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '提交认证失败'
    };
  }
};

/**
 * 获取骑手认证状态
 * @param {string} riderId - 骑手ID
 */
export const getRiderAuthStatus = async (riderId) => {
  try {
    const response = await client.get('/riders/auth/status', {
      params: { riderId }
    });
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('获取认证状态失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '获取认证状态失败'
    };
  }
};

/**
 * 骑手注册
 * @param {object} registerData - 注册信息 {phone, password, realName, vehicleType}
 */
export const registerRider = async (registerData) => {
  try {
    const response = await client.post('/riders/register', registerData);
    return { success: true, data: response.data.data };
  } catch (error) {
    console.error('骑手注册失败:', error);
    return {
      success: false,
      message: error.response?.data?.message || '注册失败'
    };
  }
};
