import { Toast } from 'antd-mobile';

export const ERROR_TYPES = {
  NETWORK_ERROR: 'network_error',
  VALIDATION_ERROR: 'validation_error',
  AUTH_ERROR: 'auth_error',
  SERVER_ERROR: 'server_error',
  UNKNOWN_ERROR: 'unknown_error'
};

export const ERROR_MESSAGES = {
  [ERROR_TYPES.NETWORK_ERROR]: '网络连接失败，请检查网络',
  [ERROR_TYPES.VALIDATION_ERROR]: '输入信息不正确，请检查后重试',
  [ERROR_TYPES.AUTH_ERROR]: '您的登录已过期，请重新登录',
  [ERROR_TYPES.SERVER_ERROR]: '服务器出错，请稍后重试',
  [ERROR_TYPES.UNKNOWN_ERROR]: '发生未知错误，请联系客服'
};

/**
 * 分类错误类型
 * @param {Error} error - 错误对象
 * @param {Object} response - API响应对象
 * @returns {string} 错误类型
 */
export const classifyError = (error, response) => {
  // 网络错误
  if (!error.response || error.code === 'ECONNABORTED') {
    return ERROR_TYPES.NETWORK_ERROR;
  }

  // 验证错误 (4xx，除401)
  if (response?.status >= 400 && response?.status < 500 && response?.status !== 401) {
    return ERROR_TYPES.VALIDATION_ERROR;
  }

  // 认证错误
  if (response?.status === 401) {
    return ERROR_TYPES.AUTH_ERROR;
  }

  // 服务器错误 (5xx)
  if (response?.status >= 500) {
    return ERROR_TYPES.SERVER_ERROR;
  }

  return ERROR_TYPES.UNKNOWN_ERROR;
};

/**
 * 显示错误提示
 * @param {Error} error - 错误对象或响应对象
 * @param {Object} options - 显示选项
 */
export const showErrorMessage = (error, options = {}) => {
  const {
    customMessage = null,
    type = 'fail',
    duration = 2000,
    fallback = '操作失败'
  } = options;

  // 优先使用自定义消息
  if (customMessage) {
    Toast.show({
      icon: type,
      content: customMessage,
      duration
    });
    return;
  }

  // 其次使用API返回的错误信息
  const apiMessage = error?.response?.data?.message ||
                     error?.data?.message ||
                     error?.message;
  if (apiMessage) {
    Toast.show({
      icon: type,
      content: apiMessage,
      duration
    });
    return;
  }

  // 最后使用通用错误信息
  Toast.show({
    icon: type,
    content: fallback,
    duration
  });
};

/**
 * 是否应该重试
 * @param {Error} error - 错误对象
 * @param {number} retryCount - 已重试次数
 * @returns {boolean}
 */
export const shouldRetry = (error, retryCount = 0) => {
  if (retryCount >= 3) return false; // 最多重试3次

  const errorType = classifyError(error, error.response);
  // 网络错误和服务器错误可以重试
  return [ERROR_TYPES.NETWORK_ERROR, ERROR_TYPES.SERVER_ERROR].includes(errorType);
};
