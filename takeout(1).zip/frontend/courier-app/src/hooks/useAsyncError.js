import { useCallback } from 'react';
import { Toast, Dialog } from 'antd-mobile';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { classifyError, ERROR_TYPES, showErrorMessage, shouldRetry } from '../utils/errorHandler';

/**
 * 统一的异步操作错误处理Hook
 * @param {Function} asyncFn - 异步函数
 * @param {Object} options - 选项
 */
export const useAsyncWithError = (asyncFn, options = {}) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const {
    onSuccess = null,
    onError = null,
    showLoadingToast = false,
    loadingMessage = null,
    successMessage = null,
    retryable = false,
    retryText = t('common.retry')
  } = options;

  const execute = useCallback(
    async (...args) => {
      let retryCount = 0;
      const maxRetries = retryable ? 3 : 0;

      const executeOnce = async () => {
        try {
          if (showLoadingToast && loadingMessage) {
            Toast.show({
              icon: 'loading',
              content: loadingMessage,
              duration: 0
            });
          }

          const result = await asyncFn(...args);

          if (showLoadingToast) {
            Toast.clear();
          }

          if (result.success) {
            if (successMessage) {
              Toast.show({
                icon: 'success',
                content: successMessage,
                duration: 2000
              });
            }
            if (onSuccess) {
              onSuccess(result);
            }
            return result;
          } else {
            // API返回失败
            showErrorMessage(
              { response: { data: result } },
              {
                customMessage: result.message,
                fallback: t('common.operationFailed') || '操作失败'
              }
            );
            if (onError) {
              onError(result);
            }
            throw new Error(result.message);
          }
        } catch (error) {
          if (showLoadingToast) {
            Toast.clear();
          }

          const errorType = classifyError(error, error.response);

          // 处理认证错误
          if (errorType === ERROR_TYPES.AUTH_ERROR) {
            Dialog.alert({
              title: t('common.loginExpired') || '登录已过期',
              content: t('common.loginExpiredDesc') || '您的登录已过期，请重新登录',
              confirmText: t('common.reLogin') || '重新登录',
              onConfirm: () => {
                navigate('/login');
              }
            });
            return;
          }

          // 判断是否应该重试
          if (retryable && retryCount < maxRetries && shouldRetry(error, retryCount)) {
            retryCount++;
            Toast.show({
              icon: 'loading',
              content: `${t('common.retrying') || '正在重试'} (${retryCount}/${maxRetries})`,
              duration: 1000
            });
            // 延迟后重试
            await new Promise(resolve => setTimeout(resolve, 1000));
            return executeOnce();
          }

          // 显示错误信息
          showErrorMessage(error, {
            fallback: t('common.operationFailed') || '操作失败'
          });

          if (onError) {
            onError(error);
          }

          throw error;
        }
      };

      return executeOnce();
    },
    [asyncFn, onSuccess, onError, showLoadingToast, loadingMessage, successMessage, retryable, t, navigate]
  );

  return { execute };
};
