import { useCallback, useEffect, useState } from 'react';
import { Dialog, Toast } from 'antd-mobile';
import { useTranslation } from 'react-i18next';

/**
 * GPS权限管理Hook
 * 处理GPS权限的申请、检查和恢复
 */
export const useGPSPermission = () => {
  const { t } = useTranslation();
  const [permissionStatus, setPermissionStatus] = useState('unknown'); // unknown | granted | denied

  // 检查权限状态
  const checkPermission = useCallback(async () => {
    // 检查Permissions API支持
    if (!navigator.permissions) {
      console.warn('Permissions API not supported');
      return null;
    }

    try {
      // 尝试查询地理位置权限
      const result = await navigator.permissions.query({ name: 'geolocation' });
      setPermissionStatus(result.state);
      return result.state;
    } catch (error) {
      console.error('Failed to query geolocation permission:', error);
      return null;
    }
  }, []);

  // 请求权限
  const requestPermission = useCallback(async () => {
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setPermissionStatus('granted');
          resolve('granted');
        },
        (error) => {
          if (error.code === error.PERMISSION_DENIED) {
            setPermissionStatus('denied');
            resolve('denied');
          } else {
            resolve('unknown');
          }
        }
      );
    });
  }, []);

  // 处理权限拒绝
  const handlePermissionDenied = useCallback(async () => {
    Dialog.alert({
      title: t('gps.permissionDenied') || '需要位置权限',
      content: t('gps.permissionDeniedDesc') || '骑手应用需要获取您的位置信息才能正常工作，请在设置中允许位置访问。',
      confirmText: t('gps.understand') || '我知道了',
      onConfirm: () => {
        Toast.show({
          content: t('gps.permissionManualGuide') || '请打开手机设置 > 应用权限 > 位置，允许本应用访问位置',
          duration: 5000
        });
      }
    });
  }, [t]);

  // 初始化：检查权限状态
  useEffect(() => {
    checkPermission();
  }, [checkPermission]);

  return {
    permissionStatus,
    checkPermission,
    requestPermission,
    handlePermissionDenied
  };
};
