import { useEffect } from 'react';
import { Dialog, Toast } from 'antd-mobile';
import useCourierStore from '../store/courierStore';
import { useTranslation } from 'react-i18next';

/**
 * GPS状态监控组件
 * 监听GPS错误并提供用户友好的提示和恢复选项
 */
const GPSStatusMonitor = () => {
  const { t } = useTranslation();
  const {
    gpsError,
    gpsStatus,
    clearGPSError,
    startGPSTracking,
    courier,
    isLoggedIn
  } = useCourierStore();

  useEffect(() => {
    if (!gpsError) return;

    // 权限被拒绝
    if (gpsError.type === 'permission') {
      Dialog.alert({
        title: t('gps.permissionDenied') || '需要位置权限',
        content: gpsError.message,
        confirmText: t('gps.openSettings') || '去设置',
        onConfirm: () => {
          Toast.show({
            content: t('gps.manualPermissionGuide') || '请打开手机设置 > 应用权限 > 位置，允许本应用访问位置',
            duration: 5000
          });
        }
      });
    }
    // 临时错误，提供重试选项
    else if (gpsError.type === 'temporary') {
      Dialog.confirm({
        title: t('gps.error') || '定位错误',
        content: gpsError.message,
        confirmText: t('common.retry') || '重试',
        cancelText: t('common.cancel') || '取消',
        onConfirm: () => {
          if (courier && isLoggedIn) {
            clearGPSError();
            startGPSTracking();
            Toast.show({
              content: t('gps.retrying') || '正在重新定位...',
              icon: 'loading'
            });
          }
        }
      });
    }
    // 致命错误
    else if (gpsError.type === 'fatal') {
      Dialog.alert({
        title: t('gps.notSupported') || '不支持定位',
        content: gpsError.message,
        confirmText: t('common.confirm') || '确定'
      });
    }
  }, [gpsError, t, clearGPSError, startGPSTracking, courier, isLoggedIn]);

  // 此组件只负责显示错误提示，不返回任何UI
  return null;
};

export default GPSStatusMonitor;
