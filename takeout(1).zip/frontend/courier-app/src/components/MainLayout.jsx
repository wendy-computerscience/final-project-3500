import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { TabBar } from 'antd-mobile';
import {
  UnorderedListOutline,
  TruckOutline,
  FileOutline,
  PayCircleOutline,
  UserOutline
} from 'antd-mobile-icons';
import './MainLayout.css';

const MainLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // TabBar配置
  const tabs = [
    {
      key: '/orders-list',
      title: '接单',
      icon: <UnorderedListOutline />
    },
    {
      key: '/delivery',
      title: '配送',
      icon: <TruckOutline />
    },
    {
      key: '/orders',
      title: '订单',
      icon: <FileOutline />
    },
    {
      key: '/income',
      title: '收入',
      icon: <PayCircleOutline />
    },
    {
      key: '/profile',
      title: '我的',
      icon: <UserOutline />
    }
  ];

  // 获取当前激活的Tab
  const getActiveKey = () => {
    const path = location.pathname;
    // 如果路径匹配某个tab，返回对应key
    const activeTab = tabs.find(tab => path.startsWith(tab.key));
    return activeTab ? activeTab.key : '/orders-list';
  };

  // 切换Tab
  const handleTabChange = (key) => {
    navigate(key);
  };

  return (
    <div className="main-layout">
      {/* 页面内容区域 */}
      <div className="main-content">
        <Outlet />
      </div>

      {/* 底部TabBar */}
      <div className="main-tabbar">
        <TabBar activeKey={getActiveKey()} onChange={handleTabChange}>
          {tabs.map(item => (
            <TabBar.Item key={item.key} icon={item.icon} title={item.title} />
          ))}
        </TabBar>
      </div>
    </div>
  );
};

export default MainLayout;
