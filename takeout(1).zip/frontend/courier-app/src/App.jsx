import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';
import useCourierStore from './store/courierStore';
import MainLayout from './components/MainLayout';
import OrderListPage from './pages/OrderListPage';
import DeliveryPage from './pages/DeliveryPage';
import NavigationPage from './pages/NavigationPage';
import OrdersPage from './pages/OrdersPage';
import IncomePage from './pages/IncomePage';
import ProfilePage from './pages/ProfilePage';
import TasksPage from './pages/TasksPage';
import RankingPage from './pages/RankingPage';
import RiderLoginPage from './pages/RiderLoginPage';
import RiderRegisterPage from './pages/RiderRegisterPage';
import RiderAuthPage from './pages/RiderAuthPage';
import RiderSettingsPage from './pages/RiderSettingsPage';
import RiderCustomerServicePage from './pages/RiderCustomerServicePage';
import AuditStatusPage from './pages/AuditStatusPage';
import OrderDetailPage from './pages/OrderDetailPage';
import WithdrawalRecordsPage from './pages/WithdrawalRecordsPage';
import './index.css';

function App() {
  const { courier } = useCourierStore();

  // 恢复登录状态
  useEffect(() => {
    // persist 中间件会自动从 localStorage 恢复状态
    // 这里可以添加额外的初始化逻辑

    // 如果 localStorage 有 riderId 但 store 中没有，尝试恢复
    const storedRiderId = localStorage.getItem('riderId');
    const storedToken = localStorage.getItem('riderToken');

    if (storedRiderId && storedToken && !courier) {
      // 可以调用 API 获取完整骑手信息
      console.log('检测到登录凭证，骑手信息将通过 persist 恢复');
    }
  }, [courier]);

  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          {/* 带TabBar的主页面 */}
          <Route path="/" element={<MainLayout />}>
            <Route index element={<Navigate to="/orders-list" replace />} />
            <Route path="orders-list" element={<OrderListPage />} />
            <Route path="delivery" element={<DeliveryPage />} />
            <Route path="orders" element={<OrdersPage />} />
            <Route path="income" element={<IncomePage />} />
            <Route path="profile" element={<ProfilePage />} />
          </Route>
          {/* 独立的导航页面(不在TabBar中) */}
          <Route path="/navigation" element={<NavigationPage />} />
          {/* 订单详情页 */}
          <Route path="/order/:orderId" element={<OrderDetailPage />} />
          <Route path="/order-detail/:orderId" element={<OrderDetailPage />} />
          {/* 任务和排行榜页面 */}
          <Route path="/tasks" element={<TasksPage />} />
          <Route path="/ranking" element={<RankingPage />} />
          {/* 认证和设置页面 */}
          <Route path="/login" element={<RiderLoginPage />} />
          <Route path="/register" element={<RiderRegisterPage />} />
          <Route path="/auth" element={<RiderAuthPage />} />
          <Route path="/settings" element={<RiderSettingsPage />} />
          <Route path="/customer-service" element={<RiderCustomerServicePage />} />
          <Route path="/audit-status" element={<AuditStatusPage />} />
          {/* 提现记录页面 */}
          <Route path="/withdrawal-records" element={<WithdrawalRecordsPage />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
