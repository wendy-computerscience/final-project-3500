import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { MapContainer, TileLayer, Marker, Polyline, Popup } from 'react-leaflet';
import { NavBar, Card, Tag, Loading, ErrorBlock } from 'antd-mobile';
import { EnvironmentOutline, ClockCircleOutline } from 'antd-mobile-icons';
import { getTrackingInfo, getOrderRoute } from '../api/tracking';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './TrackingPage.css';

// 修复 Leaflet 默认图标问题
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// 自定义图标
const restaurantIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const courierIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const userIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const TrackingPage = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [trackingData, setTrackingData] = useState(null);
  const [routeData, setRouteData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const intervalRef = useRef(null);
  const mapRef = useRef(null);

  // 获取追踪数据
  const fetchTrackingData = async () => {
    try {
      const result = await getTrackingInfo(orderId);
      if (result.success) {
        setTrackingData(result.data);
        setError(null);
      } else {
        setError(result.message);
      }
    } catch (err) {
      console.error('获取追踪信息失败:', err);
      setError(t('tracking.loadFailed'));
    }
  };

  // 获取路径数据
  const fetchRouteData = async () => {
    try {
      const result = await getOrderRoute(orderId);
      if (result.success) {
        setRouteData(result.data);
      }
    } catch (err) {
      console.error('获取路径失败:', err);
    }
  };

  // 初始加载
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchTrackingData(), fetchRouteData()]);
      setLoading(false);
    };

    loadData();

    // 设置轮询（每5秒更新一次）
    intervalRef.current = setInterval(fetchTrackingData, 5000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [orderId]);

  // 自动调整地图视野
  useEffect(() => {
    if (mapRef.current && trackingData && routeData) {
      const bounds = [];

      if (trackingData.courier) {
        bounds.push([trackingData.courier.lat, trackingData.courier.lng]);
      }
      if (routeData.pickup) {
        bounds.push([routeData.pickup.lat, routeData.pickup.lng]);
      }
      if (routeData.drop) {
        bounds.push([routeData.drop.lat, routeData.drop.lng]);
      }

      if (bounds.length > 0) {
        mapRef.current.fitBounds(bounds, { padding: [50, 50] });
      }
    }
  }, [trackingData, routeData]);

  if (loading) {
    return (
      <div className="tracking-loading">
        <Loading size="large" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="tracking-error">
        <NavBar onBack={() => navigate(-1)}>{t('tracking.title')}</NavBar>
        <div className="tracking-error-content">
          <ErrorBlock status="default" title={t('tracking.loadFailed')} description={error} />
        </div>
      </div>
    );
  }

  if (!trackingData) {
    return null;
  }

  // 订单不可追踪（不在配送状态）
  if (trackingData.trackable === false) {
    // 待支付订单直接跳转到支付页面
    if (trackingData.status === 'pending_payment') {
      navigate(`/payment/${orderId}`, { replace: true });
      return null;
    }

    return (
      <div className="tracking-page">
        <NavBar onBack={() => navigate(-1)}>{t('tracking.title')}</NavBar>
        <div className="tracking-not-trackable">
          <Card className="tracking-status-card">
            <div className="tracking-status-content">
              <ClockCircleOutline fontSize={48} color="#1677ff" />
              <div className="tracking-status-text">
                {t(`tracking.status.${trackingData.status}`) || trackingData.message}
              </div>
              <div className="tracking-status-hint">
                {trackingData.message}
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  // 构建路径点
  const pathPoints = routeData?.path || [
    [routeData?.pickup?.lat, routeData?.pickup?.lng],
    [routeData?.drop?.lat, routeData?.drop?.lng]
  ];

  return (
    <div className="tracking-page">
      <NavBar onBack={() => navigate(-1)}>{t('tracking.title')}</NavBar>

      {/* 地图区域 */}
      <div className="tracking-map-container">
        <MapContainer
          ref={mapRef}
          center={[
            trackingData.courier?.lat || routeData?.pickup?.lat || 22.302,
            trackingData.courier?.lng || routeData?.pickup?.lng || 114.172
          ]}
          zoom={14}
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {/* 配送路径 */}
          {pathPoints && pathPoints.length > 0 && (
            <Polyline
              positions={pathPoints}
              color="#1677ff"
              weight={4}
              opacity={0.7}
              dashArray="10, 10"
            />
          )}

          {/* 餐厅标记 */}
          {routeData?.pickup && (
            <Marker
              position={[routeData.pickup.lat, routeData.pickup.lng]}
              icon={restaurantIcon}
            >
              <Popup>{t('tracking.restaurantLocation')}</Popup>
            </Marker>
          )}

          {/* 配送地址标记 */}
          {routeData?.drop && (
            <Marker
              position={[routeData.drop.lat, routeData.drop.lng]}
              icon={userIcon}
            >
              <Popup>{t('tracking.deliveryAddress')}</Popup>
            </Marker>
          )}

          {/* 骑手位置标记 */}
          {trackingData.courier && (
            <Marker
              position={[trackingData.courier.lat, trackingData.courier.lng]}
              icon={courierIcon}
            >
              <Popup>{t('tracking.courierLocation')}</Popup>
            </Marker>
          )}
        </MapContainer>

        {/* ETA 悬浮卡片 */}
        <Card className="tracking-eta-card">
          <div className="tracking-eta-content">
            <div className="tracking-eta-left">
              <ClockCircleOutline fontSize={20} color="#1677ff" />
              <div className="tracking-eta-text">
                <div className="tracking-eta-label">{t('tracking.eta')}</div>
                <div className="tracking-eta-time">
                  {t('tracking.minutes', { count: trackingData.etaMinutes })}
                </div>
              </div>
            </div>
            <Tag color="primary" fill="outline">
              {t(`tracking.status.${trackingData.status}`) || trackingData.status}
            </Tag>
          </div>
        </Card>
      </div>

      {/* 订单进度卡片 */}
      <div className="tracking-progress-card">
        <div className="tracking-progress-title">{t('tracking.progress')}</div>
        <div className="tracking-progress-list">
          {trackingData.events && trackingData.events.map((event, index) => (
            <div key={index} className="tracking-progress-item">
              <div className={`tracking-progress-dot ${index === trackingData.events.length - 1 ? 'active' : ''}`} />
              <div className="tracking-progress-info">
                <div className={`tracking-progress-text ${index === trackingData.events.length - 1 ? 'active' : ''}`}>
                  {t(`tracking.status.${event.type}`) || event.type}
                </div>
                <div className="tracking-progress-time">
                  {new Date(event.ts).toLocaleTimeString('zh-CN', {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 骑手信息卡片 */}
      {trackingData.courier && (
        <div className="tracking-courier-card">
          <div className="tracking-courier-content">
            <div className="tracking-courier-left">
              <div className="tracking-courier-avatar">
                <EnvironmentOutline fontSize={24} color="#1677ff" />
              </div>
              <div className="tracking-courier-info">
                <div className="tracking-courier-status">{t('tracking.courierDelivering')}</div>
                <div className="tracking-courier-update">
                  {t('tracking.lastUpdate', { time: new Date(trackingData.lastSeenTs).toLocaleTimeString('zh-CN') })}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TrackingPage;
