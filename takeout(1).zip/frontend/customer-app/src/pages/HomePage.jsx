import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Tag,
  Skeleton,
  ErrorBlock,
  PullToRefresh,
  SearchBar,
  Swiper,
  Button,
  NavBar
} from 'antd-mobile';
import {
  EnvironmentOutline,
  StarOutline,
  GiftOutline,
  ShopbagOutline
} from 'antd-mobile-icons';
import useUserStore from '../store/userStore';
import { restaurantApi } from '../api';
import './HomePage.css';

const HomePage = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user, location } = useUserStore();
  const [foods, setFoods] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load all foods from backend (with embedded restaurant info)
  const loadFoods = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await restaurantApi.getAllFoods({
        page: 1,
        pageSize: 20,
        sortBy: 'sales'
      });

      if (!response.success || !response.data) {
        setError(t('home.loadFailed'));
        return;
      }

      setFoods(response.data.foods || []);
    } catch (err) {
      console.error('加载菜品失败:', err);
      setError(t('common.networkError'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFoods();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onRefresh = async () => {
    await loadFoods();
  };

  const handleSearch = (value) => {
    if (!value.trim()) return;
    navigate('/search', { state: { keyword: value } });
  };

  const handleFoodClick = (food) => {
    navigate(`/food/${food.id}`, {
      state: {
        food,
        restaurant: food.restaurant
      }
    });
  };

  const banners = [
    {
      id: 1,
      title: t('home.banner.newUser'),
      color: '#FF6B00'
    },
    {
      id: 2,
      title: t('home.banner.discount'),
      color: '#00B578'
    },
    {
      id: 3,
      title: t('home.banner.fastDelivery'),
      color: '#1677FF'
    }
  ];

  return (
    <div className="home-page">
      <NavBar back={null}>
        {t('home.title')}
      </NavBar>

      {/* search bar */}
      <div className="home-search-bar">
        <SearchBar
          placeholder={t('home.searchPlaceholder')}
          onSearch={handleSearch}
          onFocus={() => navigate('/search')}
        />
      </div>

      <PullToRefresh onRefresh={onRefresh}>
        {/* location info */}
        <div className="home-location-bar">
          <div className="location">
            <EnvironmentOutline fontSize={18} />
            <span className="location-text">{location?.address}</span>
          </div>
        </div>

        {/* banner */}
        <Swiper autoplay loop className="home-swiper">
          {banners.map((banner) => (
            <Swiper.Item key={banner.id}>
              <div className="banner-item" style={{ backgroundColor: banner.color }}>
                <div className="banner-title">{banner.title}</div>
              </div>
            </Swiper.Item>
          ))}
        </Swiper>

        {/* promotion */}
        <Card className="promotion-card">
          <div className="promotion-header">
            <GiftOutline color="#FF6B00" fontSize={18} />
            <span className="promotion-title">{t('home.promotion.title')}</span>
          </div>
          <div className="promotion-content">
            <Tag color="danger" fill="outline">
              {t('home.promotion.newUser')}
            </Tag>
            <span className="promotion-text">
              {t('home.promotion.firstOrder')}
            </span>
            <Button size="small" color="danger" fill="outline">
              {t('home.promotion.claim')}
            </Button>
          </div>
        </Card>

        {/* food list */}
        <div className="food-section">
          {loading && (
            <div className="home-loading-skeleton">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="home-food-card">
                  <Skeleton.Title animated />
                  <Skeleton.Paragraph lineCount={2} animated />
                </Card>
              ))}
            </div>
          )}

          {error && !loading && (
            <ErrorBlock
              status="default"
              title={t('home.loadFailed')}
              description={error}
            />
          )}

          {!loading && !error && foods.length > 0 && (
            <div className="home-food-list">
              {foods.map((food, index) => (
                  <Card
                    key={food.id}
                    className="home-food-card"
                    onClick={() => handleFoodClick(food)}
                  >
                    <div className="food-card-content">
                      <div className="food-image">
                        {food.image ? (
                          <img src={food.image} alt={food.name} className="food-img" />
                        ) : (
                          <div className="image-placeholder">🍜</div>
                        )}
                        {index < 3 && (
                          <div className="hot-badge">🔥 HOT</div>
                        )}
                        {food.monthSales > 1000 && (
                          <div className="sales-badge">
                            {t('home.monthlySales')}
                            {food.monthSales}+
                          </div>
                        )}
                      </div>
                      <div className="food-info">
                        <div className="food-info-top">
                          <div className="food-name">{food.name}</div>
                          <div className="food-desc">{food.description}</div>
                          {food.restaurant && (
                            <div className="food-restaurant">
                              <ShopbagOutline fontSize={12} />
                              <span>{food.restaurant.name}</span>
                            </div>
                          )}
                        </div>
                        <div className="food-footer">
                          <div className="food-price">
                            <span className="price-symbol">$</span>
                            <span className="price-value">{food.price}</span>
                          </div>
                          <div className="food-meta">
                            <StarOutline fontSize={12} />
                            <span>{food.rating || 4.5}</span>
                            <span className="divider">·</span>
                            <span>
                              {t('home.monthlySales')}
                              {food.monthSales}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
            </div>
          )}

          {!loading && !error && foods.length === 0 && (
            <ErrorBlock
              status="empty"
              title=""
              description={t('home.noFood')}
            />
          )}
        </div>
      </PullToRefresh>
    </div>
  );
};

export default HomePage;

