import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Form,
  Input,
  Button,
  Checkbox,
  Toast
} from 'antd-mobile';
import { EyeInvisibleOutline, EyeOutline } from 'antd-mobile-icons';
import useUserStore from '../store/userStore';
import { userApi } from '../api';
import './LoginPage.css';

const LoginPage = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { login, isLoggedIn } = useUserStore();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // 如果已登录，跳转到首页
  useEffect(() => {
    if (isLoggedIn) {
      navigate('/home', { replace: true });
    }
  }, [isLoggedIn, navigate]);

  // 登录
  const handleLogin = async () => {
    // 表单验证
    if (!username) {
      Toast.show({
        icon: 'fail',
        content: t('login.usernameRequired')
      });
      return;
    }

    if (username.length < 3) {
      Toast.show({
        icon: 'fail',
        content: t('login.usernameMinLength')
      });
      return;
    }

    if (!password) {
      Toast.show({
        icon: 'fail',
        content: t('login.passwordRequired')
      });
      return;
    }

    if (password.length < 6) {
      Toast.show({
        icon: 'fail',
        content: t('login.passwordMinLength')
      });
      return;
    }

    if (!agreed) {
      Toast.show({
        icon: 'fail',
        content: t('login.agreeToTerms')
      });
      return;
    }

    try {
      setLoading(true);

      // 调用登录API（不存在则自动注册）
      const response = await userApi.login({ username, password });

      if (response.success && response.data) {
        // 提取用户数据和token
        const { token, user: userData } = response.data;

        // 调用store的login方法
        login({
          id: userData.id,
          name: userData.nickname || userData.username,
          username: userData.username,
          tastes: [],
          token: token
        });

        Toast.show({
          icon: 'success',
          content: t('login.loginSuccess')
        });

        // 跳转到首页
        setTimeout(() => {
          navigate('/home', { replace: true });
        }, 500);
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('login.loginFailed')
        });
      }
    } catch (error) {
      console.error('登录失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('login.loginFailedRetry')
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        {/* 标题 */}
        <div className="login-header">
          <h1 className="app-name">{t('login.appName')}</h1>
          <p className="welcome-text">{t('login.welcomeText')}</p>
        </div>

        {/* 登录表单 */}
        <div className="login-form">
          <Form layout="horizontal">
            {/* 账号 */}
            <Form.Item>
              <Input
                placeholder={t('login.usernamePlaceholder')}
                value={username}
                onChange={setUsername}
                clearable
                style={{
                  '--font-size': '16px',
                  '--placeholder-color': '#999'
                }}
              />
            </Form.Item>

            {/* 密码 */}
            <Form.Item>
              <div className="password-input-wrapper">
                <Input
                  placeholder={t('login.passwordPlaceholder')}
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={setPassword}
                  clearable
                  style={{
                    '--font-size': '16px',
                    '--placeholder-color': '#999'
                  }}
                />
                <div
                  className="password-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOutline /> : <EyeInvisibleOutline />}
                </div>
              </div>
            </Form.Item>
          </Form>

          {/* 登录按钮 */}
          <Button
            block
            color="primary"
            size="large"
            loading={loading}
            onClick={handleLogin}
            className="login-button"
            style={{
              '--background-color': '#667eea',
              '--border-radius': '8px'
            }}
          >
            {t('login.loginRegister')}
          </Button>

          {/* 提示文字 */}
          <div className="login-tip">
            {t('login.autoRegisterTip')}
          </div>

          {/* 用户协议 */}
          <div className="agreement">
            <Checkbox
              checked={agreed}
              onChange={setAgreed}
              style={{
                '--icon-size': '16px',
                '--gap': '6px'
              }}
            >
              <span className="agreement-text">
                {t('login.readAgreement')}
                <a href="#" className="link">{t('login.userAgreement')}</a>
                {t('login.and')}
                <a href="#" className="link">{t('login.privacyPolicy')}</a>
              </span>
            </Checkbox>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
