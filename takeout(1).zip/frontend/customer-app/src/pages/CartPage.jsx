import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  NavBar,
  Empty,
  Card,
  Stepper,
  Button,
  Divider
} from 'antd-mobile';
import useCartStore from '../store/cartStore';
import useUserStore from '../store/userStore';
import './CartPage.css';

const CartPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  const { user } = useUserStore();
  const {
    carts,
    setUserId,
    loadCartFromServer,
    removeItem,
    updateItemQuantity,
    clearCart,
    getTotalAmount,
    getTotalQuantity,
  } = useCartStore();

  // 每次进入购物车页面时加载最新数据
  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
      loadCartFromServer(user.id);
    }
  }, [location.pathname, setUserId, loadCartFromServer]);

  const totalAmount = getTotalAmount();
  const totalQuantity = getTotalQuantity();
  const hasItems = carts.length > 0 && carts.some(cart => cart.items.length > 0);

  return (
    <div className="cart-page">
      {/* 顶部导航栏 */}
      <NavBar back={null} style={{ '--border-bottom': '1px solid #f0f0f0' }}>
        {t('nav.cart')}
      </NavBar>

      {/* 购物车内容 */}
      <div className="cart-content">
        {!hasItems ? (
          <div className="empty-cart">
            <Empty
              description={t('cart.empty')}
              imageStyle={{ width: 128 }}
            />
          </div>
        ) : (
          <>
            {/* 按餐厅分组显示购物车 */}
            {carts.map(cart => (
              <div key={cart.restaurantId} className="cart-section">
                {/* 餐厅信息 */}
                <Card className="restaurant-card">
                  <div className="restaurant-header">
                    <div className="restaurant-name">{cart.restaurantName}</div>
                    <div className="restaurant-info">
                      起送￥{cart.restaurant.minOrder} | 配送费￥{cart.restaurant.deliveryFee}
                    </div>
                  </div>
                </Card>

                {/* 购物车商品列表 */}
                <Card className="cart-items-card">
                  <div className="cart-items">
                    {cart.items.map(item => (
                      <div key={item.cartItemId} className="cart-item">
                        <div className="item-info">
                          <div className="item-name">{item.name}</div>
                          <div className="item-desc">{item.description}</div>
                          <div className="item-price">￥{item.price}</div>
                        </div>
                        <Stepper
                          value={item.quantity}
                          onChange={(value) => {
                            if (value === 0) {
                              removeItem(item.cartItemId);
                            } else {
                              updateItemQuantity(item.cartItemId, value);
                            }
                          }}
                          min={0}
                        />
                      </div>
                    ))}
                  </div>
                </Card>

                <Divider />
              </div>
            ))}

            {/* 底部操作栏 */}
            <div className="cart-bottom-bar">
              <div className="bottom-info">
                <div className="total-amount">
                  <span className="label">{t('cart.total')}:</span>
                  <span className="amount">￥{totalAmount.toFixed(2)}</span>
                </div>
                <div className="total-quantity">
                  {t('cart.totalItems', { count: totalQuantity })}
                </div>
              </div>
              <div className="bottom-actions">
                <Button
                  color="primary"
                  onClick={() => {
                    // 导航到结算页面，使用第一个购物车
                    if (carts.length > 0) {
                      const firstCart = carts[0];
                      navigate('/checkout', {
                        state: {
                          restaurant: {
                            id: firstCart.restaurantId,
                            name: firstCart.restaurantName,
                            ...firstCart.restaurant
                          }
                        }
                      });
                    }
                  }}
                  size="large"
                >
                  {t('cart.checkout')}
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CartPage;
