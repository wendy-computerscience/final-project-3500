import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Tabs,
  Tag,
  Button,
  Empty,
  Toast,
  Skeleton,
  NavBar
} from 'antd-mobile';
import {
  GiftOutline
} from 'antd-mobile-icons';
import useUserStore from '../store/userStore';
import { couponApi } from '../api';
import './CouponPage.css';

const CouponPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useUserStore();
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('unused');
  const [coupons, setCoupons] = useState({
    unused: [],
    used: [],
    expired: []
  });
  const [redPacketBalance, setRedPacketBalance] = useState(0);
  const [loading, setLoading] = useState(true);

  // 加载优惠券列表
  const loadCoupons = async () => {
    try {
      setLoading(true);
      const response = await couponApi.getUserCoupons(user.id);

      if (response.success && response.data) {
        // 按状态分类优惠券
        const categorizedCoupons = {
          unused: response.data.filter(c => c.type === 'unused'),
          used: response.data.filter(c => c.type === 'used'),
          expired: response.data.filter(c => c.type === 'expired'),
        };
        setCoupons(categorizedCoupons);
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('coupon.loadFailed'),
        });
      }
    } catch (error) {
      console.error('加载优惠券失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('coupon.loadFailed'),
      });
    } finally {
      setLoading(false);
    }
  };

  // 加载红包余额
  const loadRedPacket = async () => {
    try {
      const response = await couponApi.getRedPacket(user.id);
      if (response.success && response.data) {
        setRedPacketBalance(response.data.balance || 0);
      }
    } catch (error) {
      console.error('加载红包余额失败:', error);
    }
  };

  useEffect(() => {
    if (user?.id) {
      loadCoupons();
      loadRedPacket();
    }
  }, [user?.id, location.pathname, activeTab]);

  const filteredCoupons = coupons[activeTab] || [];

  const renderCouponCard = (coupon) => {
    const isExpired = coupon.type === 'expired';
    const isUsed = coupon.type === 'used';

    return (
      <Card key={coupon.id} className={`coupon-card ${coupon.type}`}>
        <div className="coupon-left">
          <div className="coupon-amount">
            <span className="currency">$</span>
            <span className="value">{coupon.amount}</span>
          </div>
          <div className="coupon-condition">{coupon.conditionKey || t('coupon.noThreshold')}</div>
        </div>

        <div className="coupon-divider"></div>

        <div className="coupon-right">
          <div className="coupon-info">
            <div className="coupon-scope">{coupon.scopeKey || t('coupon.allScope')}</div>
            <div className="coupon-expiry">
              {isUsed
                ? t('coupon.used', { date: new Date(coupon.expiryDate).toLocaleDateString() })
                : t('coupon.validUntil', { date: new Date(coupon.expiryDate).toLocaleDateString() })}
            </div>
          </div>

          {!isExpired && !isUsed && (
            <Button
              size="small"
              color="primary"
              fill="outline"
              onClick={() => navigate('/')}
            >
              {t('coupon.use')}
            </Button>
          )}

          {isExpired && (
            <Tag color="default" fill="outline">{t('coupon.expired')}</Tag>
          )}

          {isUsed && (
            <Tag color="success" fill="outline">{t('coupon.usedTag')}</Tag>
          )}
        </div>
      </Card>
    );
  };

  return (
    <div className="coupon-page">
      <NavBar onBack={() => navigate(-1)}>
        {t('coupon.title')}
      </NavBar>

      {/* 红包余额卡片 */}
      <Card className="red-packet-card">
        <div className="red-packet-content">
          <GiftOutline fontSize={32} color="#FF6B00" />
          <div className="red-packet-info">
            <div className="red-packet-label">{t('coupon.redPacketBalance')}</div>
            <div className="red-packet-balance">$ {redPacketBalance.toFixed(2)}</div>
          </div>
          <Button
            size="small"
            color="warning"
            onClick={() => navigate('/coupon/center')}
          >
            {t('coupon.center')}
          </Button>
        </div>
      </Card>

      {/* Tabs */}
      <div className="tabs-wrapper">
        <Tabs activeKey={activeTab} onChange={setActiveTab}>
          <Tabs.Tab
            title={t('coupon.unusedCount', { count: coupons.unused.length })}
            key="unused"
          />
          <Tabs.Tab
            title={t('coupon.usedCount', { count: coupons.used.length })}
            key="used"
          />
          <Tabs.Tab
            title={t('coupon.expiredCount', { count: coupons.expired.length })}
            key="expired"
          />
        </Tabs>
      </div>

      {/* 优惠券列表 */}
      <div className="coupons-container">
        {loading ? (
          <div className="loading-skeleton">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="coupon-card">
                <Skeleton.Title animated />
                <Skeleton.Paragraph lineCount={2} animated />
              </Card>
            ))}
          </div>
        ) : filteredCoupons.length === 0 ? (
          <Empty
            description={t('coupon.empty')}
            imageStyle={{ width: 128 }}
          />
        ) : (
          <div className="coupons-list">
            {filteredCoupons.map(coupon => renderCouponCard(coupon))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CouponPage;
