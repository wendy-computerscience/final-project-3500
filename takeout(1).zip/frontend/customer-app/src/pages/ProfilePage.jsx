import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';
import {
  Card,
  List,
  Badge,
  Dialog
} from 'antd-mobile';
import {
  UnorderedListOutline,
  EnvironmentOutline,
  GiftOutline,
  MessageOutline,
  SetOutline,
  RightOutline,
  StarOutline,
  TruckOutline,
  DownOutline,
  CheckOutline
} from 'antd-mobile-icons';
import useUserStore from '../store/userStore';
import { orderApi, couponApi } from '../api';
import './ProfilePage.css';

const ProfilePage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, i18n } = useTranslation();
  const { user, location: userLocation, logout } = useUserStore();
  const [languageExpanded, setLanguageExpanded] = useState(false);
  const [points, setPoints] = useState(0);
  const [couponCount, setCouponCount] = useState(0);
  const [orderBadges, setOrderBadges] = useState({
    pending: 0,
    delivering: 0,
    completed: 0
  });

  // 如果用户未登录，重定向到登录页
  useEffect(() => {
    if (!user || !user.id) {
      navigate('/login', { replace: true });
    }
  }, [user, navigate]);

  useEffect(() => {
    const loadStats = async () => {
      if (!user?.id) return;

      try {
        const [ordersRes, couponsRes] = await Promise.all([
          orderApi.getOrdersBadge(user.id),
          couponApi.getUserCoupons(user.id, 'unused')
        ]);

        if (ordersRes.success && ordersRes.data) {
          setOrderBadges({
            pending: ordersRes.data.pending_payment || 0,
            delivering: ordersRes.data.delivering || 0,
            completed: ordersRes.data.completed || 0
          });
        }

        if (couponsRes.success && Array.isArray(couponsRes.data)) {
          setCouponCount(couponsRes.data.length);
        }
      } catch (e) {
        // 静默失败，不影响页面其他功能
        // console.error('加载用户统计信息失败:', e);
      }
    };

    loadStats();
  }, [user?.id, location.pathname]);

  // 语言选项
  const languageOptions = [
    { label: '中文', value: 'zh' },
    { label: 'English', value: 'en' }
  ];

  // 获取当前语言标签
  const getCurrentLanguageLabel = () => {
    const current = languageOptions.find(opt => opt.value === i18n.language);
    return current ? current.label : '中文';
  };

  // 切换语言
  const handleLanguageChange = (value) => {
    i18n.changeLanguage(value);
    localStorage.setItem('language', value);
    setLanguageExpanded(false); // 选择后收起
  };

  // 处理菜单点击
  const handleMenuClick = (key) => {
    switch (key) {
      case 'orders':
        navigate('/orders');
        break;
      case 'address':
        navigate('/address');
        break;
      case 'coupons':
        navigate('/coupons');
        break;
      case 'service':
        Dialog.alert({
          content: t('profile.servicePhone'),
          confirmText: t('profile.gotIt')
        });
        break;
      case 'settings':
        console.log('跳转到设置');
        // TODO: navigate('/settings');
        break;
      default:
        break;
    }
  };

  // 退出登录
  const handleLogout = () => {
    Dialog.confirm({
      content: t('profile.logoutConfirm'),
      onConfirm: () => {
        logout();
        navigate('/login', { replace: true });
      }
    });
  };

  return (
    <div className="profile-page">
      {/* 用户信息卡片 */}
      <Card className="user-card">
        <div className="user-info">
          {/* 头像 */}
          <div className="user-avatar">
            <div className="avatar-placeholder">
              {user?.name?.charAt(0) || '?'}
            </div>
          </div>

          {/* 用户名和会员信息 */}
          <div className="user-details">
            <div className="user-name">{user?.name || ''}</div>
            <div className="user-level">
              <StarOutline fontSize={12} color="#FFB800" />
              <span>{t('profile.member')}</span>
              <span className="level-badge">LV1</span>
            </div>
          </div>
        </div>

        {/* 积分和优惠券 */}
        <div className="user-stats">
          <div className="stat-item">
            <div className="stat-value">{points}</div>
            <div className="stat-label">{t('profile.points')}</div>
          </div>
          <div className="stat-divider"></div>
          <div
            className="stat-item"
            onClick={() => handleMenuClick('coupons')}
          >
            <div className="stat-value">{couponCount}</div>
            <div className="stat-label">{t('profile.coupons')}</div>
          </div>
        </div>
      </Card>

      {/* 当前位置 */}
      <Card className="location-card">
        <div className="location-info">
          <EnvironmentOutline fontSize={18} color="#667eea" />
          <div className="location-text">
            <div className="location-label">{t('profile.currentLocation')}</div>
            <div className="location-address">{t('location.defaultAddress')}</div>
          </div>
          <RightOutline fontSize={14} color="#999" />
        </div>
      </Card>

      {/* 订单入口 */}
      <Card className="orders-entry-card">
        <div className="card-title">{t('profile.myOrders')}</div>
        <div className="order-types">
          <div className="order-type-item" onClick={() => navigate('/orders?status=pending')}>
            <Badge content={orderBadges.pending} style={{ '--right': '-8px', '--top': '-4px' }}>
              <div className="order-type-icon" style={{ color: '#FF6B00' }}>
                <TruckOutline fontSize={24} />
              </div>
            </Badge>
            <div className="order-type-label">{t('profile.pending')}</div>
          </div>
          <div className="order-type-item" onClick={() => navigate('/orders?status=delivering')}>
            <Badge content={orderBadges.delivering} style={{ '--right': '-8px', '--top': '-4px' }}>
              <div className="order-type-icon" style={{ color: '#1677FF' }}>
                <TruckOutline fontSize={24} />
              </div>
            </Badge>
            <div className="order-type-label">{t('profile.delivering')}</div>
          </div>
          <div className="order-type-item" onClick={() => navigate('/orders?status=completed')}>
            <div className="order-type-icon" style={{ color: '#00B578' }}>
              <UnorderedListOutline fontSize={24} />
            </div>
            <div className="order-type-label">{t('profile.completed')}</div>
          </div>
          <div className="order-type-item" onClick={() => navigate('/orders')}>
            <div className="order-type-icon" style={{ color: '#999' }}>
              <UnorderedListOutline fontSize={24} />
            </div>
            <div className="order-type-label">{t('profile.allOrders')}</div>
          </div>
        </div>
      </Card>

      {/* 功能菜单 */}
      <Card className="menu-card">
        <List>
          <List.Item
            prefix={<EnvironmentOutline fontSize={20} />}
            onClick={() => handleMenuClick('address')}
            arrow
          >
            {t('profile.addressManage')}
          </List.Item>
          <List.Item
            prefix={<GiftOutline fontSize={20} />}
            onClick={() => handleMenuClick('coupons')}
            arrow
          >
            {t('profile.couponRedPacket')}
          </List.Item>
          <List.Item
            prefix={<MessageOutline fontSize={20} />}
            onClick={() => handleMenuClick('service')}
            arrow
          >
            {t('profile.contactService')}
          </List.Item>
        </List>
      </Card>

      {/* 语言设置（手风琴样式） */}
      <Card className="menu-card" style={{ marginTop: '12px' }}>
        <List>
          <List.Item
            prefix={<SetOutline fontSize={20} />}
            onClick={() => setLanguageExpanded(!languageExpanded)}
            arrow={!languageExpanded ? <RightOutline /> : <DownOutline />}
            extra={<span style={{ color: '#999', fontSize: '14px' }}>{getCurrentLanguageLabel()}</span>}
          >
            {t('profile.languageSettings')}
          </List.Item>
          {languageExpanded && (
            <div style={{
              padding: '8px 12px 12px',
              backgroundColor: '#f7f8fa'
            }}>
              {languageOptions.map(option => (
                <div
                  key={option.value}
                  onClick={() => handleLanguageChange(option.value)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '12px 16px',
                    marginTop: '8px',
                    backgroundColor: i18n.language === option.value ? '#f0f2ff' : '#fff',
                    border: i18n.language === option.value ? '1.5px solid #667eea' : '1px solid #e5e5e5',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                >
                  <span style={{
                    fontSize: '15px',
                    color: i18n.language === option.value ? '#667eea' : '#333',
                    fontWeight: i18n.language === option.value ? '500' : 'normal'
                  }}>
                    {option.label}
                  </span>
                  {i18n.language === option.value && (
                    <CheckOutline fontSize={18} color="#667eea" />
                  )}
                </div>
              ))}
            </div>
          )}
        </List>
      </Card>

      {/* 退出登录按钮 */}
      <div className="logout-section">
        <div className="logout-button" onClick={handleLogout}>
          {t('profile.logout')}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
