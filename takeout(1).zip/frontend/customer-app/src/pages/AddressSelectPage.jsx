import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  NavBar,
  Card,
  Button,
  Tag,
  Toast,
  Empty,
  Radio,
  Space
} from 'antd-mobile';
import {
  AddOutline,
  LocationFill,
  PhoneFill
} from 'antd-mobile-icons';
import useUserStore from '../store/userStore';
import { addressApi } from '../api';
import './AddressSelectPage.css';

const AddressSelectPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useUserStore();
  const { t } = useTranslation();
  const [addresses, setAddresses] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [loading, setLoading] = useState(true);

  // 从路由参数获取返回页面和当前选中的地址
  const returnTo = location.state?.returnTo || '/checkout';
  const currentAddressId = location.state?.currentAddressId;

  // 加载地址列表
  const loadAddresses = async () => {
    try {
      setLoading(true);
      const response = await addressApi.getAddressList(user.id);

      if (response.success && response.data) {
        setAddresses(response.data);

        // 设置初始选中的地址（优先级：传入的地址 > 默认地址 > 第一个地址）
        if (currentAddressId) {
          setSelectedId(currentAddressId);
        } else {
          const defaultAddr = response.data.find(addr => addr.isDefault);
          const initialId = defaultAddr?.id || response.data[0]?.id;
          setSelectedId(initialId);
        }
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('address.loadFailed'),
        });
      }
    } catch (error) {
      console.error('加载地址失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('address.loadFailed'),
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      loadAddresses();
    }
  }, [user?.id]);

  // 确认选择
  const handleConfirm = () => {
    const selectedAddress = addresses.find(addr => addr.id === selectedId);
    if (!selectedAddress) {
      Toast.show(t('address.selectRequired'));
      return;
    }

    // 返回到来源页面，并传递选中的地址
    navigate(returnTo, {
      state: {
        selectedAddress,
        restaurant: location.state?.restaurant
      },
      replace: true
    });
  };

  // 新增地址
  const handleAdd = () => {
    navigate('/address/new', {
      state: {
        returnTo: '/address/select',
        nextReturnTo: returnTo,
        restaurant: location.state?.restaurant
      }
    });
  };

  const renderAddressCard = (address) => {
    const tagColor = {
      '家': 'primary',
      '公司': 'success',
      '学校': 'warning'
    };

    return (
      <Card
        key={address.id}
        className={`address-select-card ${selectedId === address.id ? 'selected' : ''}`}
        onClick={() => setSelectedId(address.id)}
      >
        <div className="card-content">
          <Radio
            checked={selectedId === address.id}
            onChange={() => setSelectedId(address.id)}
            className="address-radio"
          />

          <div className="address-content">
            <div className="address-header">
              <div className="address-info">
                <span className="address-name">{address.name}</span>
                <span className="address-phone">
                  <PhoneFill fontSize={12} /> {address.phone}
                </span>
              </div>
              <div className="address-tags">
                {address.isDefault && (
                  <Tag color="danger" fill="outline" style={{ marginRight: 8 }}>
                    {t('address.default')}
                  </Tag>
                )}
                <Tag color={tagColor[address.tag] || 'default'}>
                  {address.tag}
                </Tag>
              </div>
            </div>

            <div className="address-detail">
              <LocationFill color="#1677FF" fontSize={16} />
              <span className="detail-text">
                {address.detail} {address.room}
              </span>
            </div>
          </div>
        </div>
      </Card>
    );
  };

  return (
    <div className="address-select-page">
      <NavBar onBack={() => navigate(-1)}>
        {t('address.selectTitle')}
      </NavBar>

      <div className="addresses-container">
        {addresses.length === 0 ? (
          <div className="empty-container">
            <Empty
              description={t('address.noAddress')}
              imageStyle={{ width: 128 }}
            />
            <Button
              color="primary"
              size="large"
              onClick={handleAdd}
              style={{ marginTop: 24 }}
            >
              <AddOutline /> {t('address.addNew')}
            </Button>
          </div>
        ) : (
          <>
            <div className="addresses-list">
              <Space direction="vertical" block style={{ '--gap': '12px' }}>
                {addresses.map(address => renderAddressCard(address))}
              </Space>
            </div>

            {/* 添加新地址按钮 */}
            <div className="add-new-section">
              <Button
                block
                fill="outline"
                color="primary"
                size="large"
                onClick={handleAdd}
              >
                <AddOutline /> {t('address.addNew')}
              </Button>
            </div>
          </>
        )}
      </div>

      {/* 底部确认按钮 */}
      {addresses.length > 0 && (
        <div className="select-footer">
          <Button
            block
            color="primary"
            size="large"
            onClick={handleConfirm}
            disabled={!selectedId}
          >
            {t('address.confirmSelect')}
          </Button>
        </div>
      )}
    </div>
  );
};

export default AddressSelectPage;
