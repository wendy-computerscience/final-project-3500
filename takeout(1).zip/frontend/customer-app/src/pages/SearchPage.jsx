import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  SearchBar,
  Card,
  Tag,
  Empty,
  Skeleton
} from 'antd-mobile';
import {
  StarOutline,
  ShopbagOutline
} from 'antd-mobile-icons';
import axios from 'axios';
import './SearchPage.css';

const API_BASE_URL = 'http://localhost:3001';

const SearchPage = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [keyword, setKeyword] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [restaurants, setRestaurants] = useState({});
  const [searching, setSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  // 搜索菜品
  const handleSearch = async (value) => {
    if (!value.trim()) {
      setSearchResults([]);
      setHasSearched(false);
      return;
    }

    try {
      setSearching(true);
      setHasSearched(true);

      // 获取所有餐厅和菜品
      const restaurantsRes = await axios.get(`${API_BASE_URL}/api/restaurants`);

      if (restaurantsRes.data.success) {
        // 构建餐厅映射
        const restaurantMap = {};
        restaurantsRes.data.data.restaurants.forEach(r => {
          restaurantMap[r.id] = r;
        });
        setRestaurants(restaurantMap);

        // 获取所有菜品并进行搜索
        const allFoods = [];
        for (const restaurant of restaurantsRes.data.data.restaurants) {
          const menuData = await axios.get(`${API_BASE_URL}/api/restaurants/${restaurant.id}/menu`);
          if (menuData.data.success) {
            allFoods.push(...menuData.data.data);
          }
        }

        // 搜索包含关键词的菜品（名称或描述）
        const results = allFoods.filter(food =>
          food.name.toLowerCase().includes(value.toLowerCase()) ||
          food.description.toLowerCase().includes(value.toLowerCase())
        );

        // 按销量排序
        results.sort((a, b) => b.monthSales - a.monthSales);
        setSearchResults(results);
      }
    } catch (error) {
      console.error('搜索失败:', error);
    } finally {
      setSearching(false);
    }
  };

  // 点击菜品跳转详情页
  const handleFoodClick = (food) => {
    navigate(`/food/${food.id}`);
  };

  return (
    <div className="search-page">
      {/* 搜索栏 */}
      <div className="search-header">
        <SearchBar
          placeholder={t('search.placeholder')}
          value={keyword}
          onChange={setKeyword}
          onSearch={handleSearch}
          onClear={() => {
            setSearchResults([]);
            setHasSearched(false);
          }}
          showCancelButton
          onCancel={() => navigate(-1)}
          style={{
            '--border-radius': '20px',
            '--background': '#f5f5f5'
          }}
        />
      </div>

      <div className="search-content">
        {/* 搜索中 */}
        {searching && (
          <div className="search-loading">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="food-card">
                <Skeleton.Title animated />
                <Skeleton.Paragraph lineCount={2} animated />
              </Card>
            ))}
          </div>
        )}

        {/* 搜索结果 */}
        {!searching && hasSearched && searchResults.length > 0 && (
          <div className="search-results">
            <div className="result-count">{t('search.foundResults', { count: searchResults.length })}</div>
            <div className="food-grid">
              {searchResults.map((food) => {
                const restaurant = restaurants[food.restaurantId];
                return (
                  <Card
                    key={food.id}
                    className="food-card"
                    onClick={() => handleFoodClick(food)}
                  >
                    {/* 菜品图片 */}
                    <div className="food-image">
                      <div className="image-placeholder">🍜</div>
                      {food.monthSales > 1000 && (
                        <div className="sales-badge">{t('home.monthlySales')}{food.monthSales}+</div>
                      )}
                    </div>

                    {/* 菜品信息 */}
                    <div className="food-info">
                      <div className="food-name">{food.name}</div>
                      <div className="food-desc">{food.description}</div>

                      {/* 餐厅信息 */}
                      {restaurant && (
                        <div className="food-restaurant">
                          <ShopbagOutline fontSize={12} />
                          <span>{restaurant.name}</span>
                        </div>
                      )}

                      {/* 底部信息 */}
                      <div className="food-footer">
                        <div className="food-price">
                          <span className="price-symbol">$</span>
                          <span className="price-value">{food.price}</span>
                        </div>
                        <div className="food-meta">
                          <StarOutline fontSize={12} />
                          <span>{food.rating}</span>
                          <span className="divider">·</span>
                          <span>{t('home.monthlySales')}{food.monthSales}</span>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* 无结果 */}
        {!searching && hasSearched && searchResults.length === 0 && (
          <div className="empty-state">
            <Empty
              description={t('search.noResults')}
              imageStyle={{ width: 128 }}
            />
          </div>
        )}

        {/* 初始状态 */}
        {!searching && !hasSearched && (
          <div className="search-tips">
            <div className="tips-title">{t('search.suggestions')}</div>
            <div className="tips-tags">
              <Tag color="primary" fill="outline" onClick={() => {
                setKeyword(t('search.tags.spicy'));
                handleSearch(t('search.tags.spicy'));
              }}>{t('search.tags.spicy')}</Tag>
              <Tag color="primary" fill="outline" onClick={() => {
                setKeyword(t('search.tags.noodles'));
                handleSearch(t('search.tags.noodles'));
              }}>{t('search.tags.noodles')}</Tag>
              <Tag color="primary" fill="outline" onClick={() => {
                setKeyword(t('search.tags.rice'));
                handleSearch(t('search.tags.rice'));
              }}>{t('search.tags.rice')}</Tag>
              <Tag color="primary" fill="outline" onClick={() => {
                setKeyword(t('search.tags.soup'));
                handleSearch(t('search.tags.soup'));
              }}>{t('search.tags.soup')}</Tag>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchPage;
