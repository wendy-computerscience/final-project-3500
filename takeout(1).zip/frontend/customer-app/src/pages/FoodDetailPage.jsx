import { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { NavBar, Card, Tag, Button, Stepper, Toast, Popup } from 'antd-mobile';
import {
  StarFill,
  LocationFill,
  ShopbagOutline,
  LikeOutline
} from 'antd-mobile-icons';
import { restaurantApi } from '../api';
import useCartStore from '../store/cartStore';
import useUserStore from '../store/userStore';
import './FoodDetailPage.css';

function FoodDetailPage() {
  const { foodId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const { user } = useUserStore();
  const { initCart, addItem, getItemQuantity, setUserId } = useCartStore();

  const [food, setFood] = useState(null);
  const [restaurant, setRestaurant] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [showQuantityPopup, setShowQuantityPopup] = useState(false);
  const [actionType, setActionType] = useState(''); // 'cart' or 'buy'

  // 设置用户ID到购物车store
  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
    }
  }, [user, setUserId]);

  useEffect(() => {
    const stateFood = location.state?.food;
    const stateRestaurant = location.state?.restaurant;

    if (stateFood && stateRestaurant) {
      setFood(stateFood);
      setRestaurant(stateRestaurant);
      setLoading(false);
    } else {
      loadFoodDetailFromApi();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [foodId]);

  const loadFoodDetailFromApi = async () => {
    try {
      setLoading(true);

      // 获取一批餐厅，然后遍历菜单查找目标菜品
      const listRes = await restaurantApi.getRestaurantList({
        page: 1,
        pageSize: 20
      });

      if (!listRes.success || !listRes.data) {
        Toast.show(t('food.loadFailed'));
        return;
      }

      const restaurantList = listRes.data.restaurants || [];
      const targetId = String(foodId);

      for (const rest of restaurantList) {
        try {
          const menuRes = await restaurantApi.getRestaurantMenu(rest.id);
          if (menuRes.success && Array.isArray(menuRes.data)) {
            const found = menuRes.data.find(
              (item) => String(item.id) === targetId
            );
            if (found) {
              setFood(found);
              setRestaurant(rest);
              return;
            }
          }
        } catch (e) {
          console.error('加载餐厅菜单失败:', rest.id, e);
        }
      }

      Toast.show(t('food.notFound'));
    } catch (error) {
      console.error('加载菜品详情失败:', error);
      Toast.show(t('food.loadFailed'));
    } finally {
      setLoading(false);
    }
  };

  const addToCart = () => {
    setActionType('cart');
    setShowQuantityPopup(true);
  };

  const buyNow = () => {
    setActionType('buy');
    setShowQuantityPopup(true);
  };

  const confirmAction = async () => {
    if (!food || !restaurant) {
      setShowQuantityPopup(false);
      setQuantity(1);
      return;
    }

    // 构建餐厅信息对象
    const restaurantInfo = {
      id: restaurant.id,
      lat: restaurant.lat,
      lng: restaurant.lng,
      minOrder: restaurant.minOrder,
      deliveryFee: restaurant.deliveryFee,
      avgPrepMin: restaurant.avgPrepMin,
      merchantId: restaurant.merchantId || restaurant.id
    };

    // 初始化当前餐厅的购物车
    await initCart(restaurant.id, restaurant.name, restaurantInfo);

    // 设置当前菜品数量（需要等待每个addItem完成）
    const currentQty = getItemQuantity(food.id);
    const targetQty = currentQty + quantity;
    for (let i = currentQty; i < targetQty; i += 1) {
      await addItem(food, restaurantInfo);
    }

    if (actionType === 'cart') {
      Toast.show({
        content: t('food.addedToCart', { quantity }),
        duration: 2000
      });
    } else {
      navigate('/checkout', {
        state: {
          restaurant: {
            id: restaurant.id,
            name: restaurant.name,
            minOrder: restaurant.minOrder,
            deliveryFee: restaurant.deliveryFee,
            avgPrepMin: restaurant.avgPrepMin
          }
        }
      });
    }

    setShowQuantityPopup(false);
    setQuantity(1);
  };

  const viewRestaurant = () => {
    if (restaurant) {
      navigate(`/restaurant/${restaurant.id}`);
    }
  };

  if (loading) {
    return (
      <div className="food-detail-page">
        <NavBar onBack={() => navigate(-1)}>{t('food.detail')}</NavBar>
        <div className="loading">{t('food.loading')}</div>
      </div>
    );
  }

  if (!food || !restaurant) {
    return (
      <div className="food-detail-page">
        <NavBar onBack={() => navigate(-1)}>{t('food.detail')}</NavBar>
        <div className="error">{t('food.notFound')}</div>
      </div>
    );
  }

  return (
    <div className="food-detail-page">
      <NavBar onBack={() => navigate(-1)}>{t('food.detail')}</NavBar>

      {/* 菜品图片 */}
      <div className="food-image-section">
        <div className="food-main-image">
          {food.image ? (
            <img src={food.image} alt={food.name} className="food-img" />
          ) : (
            <div className="image-placeholder">🍜</div>
          )}
        </div>
      </div>

      {/* 菜品基本信息 */}
      <Card className="food-info-card">
        <div className="food-header">
          <h2 className="food-title">{food.name}</h2>
          <div className="food-rating">
            <StarFill color="#ff6b00" />
            <span>{food.rating || 4.5}</span>
          </div>
        </div>

        <div className="food-description">{food.description}</div>

        <div className="food-stats">
          <div className="stat-item">
            <LikeOutline fontSize={16} />
            <span>{t('food.monthlySales', { count: food.monthSales })}</span>
          </div>
          <div className="stat-item">
            <StarFill fontSize={16} color="#ff6b00" />
            <span>{t('food.positiveRate', { rate: 95 })}</span>
          </div>
        </div>

        <div className="food-tags">
          {food.tags?.map((tag, index) => (
            <Tag key={index} color="primary" fill="outline">
              {tag}
            </Tag>
          ))}
        </div>

        <div className="food-price-section">
          <div className="price-info">
            <span className="price-label">{t('food.price')}</span>
            <div className="price-value">
              <span className="price-symbol">$</span>
              <span className="price-amount">
                {Number(food.price).toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* 商家信息 */}
      <Card className="restaurant-info-card" onClick={viewRestaurant}>
        <div className="restaurant-header">
          <div className="restaurant-icon">
            <ShopbagOutline fontSize={24} />
          </div>
          <div className="restaurant-info">
            <div className="restaurant-name">{restaurant.name}</div>
            <div className="restaurant-meta">
              <span className="meta-item">
                <StarFill fontSize={12} color="#ff6b00" />
                {restaurant.rating}
              </span>
              <span className="meta-divider">·</span>
              <span className="meta-item">
                {t('food.onTimeRate', {
                  rate: ((restaurant.onTimeRate || 0.95) * 100).toFixed(0)
                })}
              </span>
            </div>
          </div>
        </div>

        <div className="restaurant-delivery-info">
          <div className="delivery-item">
            <span className="delivery-label">{t('food.minOrder')}</span>
            <span className="delivery-value">${restaurant.minOrder}</span>
          </div>
          <div className="delivery-divider" />
          <div className="delivery-item">
            <span className="delivery-label">{t('food.deliveryFee')}</span>
            <span className="delivery-value">${restaurant.deliveryFee}</span>
          </div>
          <div className="delivery-divider" />
          <div className="delivery-item">
            <span className="delivery-label">{t('food.estimated')}</span>
            <span className="delivery-value">
              {t('food.minutes', { count: restaurant.avgPrepMin })}
            </span>
          </div>
        </div>
      </Card>

      {/* 商品详情 */}
      <Card className="detail-section-card">
        <h3 className="section-title">{t('food.detailTitle')}</h3>
        <div className="detail-content">
          <p>{food.description}</p>
          <p className="detail-tips">{t('food.tip')}</p>
        </div>
      </Card>

      {/* 底部操作条 */}
      <div className="bottom-bar">
        <Button
          color="default"
          fill="outline"
          onClick={addToCart}
          style={{ flex: 1 }}
        >
          {t('food.addToCart')}
        </Button>
        <Button
          color="primary"
          onClick={buyNow}
          style={{ flex: 1 }}
        >
          {t('food.buyNow')}
        </Button>
      </div>

      {/* 数量选择弹出层 */}
      <Popup
        visible={showQuantityPopup}
        onMaskClick={() => {
          setShowQuantityPopup(false);
          setQuantity(1);
        }}
        bodyStyle={{
          borderTopLeftRadius: '16px',
          borderTopRightRadius: '16px'
        }}
      >
        <div className="quantity-popup">
          <div className="popup-food-info">
            <div className="popup-food-image">
              {food.image ? (
                <img src={food.image} alt={food.name} />
              ) : (
                <span>🍜</span>
              )}
            </div>
            <div className="popup-food-detail">
              <div className="popup-food-name">{food.name}</div>
              <div className="popup-food-price">${food.price}</div>
            </div>
          </div>

          <div className="popup-quantity-section">
            <span className="quantity-label">{t('food.quantity')}</span>
            <Stepper
              value={quantity}
              onChange={setQuantity}
              min={1}
              max={99}
            />
          </div>

          <div className="popup-total-price">
            <span className="total-label">{t('food.subtotal')}</span>
            <span className="total-value">
              ${(Number(food.price) * quantity).toFixed(2)}
            </span>
          </div>

          <Button
            block
            color="primary"
            size="large"
            onClick={confirmAction}
          >
            {actionType === 'cart'
              ? t('food.confirmAddToCart')
              : t('food.confirmBuy')}
          </Button>
        </div>
      </Popup>
    </div>
  );
}

export default FoodDetailPage;

