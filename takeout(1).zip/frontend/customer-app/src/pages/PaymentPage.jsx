import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { NavBar, Card, Button, Radio, Toast, Loading, ErrorBlock } from 'antd-mobile';
import { orderApi } from '../api';
import './PaymentPage.css';

const PaymentPage = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('wechat');
  const [paying, setPaying] = useState(false);

  // 加载订单详情
  useEffect(() => {
    const loadOrder = async () => {
      try {
        setLoading(true);
        const response = await orderApi.getOrderDetail(orderId);
        if (response.success && response.data) {
          // 检查订单状态
          if (response.data.status !== 'pending_payment') {
            Toast.show({
              icon: 'fail',
              content: t('payment.orderAlreadyPaid')
            });
            navigate('/orders', { replace: true });
            return;
          }
          setOrder(response.data);
        } else {
          setError(response.message || t('payment.loadFailed'));
        }
      } catch (err) {
        console.error('加载订单失败:', err);
        setError(t('payment.loadFailed'));
      } finally {
        setLoading(false);
      }
    };

    loadOrder();
  }, [orderId, navigate, t]);

  // 支付订单
  const handlePay = async () => {
    try {
      setPaying(true);
      const response = await orderApi.payOrder(orderId, paymentMethod);
      if (response.success) {
        Toast.show({
          icon: 'success',
          content: t('payment.paySuccess')
        });
        // 支付成功后跳转到订单列表
        navigate('/orders', { replace: true });
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('payment.payFailed')
        });
      }
    } catch (err) {
      console.error('支付失败:', err);
      Toast.show({
        icon: 'fail',
        content: t('payment.payFailed')
      });
    } finally {
      setPaying(false);
    }
  };

  if (loading) {
    return (
      <div className="payment-loading">
        <Loading size="large" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="payment-error">
        <NavBar onBack={() => navigate(-1)}>{t('payment.title')}</NavBar>
        <div className="payment-error-content">
          <ErrorBlock status="default" title={t('payment.loadFailed')} description={error} />
        </div>
      </div>
    );
  }

  if (!order) {
    return null;
  }

  return (
    <div className="payment-page">
      <NavBar onBack={() => navigate(-1)}>{t('payment.title')}</NavBar>

      {/* 订单金额 */}
      <div className="payment-amount-section">
        <div className="payment-amount-label">{t('payment.amountToPay')}</div>
        <div className="payment-amount-value">
          <span className="payment-currency">$</span>
          <span className="payment-amount">{parseFloat(order.final_amount || order.total_amount).toFixed(2)}</span>
        </div>
      </div>

      {/* 订单信息 */}
      <Card className="payment-order-card">
        <div className="payment-order-info">
          <div className="payment-order-row">
            <span className="payment-order-label">{t('payment.orderNo')}</span>
            <span className="payment-order-value">{order.order_no}</span>
          </div>
          <div className="payment-order-row">
            <span className="payment-order-label">{t('payment.restaurant')}</span>
            <span className="payment-order-value">{order.restaurant_name || t('orders.unknownRestaurant')}</span>
          </div>
        </div>
      </Card>

      {/* 订单商品 */}
      {order.items && order.items.length > 0 && (
        <Card className="payment-items-card">
          <div className="payment-items-title">{t('payment.orderItems')}</div>
          <div className="payment-items-list">
            {order.items.map((item, index) => (
              <div key={index} className="payment-item">
                <div className="payment-item-info">
                  <span className="payment-item-name">{item.name}</span>
                  <span className="payment-item-quantity">x{item.quantity}</span>
                </div>
                <span className="payment-item-price">${parseFloat(item.subtotal).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="payment-items-summary">
            <div className="payment-summary-row">
              <span>{t('payment.subtotal')}</span>
              <span>${parseFloat(order.total_amount).toFixed(2)}</span>
            </div>
            <div className="payment-summary-row">
              <span>{t('payment.deliveryFee')}</span>
              <span>${parseFloat(order.delivery_fee || 0).toFixed(2)}</span>
            </div>
            {order.discount_amount > 0 && (
              <div className="payment-summary-row discount">
                <span>{t('payment.discount')}</span>
                <span>-${parseFloat(order.discount_amount).toFixed(2)}</span>
              </div>
            )}
          </div>
        </Card>
      )}

      {/* 支付方式 */}
      <Card className="payment-method-card">
        <div className="payment-method-title">{t('payment.paymentMethod')}</div>
        <Radio.Group value={paymentMethod} onChange={setPaymentMethod}>
          <div className="payment-method-list">
            <div className="payment-method-item">
              <Radio value="wechat">
                <div className="payment-method-content">
                  <span className="payment-method-icon wechat">W</span>
                  <span className="payment-method-name">{t('payment.wechat')}</span>
                </div>
              </Radio>
            </div>
            <div className="payment-method-item">
              <Radio value="alipay">
                <div className="payment-method-content">
                  <span className="payment-method-icon alipay">A</span>
                  <span className="payment-method-name">{t('payment.alipay')}</span>
                </div>
              </Radio>
            </div>
          </div>
        </Radio.Group>
      </Card>

      {/* 支付按钮 */}
      <div className="payment-footer">
        <Button
          block
          color="primary"
          size="large"
          loading={paying}
          onClick={handlePay}
        >
          {paying ? t('payment.paying') : t('payment.confirmPay')}
        </Button>
      </div>
    </div>
  );
};

export default PaymentPage;
