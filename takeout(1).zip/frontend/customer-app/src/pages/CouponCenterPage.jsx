import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Button,
  NavBar,
  Toast,
  Tag,
  Empty,
  Skeleton
} from 'antd-mobile';
import {
  GiftOutline,
  FireFill
} from 'antd-mobile-icons';
import useUserStore from '../store/userStore';
import { couponApi } from '../api';
import './CouponCenterPage.css';

const CouponCenterPage = () => {
  const navigate = useNavigate();
  const { user } = useUserStore();
  const { t } = useTranslation();
  const [availableCoupons, setAvailableCoupons] = useState([]);
  const [claimedIds, setClaimedIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [claimingIds, setClaimingIds] = useState([]);

  // 加载可领取优惠券列表
  const loadAvailableCoupons = async () => {
    try {
      setLoading(true);
      const response = await couponApi.getAvailableCoupons();

      if (response.success && response.data) {
        setAvailableCoupons(response.data);
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('coupon.loadFailed'),
        });
      }
    } catch (error) {
      console.error('加载优惠券失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('coupon.loadFailed'),
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAvailableCoupons();
  }, []);

  // 领取优惠券
  const handleClaim = async (coupon) => {
    if (claimedIds.includes(coupon.id)) {
      Toast.show({ content: t('coupon.alreadyClaimed') });
      return;
    }

    if (claimingIds.includes(coupon.id)) {
      return; // 正在领取中，防止重复点击
    }

    try {
      setClaimingIds(prev => [...prev, coupon.id]);

      const response = await couponApi.claimCoupon(user.id, coupon.id);

      if (response.success) {
        // 添加到已领取列表
        setClaimedIds(prev => [...prev, coupon.id]);

        Toast.show({
          icon: 'success',
          content: t('coupon.claimSuccess'),
        });

        // 更新剩余数量
        setAvailableCoupons(prev =>
          prev.map(c =>
            c.id === coupon.id ? { ...c, remaining: c.remaining - 1 } : c
          )
        );
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('coupon.claimFailed'),
        });
      }
    } catch (error) {
      console.error('领取优惠券失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('coupon.claimFailed'),
      });
    } finally {
      setClaimingIds(prev => prev.filter(id => id !== coupon.id));
    }
  };

  const renderCouponCard = (coupon) => {
    const isClaimed = claimedIds.includes(coupon.id);
    const isClaiming = claimingIds.includes(coupon.id);

    return (
      <Card key={coupon.id} className={`center-coupon-card ${isClaimed ? 'claimed' : ''}`}>
        {coupon.isHot && (
          <div className="hot-badge">
            <FireFill fontSize={14} />
            <span>{t('coupon.hot')}</span>
          </div>
        )}

        <div className="coupon-main">
          <div className="coupon-left-section">
            <div className="coupon-amount-large">
              <span className="currency">$</span>
              <span className="value">{coupon.amount}</span>
            </div>
            <div className="coupon-condition">{coupon.conditionKey || t('coupon.noThreshold')}</div>
          </div>

          <div className="coupon-divider-vertical"></div>

          <div className="coupon-middle-section">
            <div className="coupon-scope">
              <GiftOutline fontSize={14} color="#667eea" />
              <span>{coupon.scopeKey || t('coupon.allScope')}</span>
            </div>
            <div className="coupon-expiry">{coupon.expiryKey || t('coupon.validDays', { days: 30 })}</div>
            <div className="coupon-remaining">
              {t('coupon.remaining', { count: coupon.remaining })}
            </div>
          </div>

          <div className="coupon-right-section">
            <Button
              color={isClaimed ? 'default' : 'primary'}
              fill={isClaimed ? 'outline' : 'solid'}
              size="small"
              disabled={isClaimed || coupon.remaining === 0 || isClaiming}
              loading={isClaiming}
              onClick={() => handleClaim(coupon)}
            >
              {isClaimed ? t('coupon.claimed') : coupon.remaining === 0 ? t('coupon.soldOut') : t('coupon.claim')}
            </Button>
          </div>
        </div>
      </Card>
    );
  };

  return (
    <div className="coupon-center-page">
      <NavBar onBack={() => navigate('/coupons')}>
        {t('coupon.center')}
      </NavBar>

      <div className="banner-section">
        <div className="banner-card">
          <div className="banner-content">
            <div className="banner-icon">
              <GiftOutline fontSize={32} color="#FF6B00" />
            </div>
            <div className="banner-text">
              <div className="banner-title">{t('coupon.exclusive')}</div>
              <div className="banner-desc">{t('coupon.claimDesc')}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="coupons-container">
        <div className="section-header">
          <span className="section-title">{t('coupon.allCoupons')}</span>
          <Tag color="primary" fill="outline">
            {t('coupon.availableCount', { count: availableCoupons.length })}
          </Tag>
        </div>

        {availableCoupons.length === 0 ? (
          <Empty description={t('coupon.noAvailable')} />
        ) : (
          <div className="coupons-list">
            {availableCoupons.map(coupon => renderCouponCard(coupon))}
          </div>
        )}
      </div>

      <div className="bottom-tip">
        {t('coupon.claimedTip')}
      </div>
    </div>
  );
};

export default CouponCenterPage;
