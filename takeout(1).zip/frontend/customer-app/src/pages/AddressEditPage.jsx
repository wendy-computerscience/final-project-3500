import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Input,
  Button,
  NavBar,
  TextArea,
  Switch,
  Toast
} from 'antd-mobile';
import useUserStore from '../store/userStore';
import { addressApi } from '../api';
import './AddressEditPage.css';

const AddressEditPage = () => {
  const navigate = useNavigate();
  const { addressId } = useParams();
  const { user } = useUserStore();
  const { t } = useTranslation();
  const isEditMode = Boolean(addressId); // 有 addressId 就是编辑模式

  // 表单数据
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [detail, setDetail] = useState('');
  const [room, setRoom] = useState('');
  const [tag, setTag] = useState('家');
  const [isDefault, setIsDefault] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // 标签选项
  const tags = [
    { label: t('address.tagHome'), value: '家', icon: '🏠' },
    { label: t('address.tagCompany'), value: '公司', icon: '🏢' },
    { label: t('address.tagSchool'), value: '学校', icon: '🏫' }
  ];

  // 加载地址数据
  useEffect(() => {
    const loadAddress = async () => {
      if (!isEditMode || !user?.id) return;

      try {
        setLoading(true);
        const response = await addressApi.getAddressDetail(addressId);

        if (response.success && response.data) {
          const address = response.data;
          setName(address.name);
          setPhone(address.phone);
          setDetail(address.detail);
          setRoom(address.room || '');
          setTag(address.tag || '家');
          setIsDefault(address.isDefault || false);
        } else {
          Toast.show({ icon: 'fail', content: response.message || t('address.loadFailed') });
          navigate('/address');
        }
      } catch (error) {
        console.error('加载地址失败:', error);
        Toast.show({ icon: 'fail', content: t('address.loadFailed') });
        navigate('/address');
      } finally {
        setLoading(false);
      }
    };

    loadAddress();
  }, [isEditMode, addressId, user?.id]);

  // 表单验证
  const validateForm = () => {
    if (!name.trim()) {
      Toast.show({ content: t('address.nameRequired') });
      return false;
    }
    if (!phone.trim() || !/^1\d{10}$/.test(phone)) {
      Toast.show({ content: t('address.phoneInvalid') });
      return false;
    }
    if (!detail.trim()) {
      Toast.show({ content: t('address.detailRequired') });
      return false;
    }
    return true;
  };

  // 提交表单
  const handleSubmit = async () => {
    if (!validateForm()) return;

    try {
      setSubmitting(true);
      const addressData = {
        userId: user.id,
        name: name.trim(),
        phone: phone.trim(),
        region: '',
        detail: detail.trim(),
        room: room.trim(),
        tag,
        isDefault
      };

      const response = isEditMode
        ? await addressApi.updateAddress(addressId, addressData)
        : await addressApi.createAddress(addressData);

      if (response.success) {
        Toast.show({
          icon: 'success',
          content: isEditMode ? t('address.updateSuccess') : t('address.addSuccess')
        });
        navigate('/address');
      } else {
        Toast.show({ icon: 'fail', content: response.message || t('address.saveFailed') });
      }
    } catch (error) {
      console.error('保存地址失败:', error);
      Toast.show({ icon: 'fail', content: t('address.saveFailed') });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="address-edit-page">
      <NavBar onBack={() => navigate('/address')}>
        {isEditMode ? t('address.editTitle') : t('address.addTitle')}
      </NavBar>

      <div className="page-content">
        {/* 收货人信息 */}
        <Card title={t('address.recipientInfo')} className="section-card">
          <div className="input-group">
            <div className="input-label">{t('address.name')}</div>
            <Input
              value={name}
              onChange={setName}
              placeholder={t('address.namePlaceholder')}
              clearable
            />
          </div>
          <div className="input-group">
            <div className="input-label">{t('address.phone')}</div>
            <Input
              value={phone}
              onChange={setPhone}
              placeholder={t('address.phonePlaceholder')}
              type="tel"
              clearable
            />
          </div>
        </Card>

        {/* 地址信息 */}
        <Card title={t('address.addressInfo')} className="section-card">
          <div className="input-group">
            <div className="input-label">{t('address.detail')}</div>
            <TextArea
              value={detail}
              onChange={setDetail}
              placeholder={t('address.detailPlaceholder')}
              rows={3}
              maxLength={100}
              showCount
            />
          </div>

          <div className="input-group">
            <div className="input-label">{t('address.room')}</div>
            <Input
              value={room}
              onChange={setRoom}
              placeholder={t('address.roomPlaceholder')}
              clearable
            />
          </div>
        </Card>

        {/* 标签和设置 */}
        <Card title={t('address.tagSettings')} className="section-card">
          <div className="tag-selector">
            {tags.map(item => (
              <div
                key={item.value}
                className={`tag-item ${tag === item.value ? 'active' : ''}`}
                onClick={() => setTag(item.value)}
              >
                <span className="tag-icon">{item.icon}</span>
                <span className="tag-label">{item.label}</span>
              </div>
            ))}
          </div>

          <div className="switch-item">
            <span>{t('address.setDefaultLabel')}</span>
            <Switch checked={isDefault} onChange={setIsDefault} />
          </div>
        </Card>

        {/* 保存按钮 */}
        <div className="submit-section">
          <Button
            block
            color="primary"
            size="large"
            onClick={handleSubmit}
            loading={submitting}
            disabled={submitting || loading}
          >
            {submitting ? t('address.saving') : t('address.save')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AddressEditPage;
