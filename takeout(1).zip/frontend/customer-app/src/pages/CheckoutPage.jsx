import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  NavBar,
  Card,
  List,
  Button,
  TextArea,
  Dialog,
  Toast,
  Divider
} from 'antd-mobile';
import {
  LocationFill
} from 'antd-mobile-icons';
import useCartStore from '../store/cartStore';
import useAddressStore from '../store/addressStore';
import useUserStore from '../store/userStore';
import { orderApi } from '../api';
import './CheckoutPage.css';

function CheckoutPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();

  const { carts, clearCart, setUserId } = useCartStore();
  const { addresses, loadAddresses } = useAddressStore();
  const { user } = useUserStore();

  const [selectedAddress, setSelectedAddress] = useState(null);
  const [remark, setRemark] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // 用于跟踪上一次的 location.key，避免重复应用选中的地址
  const lastLocationKey = useRef(null);
  // 用于跟踪是否是因为提交订单而清空购物车
  const isOrderSubmitted = useRef(false);

  // 从 location.state 获取餐厅信息
  const restaurantInfo = location.state?.restaurant;

  // 获取当前餐厅的购物车
  const cart = restaurantInfo
    ? carts.find(c => c.restaurantId === String(restaurantInfo.id))
    : (carts.length > 0 ? carts[0] : null);

  // 使用传入的餐厅信息或购物车中的餐厅信息
  const restaurant = restaurantInfo || (cart ? {
    id: cart.restaurantId,
    name: cart.restaurantName,
    ...cart.restaurant
  } : null);

  // 设置用户ID
  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
    }
  }, [user, setUserId]);

  useEffect(() => {
    // 检查购物车是否为空
    // 如果是因为提交订单而清空的购物车，不显示提示
    if (!cart || !cart.items || cart.items.length === 0) {
      if (!isOrderSubmitted.current) {
        Toast.show(t('checkout.cartEmpty'));
        navigate(-1);
      }
      return;
    }

    // 加载地址列表
    loadAddresses(user.id);
  }, [cart]);

  // 单独处理从地址选择页面返回的情况
  useEffect(() => {
    // 检查是否是新的导航（通过 location.key 判断）
    if (location.key && location.key !== lastLocationKey.current) {
      lastLocationKey.current = location.key;

      // 如果有选中的地址，应用它
      if (location.state?.selectedAddress) {
        setSelectedAddress(location.state.selectedAddress);
      }
    }
  }, [location.key, location.state?.selectedAddress]);

  useEffect(() => {
    // 只在没有选中地址，且不是从地址选择页面返回时，才设置默认地址
    if (addresses.length > 0 && !selectedAddress && !location.state?.selectedAddress) {
      const defaultAddr = addresses.find(addr => addr.isDefault) || addresses[0];
      setSelectedAddress(defaultAddr);
    }
  }, [addresses, selectedAddress]);

  // 计算商品小计
  const calculateSubtotal = () => {
    if (!cart || !cart.items) return 0;
    return cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  // 固定配送费
  const deliveryFee = 3;

  // 计算总金额
  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    return subtotal + deliveryFee;
  };

  // 选择地址
  const handleSelectAddress = () => {
    if (addresses.length === 0) {
      // 没有地址，跳转到新建地址页面
      navigate('/address/new', { state: { returnTo: '/checkout', restaurant: restaurantInfo } });
    } else {
      // 有地址，跳转到地址选择页面
      navigate('/address/select', {
        state: {
          returnTo: '/checkout',
          currentAddressId: selectedAddress?.id,
          restaurant: restaurantInfo
        }
      });
    }
  };

  // 提交订单
  const handleSubmit = async () => {
    // 验证地址
    if (!selectedAddress) {
      Toast.show(t('checkout.selectAddress'));
      return;
    }

    // 验证起送金额
    const subtotal = calculateSubtotal();
    const minOrder = restaurant?.minOrder || 0;
    if (subtotal < minOrder) {
      Toast.show(t('checkout.minOrderGap', { amount: (minOrder - subtotal).toFixed(2) }));
      return;
    }

    // 确认订单
    const result = await Dialog.confirm({
      content: t('checkout.confirmOrder', { amount: calculateTotal().toFixed(2) }),
    });

    if (!result) return;

    setSubmitting(true);

    try {
      // 构建订单数据
      const orderData = {
        userId: user.id,
        restaurantId: cart.restaurantId,
        items: cart.items.map(item => ({
          foodId: item.id,
          quantity: item.quantity,
          price: item.price,
          name: item.name,
        })),
        deliveryAddress: {
          name: selectedAddress.name,
          phone: selectedAddress.phone,
          detail: selectedAddress.detail,
          room: selectedAddress.room,
          latitude: selectedAddress.latitude,
          longitude: selectedAddress.longitude,
        },
        remark: remark.trim(),
        subtotal: calculateSubtotal(),
        deliveryFee: deliveryFee,
        totalAmount: calculateTotal(),
      };

      const response = await orderApi.createOrder(orderData);

      if (response.success) {
        Toast.show({
          icon: 'success',
          content: t('checkout.orderSuccess'),
        });

        // 标记为订单提交，避免购物车清空提示
        isOrderSubmitted.current = true;

        // 清空购物车
        clearCart();

        // 跳转到支付页面或订单详情
        navigate(`/orders`, { replace: true });
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('checkout.orderFailed'),
        });
      }
    } catch (error) {
      console.error('提交订单失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('checkout.networkError'),
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (!cart || cart.items.length === 0) {
    return null;
  }

  const subtotal = calculateSubtotal();
  const total = calculateTotal();

  return (
    <div className="checkout-page">
      <NavBar onBack={() => navigate(-1)}>{t('checkout.title')}</NavBar>

      {/* 配送地址 */}
      <Card className="checkout-section address-section">
        <List>
          <List.Item
            prefix={<LocationFill fontSize={20} color="#1677FF" />}
            onClick={handleSelectAddress}
            clickable
          >
            {selectedAddress ? (
              <div className="selected-address">
                <div className="address-header">
                  <span className="address-name">{selectedAddress.name}</span>
                  <span className="address-phone">{selectedAddress.phone}</span>
                </div>
                <div className="address-detail">
                  {selectedAddress.detail} {selectedAddress.room}
                </div>
              </div>
            ) : (
              <div className="no-address">{t('checkout.selectAddress')}</div>
            )}
          </List.Item>
        </List>
      </Card>

      {/* 餐厅信息 */}
      {restaurant && (
        <Card className="checkout-section restaurant-section">
          <div className="restaurant-info">
            <div className="restaurant-name">{restaurant.name}</div>
          </div>
        </Card>
      )}

      {/* 订单商品 */}
      <Card className="checkout-section items-section">
        <div className="section-title">{t('checkout.orderItems')}</div>
        <div className="items-list">
          {cart.items.map(item => (
            <div key={item.id} className="item-row">
              <div className="item-name">{item.name}</div>
              <div className="item-right">
                <span className="item-quantity">x{item.quantity}</span>
                <span className="item-amount">${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* 备注 */}
      <Card className="checkout-section remark-section">
        <div className="section-title">{t('checkout.remark')}</div>
        <TextArea
          placeholder={t('checkout.remarkPlaceholder')}
          value={remark}
          onChange={setRemark}
          maxLength={100}
          showCount
          rows={3}
        />
      </Card>

      {/* 金额明细 */}
      <Card className="checkout-section amount-section">
        <div className="amount-row">
          <span>{t('checkout.subtotal')}</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>
        <div className="amount-row">
          <span>{t('checkout.deliveryFee')}</span>
          <span>${deliveryFee.toFixed(2)}</span>
        </div>
        <Divider />
        <div className="amount-row total-row">
          <span className="total-label">{t('checkout.actualPayment')}</span>
          <span className="total-amount">${total.toFixed(2)}</span>
        </div>
      </Card>

      {/* 底部提交按钮 */}
      <div className="checkout-footer">
        <div className="footer-amount">
          <div className="footer-label">{t('checkout.actualPay')}</div>
          <div className="footer-total">${total.toFixed(2)}</div>
        </div>
        <Button
          color="primary"
          size="large"
          onClick={handleSubmit}
          loading={submitting}
          disabled={submitting}
          className="submit-btn"
        >
          {submitting ? t('checkout.submitting') : t('checkout.submit')}
        </Button>
      </div>
    </div>
  );
}

export default CheckoutPage;
