import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  List,
  Card,
  Button,
  Tag,
  Dialog,
  Toast,
  Empty,
  NavBar
} from 'antd-mobile';
import {
  AddOutline,
  LocationFill,
  PhoneFill,
  EditSOutline,
  DeleteOutline
} from 'antd-mobile-icons';
import useUserStore from '../store/userStore';
import { addressApi } from '../api';
import './AddressManagePage.css';

const AddressManagePage = () => {
  const navigate = useNavigate();
  const { user } = useUserStore();
  const { t } = useTranslation();
  const [addresses, setAddresses] = useState([]);
  const [loading, setLoading] = useState(true);

  // 加载地址列表
  const loadAddresses = async () => {
    try {
      setLoading(true);
      const response = await addressApi.getAddressList(user.id);

      if (response.success && response.data) {
        setAddresses(response.data);
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('address.loadFailed'),
        });
      }
    } catch (error) {
      console.error('加载地址失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('address.loadFailed'),
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      loadAddresses();
    }
  }, [user?.id]);

  // 删除地址
  const handleDelete = async (addressId) => {
    const result = await Dialog.confirm({
      content: t('address.deleteConfirm'),
    });

    if (result) {
      try {
        const response = await addressApi.deleteAddress(addressId);

        if (response.success) {
          Toast.show({ icon: 'success', content: t('address.deleteSuccess') });
          // 重新加载地址列表
          loadAddresses();
        } else {
          Toast.show({
            icon: 'fail',
            content: response.message || t('address.deleteFailed'),
          });
        }
      } catch (error) {
        console.error('删除地址失败:', error);
        Toast.show({
          icon: 'fail',
          content: error.message || t('address.deleteFailed'),
        });
      }
    }
  };

  // 设置默认地址
  const handleSetDefault = async (addressId) => {
    try {
      const response = await addressApi.setDefaultAddress(addressId, user.id);

      if (response.success) {
        Toast.show({ icon: 'success', content: t('address.setDefaultSuccess') });
        // 重新加载地址列表
        loadAddresses();
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('address.setDefaultFailed'),
        });
      }
    } catch (error) {
      console.error('设置默认地址失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('address.setDefaultFailed'),
      });
    }
  };

  // 编辑地址
  const handleEdit = (addressId) => {
    navigate(`/address/edit/${addressId}`);
  };

  // 新增地址
  const handleAdd = () => {
    navigate('/address/new');
  };

  const renderAddressCard = (address) => {
    const tagColor = {
      '家': 'primary',
      '公司': 'success',
      '学校': 'warning'
    };

    return (
      <Card key={address.id} className="address-card">
        <div className="address-header">
          <div className="address-info">
            <span className="address-name">{address.name}</span>
            <span className="address-phone">
              <PhoneFill fontSize={12} /> {address.phone}
            </span>
          </div>
          <div className="address-tags">
            {address.isDefault && (
              <Tag color="danger" fill="outline" style={{ marginRight: 8 }}>
                {t('address.default')}
              </Tag>
            )}
            <Tag color={tagColor[address.tag] || 'default'}>
              {address.tag}
            </Tag>
          </div>
        </div>

        <div className="address-detail">
          <LocationFill color="#1677FF" fontSize={16} />
          <span className="detail-text">
            {address.detail} {address.room}
          </span>
        </div>

        <div className="address-actions">
          {!address.isDefault && (
            <Button
              size="small"
              fill="outline"
              onClick={() => handleSetDefault(address.id)}
            >
              {t('address.setDefault')}
            </Button>
          )}
          <Button
            size="small"
            fill="outline"
            color="primary"
            onClick={() => handleEdit(address.id)}
          >
            <EditSOutline /> {t('address.edit')}
          </Button>
          <Button
            size="small"
            fill="outline"
            color="danger"
            onClick={() => handleDelete(address.id)}
          >
            <DeleteOutline /> {t('address.delete')}
          </Button>
        </div>
      </Card>
    );
  };

  return (
    <div className="address-manage-page">
      <NavBar onBack={() => navigate(-1)}>
        {t('address.title')}
      </NavBar>

      <div className="addresses-container">
        {addresses.length === 0 ? (
          <Empty
            description={t('address.noAddress')}
            imageStyle={{ width: 128 }}
          />
        ) : (
          <div className="addresses-list">
            {addresses.map(address => renderAddressCard(address))}
          </div>
        )}
      </div>

      {/* 添加地址按钮 */}
      <div className="add-button-container">
        <Button
          block
          color="primary"
          size="large"
          onClick={handleAdd}
        >
          <AddOutline /> {t('address.addNew')}
        </Button>
      </div>
    </div>
  );
};

export default AddressManagePage;
