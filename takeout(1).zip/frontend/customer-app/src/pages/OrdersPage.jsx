import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Tabs,
  Card,
  Button,
  Tag,
  Empty,
  PullToRefresh,
  Skeleton,
  Toast,
  NavBar
} from 'antd-mobile';
import {
  ClockCircleOutline,
  TruckOutline,
  CheckCircleOutline,
  ShopbagOutline
} from 'antd-mobile-icons';
import useUserStore from '../store/userStore';
import { orderApi } from '../api';
import './OrdersPage.css';

const OrdersPage = () => {
  const navigate = useNavigate();
  const { user } = useUserStore();
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('all');
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  // 订单状态配置
  const statusConfig = {
    pending_payment: { label: t('orders.status.pendingPayment'), color: 'warning', icon: <ClockCircleOutline /> },
    paid: { label: t('orders.status.paid'), color: 'primary', icon: <ClockCircleOutline /> },
    pending_accept: { label: t('orders.status.pendingAccept'), color: 'primary', icon: <ClockCircleOutline /> },
    preparing: { label: t('orders.status.preparing'), color: 'primary', icon: <ShopbagOutline /> },
    ready: { label: t('orders.status.ready'), color: 'primary', icon: <ShopbagOutline /> },
    pending_pickup: { label: t('orders.status.pendingPickup'), color: 'primary', icon: <TruckOutline /> },
    delivering: { label: t('orders.status.delivering'), color: 'primary', icon: <TruckOutline /> },
    completed: { label: t('orders.status.completed'), color: 'success', icon: <CheckCircleOutline /> },
    cancelled: { label: t('orders.status.cancelled'), color: 'default', icon: <ClockCircleOutline /> }
  };

  // 加载订单数据
  const loadOrders = async () => {
    try {
      setLoading(true);

      // 开发环境：如果 user.id 为空，使用默认测试用户 ID
      const userId = user?.id || (process.env.NODE_ENV === 'development' ? 1 : null);

      if (!userId) {
        setLoading(false);
        return;
      }

      // 调用真实API
      const statusFilter = activeTab === 'all' ? null : activeTab;
      const response = await orderApi.getUserOrders(userId, statusFilter, 1, 20);

      if (response.success && response.data) {
        // 转换数据格式以匹配前端组件
        const formattedOrders = response.data.orders.map(order => ({
          id: order.id,
          restaurantName: order.restaurant_name || t('orders.unknownRestaurant'),
          items: [], // TODO: 从订单明细表获取
          totalAmount: parseFloat(order.total_amount || 0),
          status: order.status,
          createTime: order.created_at,
          itemCount: 0, // TODO: 从订单明细计算
        }));

        setOrders(formattedOrders);
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('orders.loadFailed'),
        });
      }
    } catch (error) {
      console.error('加载订单失败:', error);
      Toast.show({
        icon: 'fail',
        content: error.message || t('orders.loadFailed'),
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // 开发环境：如果 user.id 为空，使用默认测试用户 ID
    const userId = user?.id || (process.env.NODE_ENV === 'development' ? 1 : null);

    if (userId) {
      loadOrders();
    } else {
      // 生产环境且未登录，显示空状态
      setLoading(false);
    }
  }, [activeTab, user?.id]);

  // 下拉刷新
  const onRefresh = async () => {
    await loadOrders();
  };

  // 过滤订单
  const getFilteredOrders = () => {
    if (activeTab === 'all') return orders;
    return orders.filter(order => order.status === activeTab);
  };

  // 格式化时间
  const formatTime = (timeStr) => {
    const date = new Date(timeStr);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    const timeFormatted = date.toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit'
    });

    if (days === 0) return t('orders.today') + ' ' + timeFormatted;
    if (days === 1) return t('orders.yesterday') + ' ' + timeFormatted;

    return date.toLocaleDateString('zh-CN', {
      month: '2-digit',
      day: '2-digit'
    }) + ' ' + timeFormatted;
  };

  // 点击订单卡片
  const handleOrderClick = (order) => {
    // 根据订单状态跳转到不同页面
    switch (order.status) {
      case 'pending_payment':
        // 待支付 -> 支付页面
        navigate(`/payment/${order.id}`);
        break;
      case 'pending_pickup':
      case 'delivering':
        // 配送相关状态 -> 追踪页面
        navigate(`/tracking/${order.id}`);
        break;
      default:
        // 其他状态 -> 订单详情页（暂用追踪页面代替）
        navigate(`/order/${order.id}`);
        break;
    }
  };

  // 快捷操作
  const handleOrderAction = async (order, action) => {
    switch (action) {
      case 'pay':
        navigate(`/payment/${order.id}`);
        break;
      case 'track':
        navigate(`/tracking/${order.id}`);
        break;
      case 'reorder':
        try {
          const response = await orderApi.reorderOrder(order.id);
          if (response.success) {
            Toast.show({
              icon: 'success',
              content: t('orders.reorderSuccess')
            });
            navigate('/cart');
          } else {
            Toast.show({
              icon: 'fail',
              content: response.message || '再来一单失败'
            });
          }
        } catch (error) {
          console.error('再来一单失败:', error);
          Toast.show({
            icon: 'fail',
            content: '再来一单失败'
          });
        }
        break;
      case 'refund':
        Toast.show({ content: t('orders.refundInDevelopment') });
        break;
      default:
        break;
    }
  };

  // 渲染订单卡片
  const renderOrderCard = (order) => {
    const config = statusConfig[order.status] || {
      label: order.status,
      color: 'default',
      icon: <ClockCircleOutline />
    };

    return (
      <Card
        key={order.id}
        className="order-card"
        onClick={() => handleOrderClick(order)}
      >
        {/* 订单头部 */}
        <div className="order-header">
          <div className="restaurant-info">
            <ShopbagOutline fontSize={16} />
            <span className="restaurant-name">{order.restaurantName}</span>
          </div>
          <Tag color={config.color} fill="outline">
            {config.label}
          </Tag>
        </div>

        {/* 订单商品 */}
        <div className="order-items">
          <div className="items-text">
            {order.items.join('、')}
            {order.itemCount > 2 && t('orders.moreItems', { count: order.itemCount })}
          </div>
        </div>

        {/* 订单底部 */}
        <div className="order-footer">
          <div className="order-info">
            <div className="order-time">{formatTime(order.createTime)}</div>
            <div className="order-amount">
              <span className="amount-label">{t('orders.paidAmount')}</span>
              <span className="amount-symbol">$</span>
              <span className="amount-value">{order.totalAmount.toFixed(2)}</span>
            </div>
          </div>

          {/* 操作按钮 */}
          <div className="order-actions" onClick={(e) => e.stopPropagation()}>
            {order.status === 'pending_payment' && (
              <Button
                size="small"
                color="primary"
                onClick={() => handleOrderAction(order, 'pay')}
              >
                {t('orders.toPay')}
              </Button>
            )}
            {(order.status === 'preparing' || order.status === 'delivering' || order.status === 'pending_pickup') && (
              <Button
                size="small"
                fill="outline"
                onClick={() => handleOrderAction(order, 'track')}
              >
                {t('orders.viewProgress')}
              </Button>
            )}
            {order.status === 'completed' && (
              <>
                <Button
                  size="small"
                  fill="outline"
                  onClick={() => handleOrderAction(order, 'reorder')}
                >
                  {t('orders.reorder')}
                </Button>
              </>
            )}
          </div>
        </div>
      </Card>
    );
  };

  const filteredOrders = getFilteredOrders();

  return (
    <div className="orders-page">
      {/* 顶部导航栏 */}
      <NavBar back={null} style={{ '--border-bottom': '1px solid #f0f0f0' }}>
        {t('orders.title')}
      </NavBar>

      {/* 订单状态标签 */}
      <div className="tabs-wrapper">
        <Tabs
          activeKey={activeTab}
          onChange={setActiveTab}
          style={{
            '--active-line-color': '#667eea',
            '--active-line-height': '3px'
          }}
        >
          <Tabs.Tab title={t('orders.all')} key="all" />
          <Tabs.Tab title={t('orders.pending')} key="pending" />
          <Tabs.Tab title={t('orders.delivering')} key="delivering" />
          <Tabs.Tab title={t('orders.completed')} key="completed" />
        </Tabs>
      </div>

      {/* 订单列表 */}
      <div className="orders-content">
        <PullToRefresh onRefresh={onRefresh}>
          {loading ? (
            <div className="loading-skeleton">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="order-card">
                  <Skeleton.Title animated />
                  <Skeleton.Paragraph lineCount={2} animated />
                </Card>
              ))}
            </div>
          ) : filteredOrders.length > 0 ? (
            <div className="orders-list">
              {filteredOrders.map(renderOrderCard)}
            </div>
          ) : (
            <div className="empty-wrapper">
              <Empty
                description={
                  activeTab === 'all' ? t('orders.empty') : t('orders.emptyStatus', { status: statusConfig[activeTab]?.label || '' })
                }
              />
            </div>
          )}
        </PullToRefresh>
      </div>
    </div>
  );
};

export default OrdersPage;
