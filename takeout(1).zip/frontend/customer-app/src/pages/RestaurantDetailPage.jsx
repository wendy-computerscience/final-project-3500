import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { NavBar, Card, Tag, Badge, Button, Stepper, Toast, FloatingBubble, Popup, Grid } from 'antd-mobile';
import {
  ShopbagOutline,
  StarFill,
  LocationFill,
  ClockCircleFill,
  FireFill,
  LikeOutline
} from 'antd-mobile-icons';
import axios from 'axios';
import useCartStore from '../store/cartStore';
import useUserStore from '../store/userStore';
import './RestaurantDetailPage.css';

const API_BASE_URL = 'http://localhost:3001';

function RestaurantDetailPage() {
  const { restaurantId } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const { user } = useUserStore();

  const [restaurant, setRestaurant] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [cartVisible, setCartVisible] = useState(false);
  const [suggestions, setSuggestions] = useState(null);
  const [loading, setLoading] = useState(true);

  // 使用购物车 store
  const {
    cart,
    initCart,
    addItem,
    removeItem,
    updateItemQuantity,
    clearCart,
    getItemQuantity,
    getTotalAmount,
    getTotalQuantity,
    isMinOrderMet,
    getMinOrderGap,
    setUserId,
  } = useCartStore();

  // 设置用户ID到购物车store
  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
    }
  }, [user, setUserId]);

  // 加载餐厅和菜品数据
  useEffect(() => {
    loadRestaurantData();
  }, [restaurantId]);

  // 当购物车变化时，获取凑单建议
  useEffect(() => {
    if (restaurant && Object.keys(cart).length > 0) {
      loadSuggestions();
    } else {
      setSuggestions(null);
    }
  }, [cart, restaurant]);

  const loadRestaurantData = async () => {
    try {
      setLoading(true);

      // 从API加载餐厅和菜品数据
      const [restaurantRes, menuRes] = await Promise.all([
        axios.get(`${API_BASE_URL}/api/restaurants/${restaurantId}`),
        axios.get(`${API_BASE_URL}/api/restaurants/${restaurantId}/menu`)
      ]);

      if (!restaurantRes.data.success) {
        Toast.show(t('restaurant.notFound'));
        navigate('/');
        return;
      }

      const restaurantData = restaurantRes.data.data;
      setRestaurant(restaurantData);
      setMenuItems(menuRes.data.data);

      // 初始化购物车
      initCart(restaurantId, restaurantData.name, {
        lat: restaurantData.lat,
        lng: restaurantData.lng,
        minOrder: restaurantData.minOrder,
        deliveryFee: restaurantData.deliveryFee,
        avgPrepMin: restaurantData.avgPrepMin,
        merchantId: restaurantData.merchantId || restaurantId,
      });

    } catch (error) {
      console.error('加载餐厅数据失败:', error);
      Toast.show(t('restaurant.loadFailed'));
    } finally {
      setLoading(false);
    }
  };

  const loadSuggestions = async () => {
    try {
      const currentAmount = getTotalAmount();
      const cartItemIds = cart?.items.map(item => item.id).join(',') || '';

      const response = await axios.get(
        `${API_BASE_URL}/api/suggestion/${restaurantId}`,
        {
          params: {
            currentAmount,
            cartItems: cartItemIds
          }
        }
      );

      if (response.data.success) {
        setSuggestions(response.data.data);
      }
    } catch (error) {
      console.error('获取凑单建议失败:', error);
    }
  };

  // 结算
  const checkout = () => {
    if (!isMinOrderMet()) {
      const gap = getMinOrderGap();
      Toast.show(t('restaurant.minOrderGap', { amount: gap.toFixed(2) }));
      return;
    }

    // 导航到结算页，传递餐厅信息
    navigate('/checkout', {
      state: {
        restaurant: {
          id: restaurantId,
          name: restaurant.name,
          minOrder: restaurant.minOrder,
          deliveryFee: restaurant.deliveryFee,
          avgPrepMin: restaurant.avgPrepMin,
        }
      }
    });
  };

  // 添加推荐菜品到购物车
  const addSuggestionToCart = (item) => {
    // 构建餐厅信息
    const restaurantInfo = {
      id: restaurantId,
      lat: restaurantData.lat,
      lng: restaurantData.lng,
      minOrder: restaurantData.minOrder,
      deliveryFee: restaurantData.deliveryFee,
      avgPrepMin: restaurantData.avgPrepMin,
      merchantId: restaurantData.merchantId || restaurantId
    };

    addItem(item, restaurantInfo);
    Toast.show({
      content: t('restaurant.addedToCart'),
      duration: 1000
    });
  };

  if (loading) {
    return <div className="restaurant-loading">{t('restaurant.loading')}</div>;
  }

  if (!restaurant) {
    return null;
  }

  const totalAmount = getTotalAmount();
  const totalQuantity = getTotalQuantity();
  const canCheckout = isMinOrderMet();

  return (
    <div className="restaurant-detail-page">
      <NavBar onBack={() => navigate(-1)}>{t('restaurant.detail')}</NavBar>

      {/* 餐厅信息 */}
      <Card className="restaurant-info-card">
        <div className="restaurant-header">
          <div className="restaurant-name-wrapper">
            <h2 className="restaurant-name">{restaurant.name}</h2>
            <div className="restaurant-rating">
              <StarFill color="#ff6b00" />
              <span>{restaurant.rating}</span>
            </div>
          </div>

          <div className="restaurant-tags">
            {restaurant.cuisine?.map((c, i) => (
              <Tag key={i} color="primary" fill="outline" style={{ marginRight: 4 }}>
                {c}
              </Tag>
            ))}
          </div>

          <div className="restaurant-meta">
            <span className="meta-item">
              <LocationFill fontSize={14} />
              {restaurant.address}
            </span>
            <span className="meta-item">
              <ClockCircleFill fontSize={14} />
              {t('restaurant.estimatedTime', { minutes: restaurant.avgPrepMin })}
            </span>
          </div>

          <div className="restaurant-delivery-info">
            <span>{t('restaurant.minOrder', { amount: restaurant.minOrder })}</span>
            <span className="divider">|</span>
            <span>{t('restaurant.deliveryFee', { amount: restaurant.deliveryFee })}</span>
            <span className="divider">|</span>
            <span className="on-time-rate">{t('restaurant.onTimeRate', { rate: (restaurant.onTimeRate * 100).toFixed(0) })}</span>
          </div>
        </div>
      </Card>

      {/* 凑单建议 */}
      {suggestions?.needSuggestion && suggestions.suggestions.length > 0 && (
        <div className="suggestion-card">
          <div className="suggestion-header">
            <FireFill color="#ff6b00" />
            <span className="suggestion-title">{t('restaurant.suggestion')}</span>
            <Tag color="warning" fill="outline" className="suggestion-gap-tag">
              {t('restaurant.stillNeed', { amount: suggestions.gap.toFixed(2) })}
            </Tag>
          </div>

          <div className="suggestion-list">
            {suggestions.suggestions.map(item => (
              <div key={item.id} className="suggestion-item">
                <div className="suggestion-item-info">
                  <div className="suggestion-item-name">{item.name}</div>
                  <div className="suggestion-item-reasons">
                    {item.reasons.map((reason, i) => (
                      <Tag key={i} color="success" fill="outline" style={{ marginRight: 4, fontSize: 11 }}>
                        {reason}
                      </Tag>
                    ))}
                  </div>
                  <div className="suggestion-item-price">
                    ${item.price}
                    {item.willReachMinOrder && (
                      <Tag color="success" style={{ marginLeft: 8, fontSize: 11 }}>
                        {t('restaurant.canDeliver')}
                      </Tag>
                    )}
                  </div>
                </div>
                <Button
                  size="small"
                  color="primary"
                  onClick={() => addSuggestionToCart(item)}
                >
                  {t('restaurant.add')}
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 菜品列表 */}
      <div className="menu-list">
        <div className="menu-header">
          <h3>{t('restaurant.menu')}</h3>
        </div>

        {menuItems.map(item => (
          <Card key={item.id} className="menu-item-card">
            <div className="menu-item">
              <div className="menu-item-info">
                <div className="menu-item-name">{item.name}</div>
                <div className="menu-item-desc">{item.description}</div>
                <div className="menu-item-meta">
                  <Tag color="default" fill="outline" style={{ fontSize: 11 }}>
                    {t('restaurant.monthlySales', { count: item.monthSales })}
                  </Tag>
                  <span className="menu-item-rating">
                    <LikeOutline fontSize={12} />
                    {item.rating}
                  </span>
                </div>
                <div className="menu-item-price">${item.price}</div>
              </div>

              <div className="menu-item-action">
                {getItemQuantity(item.id) > 0 ? (
                  <Stepper
                    value={getItemQuantity(item.id)}
                    onChange={(value) => {
                      if (value > getItemQuantity(item.id)) {
                        // 构建餐厅信息
                        const restaurantInfo = {
                          id: restaurantId,
                          lat: restaurantData.lat,
                          lng: restaurantData.lng,
                          minOrder: restaurantData.minOrder,
                          deliveryFee: restaurantData.deliveryFee,
                          avgPrepMin: restaurantData.avgPrepMin,
                          merchantId: restaurantData.merchantId || restaurantId
                        };
                        addItem(item, restaurantInfo);
                      } else {
                        removeItem(item.id);
                      }
                    }}
                    min={0}
                  />
                ) : (
                  <Button
                    size="small"
                    color="primary"
                    onClick={() => {
                      // 构建餐厅信息
                      const restaurantInfo = {
                        id: restaurantId,
                        lat: restaurantData.lat,
                        lng: restaurantData.lng,
                        minOrder: restaurantData.minOrder,
                        deliveryFee: restaurantData.deliveryFee,
                        avgPrepMin: restaurantData.avgPrepMin,
                        merchantId: restaurantData.merchantId || restaurantId
                      };
                      addItem(item, restaurantInfo);
                    }}
                  >
                    {t('restaurant.add')}
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* 购物车浮窗 */}
      {totalQuantity > 0 && (
        <>
          <FloatingBubble
            style={{
              '--initial-position-bottom': '100px',
              '--initial-position-right': '24px',
              '--edge-distance': '24px',
            }}
            onClick={() => setCartVisible(true)}
          >
            <Badge content={totalQuantity}>
              <ShopbagOutline fontSize={32} />
            </Badge>
          </FloatingBubble>

          {/* 底部购物车栏 */}
          <div className="cart-bar">
            <div className="cart-bar-left" onClick={() => setCartVisible(true)}>
              <Badge content={totalQuantity} className="cart-badge">
                <ShopbagOutline fontSize={24} />
              </Badge>
              <div className="cart-amount">
                <div className="cart-total">${totalAmount.toFixed(2)}</div>
                {!canCheckout && (
                  <div className="cart-tip">{t('restaurant.stillNeed', { amount: getMinOrderGap().toFixed(2) })}</div>
                )}
              </div>
            </div>

            <Button
              color={canCheckout ? 'primary' : 'default'}
              disabled={!canCheckout}
              onClick={checkout}
              className="checkout-btn"
            >
              {canCheckout ? t('restaurant.checkout') : t('restaurant.stillNeed', { amount: getMinOrderGap().toFixed(2) })}
            </Button>
          </div>
        </>
      )}

      {/* 购物车抽屉 */}
      <Popup
        visible={cartVisible}
        onMaskClick={() => setCartVisible(false)}
        bodyStyle={{ height: '50vh' }}
        position="bottom"
      >
        <div className="cart-popup">
          <div className="cart-popup-header">
            <h3>{t('restaurant.cart')}</h3>
            <Button size="small" fill="none" onClick={clearCart}>
              {t('restaurant.clear')}
            </Button>
          </div>

          <div className="cart-popup-list">
            {cart?.items.map(item => (
              <div key={item.id} className="cart-popup-item">
                <div className="cart-popup-item-info">
                  <div className="cart-popup-item-name">{item.name}</div>
                  <div className="cart-popup-item-price">${item.price}</div>
                </div>
                <Stepper
                  value={item.quantity}
                  onChange={(value) => {
                    updateItemQuantity(item.id, value);
                  }}
                  min={0}
                />
              </div>
            ))}
          </div>
        </div>
      </Popup>
    </div>
  );
}

export default RestaurantDetailPage;
