import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  NavBar,
  Card,
  List,
  Button,
  Tag,
  Steps,
  Divider,
  Loading,
  Toast
} from 'antd-mobile';
import {
  ClockCircleOutline,
  EnvironmentOutline,
  PhoneFill
} from 'antd-mobile-icons';
import { orderApi } from '../api';
import './OrderDetailPage.css';

const OrderDetailPage = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  // 加载订单详情
  useEffect(() => {
    const loadOrderDetail = async () => {
      try {
        setLoading(true);
        const response = await orderApi.getOrderDetail(orderId);

        if (response.success && response.data) {
          setOrder(response.data);
        } else {
          Toast.show({
            icon: 'fail',
            content: response.message || t('orderDetail.loadFailed')
          });
          navigate(-1);
        }
      } catch (error) {
        console.error('加载订单详情失败:', error);
        Toast.show({
          icon: 'fail',
          content: t('orderDetail.loadFailed')
        });
        navigate(-1);
      } finally {
        setLoading(false);
      }
    };

    if (orderId) {
      loadOrderDetail();
    }
  }, [orderId]);

  // 获取状态标签颜色
  const getStatusColor = (status) => {
    const colorMap = {
      pending_payment: 'warning',
      paid: 'primary',
      preparing: 'primary',
      ready: 'success',
      delivering: 'primary',
      completed: 'success',
      cancelled: 'danger'
    };
    return colorMap[status] || 'default';
  };

  // 获取状态文本
  const getStatusText = (status) => {
    return t(`orderDetail.status.${status}`) || status;
  };

  // 获取订单步骤
  const getOrderSteps = () => {
    if (!order) return [];

    const allSteps = [
      { key: 'pending_payment', title: t('orderDetail.steps.pendingPayment') },
      { key: 'paid', title: t('orderDetail.steps.paid') },
      { key: 'preparing', title: t('orderDetail.steps.preparing') },
      { key: 'ready', title: t('orderDetail.steps.ready') },
      { key: 'delivering', title: t('orderDetail.steps.delivering') },
      { key: 'completed', title: t('orderDetail.steps.completed') }
    ];

    const statusIndex = allSteps.findIndex(step => step.key === order.status);
    return allSteps.slice(0, statusIndex + 1);
  };

  // 查看配送进度
  const handleTrackDelivery = () => {
    navigate(`/tracking/${orderId}`);
  };

  // 联系商家
  const handleContactMerchant = () => {
    Toast.show(t('orderDetail.contactMerchant'));
  };

  // 再来一单
  const handleReorder = async () => {
    try {
      const response = await orderApi.reorderOrder(orderId);
      if (response.success) {
        Toast.show({
          icon: 'success',
          content: t('orderDetail.reorderSuccess')
        });
        navigate('/cart');
      } else {
        Toast.show({
          icon: 'fail',
          content: response.message || t('orderDetail.reorderFailed')
        });
      }
    } catch (error) {
      console.error('再来一单失败:', error);
      Toast.show({
        icon: 'fail',
        content: t('orderDetail.reorderFailed')
      });
    }
  };

  if (loading) {
    return (
      <div className="order-detail-page">
        <NavBar onBack={() => navigate(-1)}>{t('orderDetail.title')}</NavBar>
        <div style={{ padding: '100px 0', textAlign: 'center' }}>
          <Loading color="primary" />
        </div>
      </div>
    );
  }

  if (!order) {
    return null;
  }

  return (
    <div className="order-detail-page">
      <NavBar onBack={() => navigate(-1)}>{t('orderDetail.title')}</NavBar>

      {/* 订单状态 */}
      <Card className="status-card">
        <div className="status-header">
          <Tag color={getStatusColor(order.status)} fill="solid">
            {getStatusText(order.status)}
          </Tag>
          {order.status === 'delivering' && (
            <Button size="small" color="primary" fill="outline" onClick={handleTrackDelivery}>
              {t('orderDetail.trackDelivery')}
            </Button>
          )}
        </div>

        {/* 订单进度 */}
        <div className="status-steps">
          <Steps current={getOrderSteps().length - 1} direction="horizontal">
            {getOrderSteps().map((step, index) => (
              <Steps.Step key={step.key} title={step.title} />
            ))}
          </Steps>
        </div>

        {/* 预计送达时间 */}
        {order.estimatedDeliveryTime && (
          <div className="delivery-time">
            <ClockCircleOutline fontSize={16} />
            <span>{t('orderDetail.estimatedTime')}: {order.estimatedDeliveryTime}</span>
          </div>
        )}
      </Card>

      {/* 配送地址 */}
      <Card className="address-card">
        <div className="card-title">
          <EnvironmentOutline fontSize={18} color="#1677FF" />
          <span>{t('orderDetail.deliveryAddress')}</span>
        </div>
        <div className="address-info">
          <div className="address-detail">
            <div className="address-name">{order.deliveryAddress?.name}</div>
            <div className="address-phone">
              <PhoneFill fontSize={12} /> {order.deliveryAddress?.phone}
            </div>
          </div>
          <div className="address-text">{order.deliveryAddress?.detail}</div>
        </div>
      </Card>

      {/* 商家信息 */}
      <Card className="merchant-card">
        <List>
          <List.Item
            extra={
              <Button size="small" fill="outline" onClick={handleContactMerchant}>
                {t('orderDetail.contact')}
              </Button>
            }
          >
            {order.restaurantName || t('orderDetail.restaurant')}
          </List.Item>
        </List>
      </Card>

      {/* 订单商品 */}
      <Card className="items-card">
        <div className="card-title">{t('orderDetail.orderItems')}</div>
        <div className="items-list">
          {order.items?.map((item, index) => (
            <div key={index} className="item-row">
              <div className="item-info">
                <div className="item-name">{item.name}</div>
                <div className="item-quantity">x{item.quantity}</div>
              </div>
              <div className="item-price">${(item.price * item.quantity).toFixed(2)}</div>
            </div>
          ))}
        </div>

        <Divider />

        {/* 金额明细 */}
        <div className="amount-detail">
          <div className="amount-row">
            <span>{t('orderDetail.subtotal')}</span>
            <span>${order.subtotal?.toFixed(2) || '0.00'}</span>
          </div>
          <div className="amount-row">
            <span>{t('orderDetail.deliveryFee')}</span>
            <span>${order.deliveryFee?.toFixed(2) || '0.00'}</span>
          </div>
          {order.discount > 0 && (
            <div className="amount-row discount">
              <span>{t('orderDetail.discount')}</span>
              <span>-${order.discount?.toFixed(2)}</span>
            </div>
          )}
          <div className="amount-row total">
            <span>{t('orderDetail.totalAmount')}</span>
            <span className="total-price">${order.totalAmount?.toFixed(2) || '0.00'}</span>
          </div>
        </div>
      </Card>

      {/* 订单信息 */}
      <Card className="info-card">
        <div className="card-title">{t('orderDetail.orderInfo')}</div>
        <div className="info-list">
          <div className="info-row">
            <span className="info-label">{t('orderDetail.orderNo')}</span>
            <span className="info-value">{order.orderNo}</span>
          </div>
          <div className="info-row">
            <span className="info-label">{t('orderDetail.createTime')}</span>
            <span className="info-value">{order.createdAt}</span>
          </div>
          {order.paidAt && (
            <div className="info-row">
              <span className="info-label">{t('orderDetail.paidTime')}</span>
              <span className="info-value">{order.paidAt}</span>
            </div>
          )}
          {order.remark && (
            <div className="info-row">
              <span className="info-label">{t('orderDetail.remark')}</span>
              <span className="info-value">{order.remark}</span>
            </div>
          )}
        </div>
      </Card>

      {/* 底部操作按钮 */}
      {order.status === 'completed' && (
        <div className="footer-actions">
          <Button block color="primary" size="large" onClick={handleReorder}>
            {t('orderDetail.reorder')}
          </Button>
        </div>
      )}
    </div>
  );
};

export default OrderDetailPage;
