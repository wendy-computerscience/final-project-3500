import { create } from 'zustand';

/**
 * 订单状态管理
 * 用于缓存订单列表，减少API调用
 */
const useOrderStore = create((set, get) => ({
  // 订单列表
  orders: [],

  // 订单列表加载状态
  loading: false,

  // 分页信息
  pagination: {
    page: 1,
    pageSize: 10,
    total: 0,
  },

  // 当前筛选状态
  currentStatus: 'all', // all, pending_payment, preparing, delivering, completed, cancelled

  /**
   * 设置订单列表
   */
  setOrders: (orders, pagination) => {
    set({ orders });
    if (pagination) {
      set({ pagination });
    }
  },

  /**
   * 追加订单（用于分页加载更多）
   */
  appendOrders: (newOrders) => {
    const currentOrders = get().orders;
    set({ orders: [...currentOrders, ...newOrders] });
  },

  /**
   * 更新单个订单
   */
  updateOrder: (orderId, updatedData) => {
    const orders = get().orders;
    const index = orders.findIndex((order) => order.id === orderId);

    if (index !== -1) {
      orders[index] = { ...orders[index], ...updatedData };
      set({ orders: [...orders] });
    }
  },

  /**
   * 移除订单（用于删除操作）
   */
  removeOrder: (orderId) => {
    const orders = get().orders;
    set({ orders: orders.filter((order) => order.id !== orderId) });
  },

  /**
   * 添加新订单（用于创建订单后）
   */
  addOrder: (order) => {
    const orders = get().orders;
    set({ orders: [order, ...orders] });
  },

  /**
   * 设置加载状态
   */
  setLoading: (loading) => {
    set({ loading });
  },

  /**
   * 设置当前筛选状态
   */
  setCurrentStatus: (status) => {
    set({ currentStatus: status });
  },

  /**
   * 设置分页信息
   */
  setPagination: (pagination) => {
    set({ pagination: { ...get().pagination, ...pagination } });
  },

  /**
   * 清空订单列表
   */
  clearOrders: () => {
    set({
      orders: [],
      pagination: {
        page: 1,
        pageSize: 10,
        total: 0,
      },
    });
  },

  /**
   * 根据状态筛选订单
   */
  getFilteredOrders: () => {
    const { orders, currentStatus } = get();

    if (currentStatus === 'all') {
      return orders;
    }

    return orders.filter((order) => order.status === currentStatus);
  },
}));

export default useOrderStore;
