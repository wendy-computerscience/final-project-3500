import { create } from 'zustand';
import { cartApi } from '../api';

/**
 * 购物车状态管理
 * 支持多个餐厅的购物车
 * 数据从服务器实时同步
 */
const useCartStore = create((set, get) => ({
  // 购物车数据结构（数组，支持多个餐厅）:
  // [
  //   {
  //     restaurantId: string,
  //     restaurantName: string,
  //     restaurant: { lat, lng, minOrder, deliveryFee, avgPrepMin, merchantId },
  //     items: [{ id, name, price, quantity, description, cartItemId }]
  //   }
  // ]
  carts: [],
  userId: null,

  /**
   * 设置用户ID
   */
  setUserId: (id) => {
    set({ userId: id });
  },

  /**
   * 初始化餐厅购物车
   * 确保该餐厅的购物车结构存在，并加载最新数据
   */
  initCart: async (restaurantId, restaurantName, restaurantInfo) => {
    const userId = get().userId;

    if (!userId) {
      console.warn('用户未登录，无法初始化购物车');
      return;
    }

    try {
      // 从服务器加载最新购物车数据
      await get().loadCartFromServer(userId);

      // 检查该餐厅的购物车是否已存在
      const carts = get().carts;
      const existingCart = carts.find(cart => cart.restaurantId === restaurantId.toString());

      // 如果不存在，在本地创建空购物车结构（不调用后端API）
      if (!existingCart) {
        const newCart = {
          restaurantId: restaurantId.toString(),
          restaurantName,
          restaurant: {
            lat: restaurantInfo.lat,
            lng: restaurantInfo.lng,
            minOrder: restaurantInfo.minOrder,
            deliveryFee: restaurantInfo.deliveryFee,
            avgPrepMin: restaurantInfo.avgPrepMin,
            merchantId: restaurantInfo.merchantId
          },
          items: []
        };

        set({ carts: [...carts, newCart] });
      } else {
        // 如果已存在，更新餐厅信息（确保是最新的）
        const updatedCarts = carts.map(cart => {
          if (cart.restaurantId === restaurantId.toString()) {
            return {
              ...cart,
              restaurantName,
              restaurant: {
                lat: restaurantInfo.lat,
                lng: restaurantInfo.lng,
                minOrder: restaurantInfo.minOrder,
                deliveryFee: restaurantInfo.deliveryFee,
                avgPrepMin: restaurantInfo.avgPrepMin,
                merchantId: restaurantInfo.merchantId
              }
            };
          }
          return cart;
        });

        set({ carts: updatedCarts });
      }
    } catch (error) {
      console.error('初始化购物车失败:', error);
    }
  },

  /**
   * 从服务器加载购物车
   */
  loadCartFromServer: async (userId) => {
    try {
      const response = await cartApi.getUserCart(userId);

      if (response && response.success && response.data) {
        set({ carts: response.data.carts || [], userId });
        return response.data.carts || [];
      } else {
        set({ carts: [], userId });
        return [];
      }
    } catch (error) {
      console.error('加载购物车失败:', error);
      set({ carts: [], userId });
      return [];
    }
  },

  /**
   * 添加商品到购物车
   */
  addItem: async (item, restaurantInfo) => {
    const userId = get().userId;

    if (!userId) {
      console.error('用户未登录');
      return;
    }

    try {
      const response = await cartApi.addToCart({
        userId,
        restaurantId: parseInt(restaurantInfo.id),
        menuItemId: parseInt(item.id),
        quantity: 1
      });

      // 使用服务器返回的数据更新本地
      if (response.success && response.data) {
        set({ carts: response.data.carts || [] });
      }
    } catch (error) {
      console.error('同步购物车到服务器失败:', error);
    }
  },

  /**
   * 减少商品数量或移除商品
   */
  removeItem: async (cartItemId) => {
    const userId = get().userId;

    if (!userId || !cartItemId) return;

    try {
      const response = await cartApi.removeCartItem(cartItemId, userId);
      if (response.success && response.data) {
        set({ carts: response.data.carts || [] });
      }
    } catch (error) {
      console.error('同步购物车失败:', error);
    }
  },

  /**
   * 更新商品数量
   */
  updateItemQuantity: async (cartItemId, quantity) => {
    const userId = get().userId;

    if (!userId || !cartItemId) return;

    try {
      const response = await cartApi.updateCartItem(cartItemId, quantity, userId);
      if (response.success && response.data) {
        set({ carts: response.data.carts || [] });
      }
    } catch (error) {
      console.error('同步购物车失败:', error);
    }
  },

  /**
   * 清空购物车
   */
  clearCart: async () => {
    const userId = get().userId;

    if (!userId) return;

    set({ carts: [] });

    try {
      await cartApi.clearCart(userId);
    } catch (error) {
      console.error('清空服务器购物车失败:', error);
    }
  },

  /**
   * 获取指定餐厅的购物车
   */
  getCartByRestaurant: (restaurantId) => {
    const carts = get().carts;
    return carts.find(cart => cart.restaurantId === restaurantId.toString());
  },

  /**
   * 获取商品数量
   */
  getItemQuantity: (itemId) => {
    const carts = get().carts;
    for (const cart of carts) {
      const item = cart.items.find((i) => i.id === itemId.toString());
      if (item) return item.quantity;
    }
    return 0;
  },

  /**
   * 计算所有购物车的总金额
   */
  getTotalAmount: () => {
    const carts = get().carts;
    return carts.reduce((total, cart) => {
      return total + cart.items.reduce((sum, item) => {
        return sum + item.price * item.quantity;
      }, 0);
    }, 0);
  },

  /**
   * 计算所有购物车的总数量
   */
  getTotalQuantity: () => {
    const carts = get().carts;
    return carts.reduce((total, cart) => {
      return total + cart.items.reduce((sum, item) => {
        return sum + item.quantity;
      }, 0);
    }, 0);
  },

  /**
   * 检查是否满足起送价（针对特定餐厅）
   */
  isMinOrderMet: (restaurantId) => {
    const cart = get().getCartByRestaurant(restaurantId);
    if (!cart) return false;

    const totalAmount = cart.items.reduce((sum, item) => {
      return sum + item.price * item.quantity;
    }, 0);

    return totalAmount >= cart.restaurant.minOrder;
  },

  /**
   * 获取还差多少才能起送（针对特定餐厅）
   */
  getMinOrderGap: (restaurantId) => {
    const cart = get().getCartByRestaurant(restaurantId);
    if (!cart) return 0;

    const totalAmount = cart.items.reduce((sum, item) => {
      return sum + item.price * item.quantity;
    }, 0);

    const gap = cart.restaurant.minOrder - totalAmount;
    return gap > 0 ? gap : 0;
  },
}));

export default useCartStore;
