import { create } from 'zustand';
import { persist } from 'zustand/middleware';

/**
 * 用户状态管理
 */
const useUserStore = create(
  persist(
    (set) => ({
      // 登录状态
      isLoggedIn: false,
      token: null,

      // 用户信息（开发环境提供默认测试用户）
      user: {
        id: process.env.NODE_ENV === 'development' ? 1 : null,
        name: process.env.NODE_ENV === 'development' ? '测试用户' : '',
        phone: process.env.NODE_ENV === 'development' ? '13800138000' : '',
        tastes: [],
      },

      // 用户当前位置
      location: {
        lat: 22.301,
        lng: 114.172,
        address: '深圳市南山区科技园北区',
      },

      // 登录
      login: (userData) => set({
        isLoggedIn: true,
        token: userData.token,
        user: {
          id: userData.id,
          name: userData.name,
          phone: userData.phone,
          tastes: userData.tastes || [],
        }
      }),

      // 退出登录
      logout: () => set({
        isLoggedIn: false,
        token: null,
        user: {
          id: null,
          name: '',
          phone: '',
          tastes: [],
        }
      }),

      // 更新用户信息
      setUser: (user) => set({ user }),

      // 更新位置
      setLocation: (location) => set({ location }),
    }),
    {
      name: 'user-storage', // localStorage key
    }
  )
);

export default useUserStore;
