import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { addressApi } from '../api';

/**
 * 地址状态管理
 * 用于缓存地址列表，减少API调用
 */
const useAddressStore = create(
  persist(
    (set, get) => ({
      // 地址列表
      addresses: [],

      // 加载状态
      loading: false,

      // 当前选中的地址ID（用于结算页）
      selectedAddressId: null,

      setAddresses: (addresses) => {
        set({ addresses });
      },

      addAddress: (address) => {
        const addresses = get().addresses;

        if (address.isDefault) {
          addresses.forEach((addr) => {
            addr.isDefault = false;
          });
        }

        set({ addresses: [address, ...addresses] });
      },

      updateAddress: (addressId, updatedData) => {
        const addresses = get().addresses;
        const index = addresses.findIndex((addr) => addr.id === addressId);

        if (index !== -1) {
          if (updatedData.isDefault) {
            addresses.forEach((addr) => {
              addr.isDefault = false;
            });
          }

          addresses[index] = { ...addresses[index], ...updatedData };
          set({ addresses: [...addresses] });
        }
      },

      deleteAddress: (addressId) => {
        const addresses = get().addresses;
        set({ addresses: addresses.filter((addr) => addr.id !== addressId) });
      },

      setDefaultAddress: (addressId) => {
        const addresses = get().addresses;

        addresses.forEach((addr) => {
          addr.isDefault = addr.id === addressId;
        });

        set({ addresses: [...addresses] });
      },

      setSelectedAddressId: (addressId) => {
        set({ selectedAddressId: addressId });
      },

      getDefaultAddress: () => {
        const addresses = get().addresses;
        return addresses.find((addr) => addr.isDefault) || null;
      },

      getAddressById: (addressId) => {
        const addresses = get().addresses;
        return addresses.find((addr) => addr.id === addressId) || null;
      },

      getSelectedAddress: () => {
        const { addresses, selectedAddressId } = get();

        if (selectedAddressId) {
          return (
            addresses.find((addr) => addr.id === selectedAddressId) || null
          );
        }

        return get().getDefaultAddress();
      },

      setLoading: (loading) => {
        set({ loading });
      },

      clearAddresses: () => {
        set({
          addresses: [],
          selectedAddressId: null
        });
      },

      // 统一使用内部引入的 addressApi
      loadAddresses: async (userId) => {
        try {
          set({ loading: true });

          const response = await addressApi.getAddressList(userId);

          if (response.success) {
            set({ addresses: response.data });
          }
        } catch (error) {
          console.error('加载地址列表失败:', error);
        } finally {
          set({ loading: false });
        }
      }
    }),
    {
      name: 'address-storage',
      partialize: (state) => ({ addresses: state.addresses })
    }
  )
);

export default useAddressStore;

