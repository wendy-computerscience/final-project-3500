import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './components/MainLayout';
import HomePage from './pages/HomePage';
import CartPage from './pages/CartPage';
import OrdersPage from './pages/OrdersPage';
import ProfilePage from './pages/ProfilePage';
import LoginPage from './pages/LoginPage';
import SearchPage from './pages/SearchPage';
import TrackingPage from './pages/TrackingPage';
import OrderDetailPage from './pages/OrderDetailPage';
import RestaurantDetailPage from './pages/RestaurantDetailPage';
import FoodDetailPage from './pages/FoodDetailPage';
import AddressManagePage from './pages/AddressManagePage';
import AddressEditPage from './pages/AddressEditPage';
import AddressSelectPage from './pages/AddressSelectPage';
import CouponPage from './pages/CouponPage';
import CouponCenterPage from './pages/CouponCenterPage';
import CheckoutPage from './pages/CheckoutPage';
import PaymentPage from './pages/PaymentPage';
import useUserStore from './store/userStore';
import './index.css';

// 路由保护组件
const ProtectedRoute = ({ children }) => {
  const { isLoggedIn } = useUserStore();

  if (!isLoggedIn) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

// 根路径重定向组件
const RootRedirect = () => {
  const { isLoggedIn } = useUserStore();
  return <Navigate to={isLoggedIn ? "/home" : "/login"} replace />;
};

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          {/* 根路径根据登录状态重定向 */}
          <Route index element={<RootRedirect />} />

          {/* 登录页（公开访问） */}
          <Route path="/login" element={<LoginPage />} />

          {/* 带TabBar的主页面（需要登录） */}
          <Route path="/" element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }>
            <Route path="home" element={<HomePage />} />
            <Route path="cart" element={<CartPage />} />
            <Route path="orders" element={<OrdersPage />} />
            <Route path="profile" element={<ProfilePage />} />
          </Route>

          {/* 独立页面（需要登录） */}
          <Route path="/search" element={
            <ProtectedRoute>
              <SearchPage />
            </ProtectedRoute>
          } />
          <Route path="/food/:foodId" element={
            <ProtectedRoute>
              <FoodDetailPage />
            </ProtectedRoute>
          } />
          <Route path="/restaurant/:restaurantId" element={
            <ProtectedRoute>
              <RestaurantDetailPage />
            </ProtectedRoute>
          } />
          <Route path="/tracking/:orderId" element={
            <ProtectedRoute>
              <TrackingPage />
            </ProtectedRoute>
          } />
          <Route path="/order/:orderId" element={
            <ProtectedRoute>
              <OrderDetailPage />
            </ProtectedRoute>
          } />
          <Route path="/address" element={
            <ProtectedRoute>
              <AddressManagePage />
            </ProtectedRoute>
          } />
          <Route path="/address/select" element={
            <ProtectedRoute>
              <AddressSelectPage />
            </ProtectedRoute>
          } />
          <Route path="/address/new" element={
            <ProtectedRoute>
              <AddressEditPage />
            </ProtectedRoute>
          } />
          <Route path="/address/edit/:addressId" element={
            <ProtectedRoute>
              <AddressEditPage />
            </ProtectedRoute>
          } />
          <Route path="/coupons" element={
            <ProtectedRoute>
              <CouponPage />
            </ProtectedRoute>
          } />
          <Route path="/coupon/center" element={
            <ProtectedRoute>
              <CouponCenterPage />
            </ProtectedRoute>
          } />
          <Route path="/checkout" element={
            <ProtectedRoute>
              <CheckoutPage />
            </ProtectedRoute>
          } />
          <Route path="/payment/:orderId" element={
            <ProtectedRoute>
              <PaymentPage />
            </ProtectedRoute>
          } />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
