import client from './client';

/**
 * 优惠券相关API
 */

/**
 * 获取用户优惠券列表
 * 对应后端: GET /api/coupons?userId=...&type=unused|used|expired
 * @param {number|string} userId - 用户ID
 * @param {string} status - 优惠券状态（可选）: unused, used, expired
 */
export const getUserCoupons = async (userId, status = null) => {
  const params = { userId };
  if (status) {
    // 后端使用 type 字段表示优惠券状态
    params.type = status;
  }

  const response = await client.get('/coupons', { params });
  return response;
};

/**
 * 获取可领取的优惠券列表
 * 对应后端: GET /api/coupons/available
 */
export const getAvailableCoupons = async () => {
  const response = await client.get('/coupons/available');
  return response;
};

/**
 * 领取优惠券
 * 对应后端: POST /api/coupons
 * @param {number|string} userId - 用户ID
 * @param {number|string} couponId - 优惠券模板ID
 */
export const claimCoupon = async (userId, couponId) => {
  const response = await client.post('/coupons', { userId, couponId });
  return response;
};

/**
 * 获取用户红包余额
 * 对应后端: GET /api/coupons/red-packet?userId=...
 */
export const getRedPacket = async (userId) => {
  const response = await client.get('/coupons/red-packet', {
    params: { userId }
  });
  return response;
};

/**
 * 获取可用优惠券（结算页使用）
 * 当前后端没有 /coupons/usable 路由，调用前请确认实现情况
 */
export const getUsableCoupons = async (userId, orderAmount, restaurantId = null) => {
  const params = { userId, orderAmount };
  if (restaurantId) {
    params.restaurantId = restaurantId;
  }

  const response = await client.get('/coupons/usable', { params });
  return response;
};

