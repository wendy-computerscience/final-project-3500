/**
 * API 统一导出
 * 集中管理所有API模块，方便统一导入使用
 */

// 订单相关API
export * as orderApi from './order';

// 餐厅和菜品相关API
export * as restaurantApi from './restaurant';

// 地址管理API
export * as addressApi from './address';

// 优惠券API
export * as couponApi from './coupon';

// 用户认证和信息API
export * as userApi from './user';

// 推荐系统API
export * as recommendationApi from './recommendation';

// 订单追踪API
export * as trackingApi from './tracking';

// 购物车API
export * as cartApi from './cart';

// 凑单建议API（如需要可以创建单独的文件）
// export * as suggestionApi from './suggestion';

// 默认导出 axios client
export { default as client } from './client';

/**
 * 使用示例：
 *
 * // 方式1: 导入整个API模块
 * import { orderApi, restaurantApi } from '@/api';
 * const orders = await orderApi.getUserOrders(userId);
 *
 * // 方式2: 导入单个API文件
 * import * as orderApi from '@/api/order';
 * const orders = await orderApi.getUserOrders(userId);
 *
 * // 方式3: 导入具体函数
 * import { getUserOrders } from '@/api/order';
 * const orders = await getUserOrders(userId);
 */
