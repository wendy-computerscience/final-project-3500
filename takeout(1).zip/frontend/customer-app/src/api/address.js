import client from './client';

/**
 * 地址管理相关API
 */

/**
 * 获取用户地址列表
 * @param {number|string} userId - 用户ID
 * @returns {Promise} - 地址列表
 */
export const getAddressList = async (userId) => {
  const response = await client.get('/addresses', { params: { userId } });
  return response;
};

/**
 * 获取地址详情
 * @param {number|string} addressId - 地址ID
 * @returns {Promise} - 地址详情
 */
export const getAddressDetail = async (addressId) => {
  const response = await client.get(`/addresses/${addressId}`);
  return response;
};

/**
 * 创建地址
 * @param {object} addressData - 地址数据
 * @param {number} addressData.userId - 用户ID
 * @param {string} addressData.tag - 标签: home, company, school
 * @param {string} addressData.name - 联系人姓名
 * @param {string} addressData.phone - 联系电话
 * @param {string} addressData.region - 区域（省市区）
 * @param {string} addressData.detail - 详细地址
 * @param {string} addressData.room - 门牌号（可选）
 * @param {number} addressData.latitude - 纬度（可选）
 * @param {number} addressData.longitude - 经度（可选）
 * @param {boolean} addressData.isDefault - 是否设为默认
 * @returns {Promise} - 创建结果
 */
export const createAddress = async (addressData) => {
  const response = await client.post('/addresses', addressData);
  return response;
};

/**
 * 更新地址
 * @param {number|string} addressId - 地址ID
 * @param {object} addressData - 地址数据
 * @returns {Promise} - 更新结果
 */
export const updateAddress = async (addressId, addressData) => {
  const response = await client.put(`/addresses/${addressId}`, addressData);
  return response;
};

/**
 * 删除地址
 * @param {number|string} addressId - 地址ID
 * @returns {Promise} - 删除结果
 */
export const deleteAddress = async (addressId) => {
  const response = await client.delete(`/addresses/${addressId}`);
  return response;
};

/**
 * 设置默认地址
 * @param {number|string} addressId - 地址ID
 * @param {number|string} userId - 用户ID
 * @returns {Promise} - 设置结果
 */
export const setDefaultAddress = async (addressId, userId) => {
  const response = await client.post(`/addresses/${addressId}/default`, { userId });
  return response;
};
