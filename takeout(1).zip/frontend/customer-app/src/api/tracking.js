import client from './client';

/**
 * 获取订单追踪信息
 * @param {string} orderId - 订单ID
 * 返回结构: { success, data, message }
 */
export const getTrackingInfo = async (orderId) => {
  return client.get(`/track/${orderId}`);
};

/**
 * 获取订单配送路径
 * @param {string} orderId - 订单ID
 * 返回结构: { success, data, message }
 */
export const getOrderRoute = async (orderId) => {
  return client.get(`/track/${orderId}/route`);
};

