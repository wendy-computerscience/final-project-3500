import client from './client';

/**
 * 用户认证和信息相关API
 */

/**
 * 用户登录（不存在则自动注册）
 * @param {object} loginData - 登录数据
 * @param {string} loginData.username - 账号
 * @param {string} loginData.password - 密码
 * @returns {Promise} - 登录结果（包含token和用户信息）
 */
export const login = async (loginData) => {
  const response = await client.post('/users/login', loginData);
  return response;
};

/**
 * 获取用户信息
 * @param {number|string} userId - 用户ID
 * @returns {Promise} - 用户信息
 */
export const getUserProfile = async (userId) => {
  const response = await client.get(`/users/${userId}/profile`);
  return response;
};

/**
 * 更新用户信息
 * @param {number|string} userId - 用户ID
 * @param {object} profileData - 用户信息
 * @param {string} profileData.nickname - 昵称（可选）
 * @param {string} profileData.avatar - 头像URL（可选）
 * @param {number} profileData.gender - 性别（可选）
 * @param {string} profileData.birthday - 生日（可选）
 * @param {string} profileData.email - 邮箱（可选）
 * @returns {Promise} - 更新结果
 */
export const updateUserProfile = async (userId, profileData) => {
  const response = await client.put(`/users/${userId}/profile`, profileData);
  return response;
};

/**
 * 退出登录
 * @returns {Promise} - 退出结果
 */
export const logout = async () => {
  // 清除本地token
  localStorage.removeItem('token');
  return Promise.resolve({ success: true });
};
