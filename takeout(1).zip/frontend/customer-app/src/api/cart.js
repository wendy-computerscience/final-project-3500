import client from './client';

const API_BASE = '/cart';

/**
 * 获取用户购物车
 * @param {number} userId - 用户ID
 * @returns {Promise} 购物车数据
 */
export const getUserCart = async (userId) => {
  try {
    const response = await client.get(`${API_BASE}/${userId}`);
    return response;
  } catch (error) {
    console.error('获取购物车失败:', error);
    return null;
  }
};

/**
 * 添加商品到购物车
 * @param {Object} params - 参数
 * @param {number} params.userId - 用户ID
 * @param {number} params.restaurantId - 餐厅ID
 * @param {number} params.menuItemId - 菜品ID
 * @param {number} params.quantity - 数量
 * @returns {Promise} 操作结果
 */
export const addToCart = async ({ userId, restaurantId, menuItemId, quantity = 1 }) => {
  const response = await client.post(API_BASE, {
    userId,
    restaurantId,
    menuItemId,
    quantity
  });
  return response;
};

/**
 * 更新购物车项数量
 * @param {number} cartItemId - 购物车项ID
 * @param {number} quantity - 新数量
 * @param {number} userId - 用户ID
 * @returns {Promise} 操作结果
 */
export const updateCartItem = async (cartItemId, quantity, userId) => {
  const response = await client.put(`${API_BASE}/${cartItemId}`, {
    quantity,
    userId
  });
  return response;
};

/**
 * 删除购物车项
 * @param {number} cartItemId - 购物车项ID
 * @param {number} userId - 用户ID
 * @returns {Promise} 操作结果
 */
export const removeCartItem = async (cartItemId, userId) => {
  const response = await client.delete(`${API_BASE}/${cartItemId}`, {
    data: { userId }
  });
  return response;
};

/**
 * 清空购物车
 * @param {number} userId - 用户ID
 * @returns {Promise} 操作结果
 */
export const clearCart = async (userId) => {
  const response = await client.delete(`${API_BASE}/${userId}/clear`);
  return response;
};
