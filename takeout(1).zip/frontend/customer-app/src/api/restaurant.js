import client from './client';

/**
 * 餐厅和菜品相关API
 */

/**
 * 获取所有食物列表（包含餐厅信息）
 * 用于首页展示
 * @param {object} params - 查询参数
 * @param {number} params.page - 页码（默认1）
 * @param {number} params.pageSize - 每页数量（默认20）
 * @param {string} params.sortBy - 排序方式（sales/price_asc/price_desc/rating，默认sales）
 * @returns {Promise} - 食物列表
 */
export const getAllFoods = async (params = {}) => {
  const response = await client.get('/restaurants/foods', { params });
  return response;
};

/**
 * 获取餐厅列表
 * @param {object} params - 查询参数
 * @param {string} params.category - 分类（可选）
 * @param {number} params.latitude - 用户纬度（可选）
 * @param {number} params.longitude - 用户经度（可选）
 * @param {number} params.page - 页码（默认1）
 * @param {number} params.pageSize - 每页数量（默认10）
 * @returns {Promise} - 餐厅列表
 */
export const getRestaurantList = async (params = {}) => {
  const response = await client.get('/restaurants', { params });
  return response;
};

/**
 * 获取餐厅详情
 * @param {number|string} restaurantId - 餐厅ID
 * @returns {Promise} - 餐厅详情
 */
export const getRestaurantDetail = async (restaurantId) => {
  const response = await client.get(`/restaurants/${restaurantId}`);
  return response;
};

/**
 * 获取餐厅菜品列表
 * @param {number|string} restaurantId - 餐厅ID
 * @returns {Promise} - 菜品列表
 */
export const getRestaurantMenu = async (restaurantId) => {
  const response = await client.get(`/restaurants/${restaurantId}/menu`);
  return response;
};

/**
 * 获取菜品详情
 * @param {number|string} foodId - 菜品ID
 * @returns {Promise} - 菜品详情
 */
export const getFoodDetail = async (foodId) => {
  const response = await client.get(`/menu-items/${foodId}`);
  return response;
};

/**
 * 搜索餐厅或菜品
 * @param {string} keyword - 搜索关键词
 * @param {object} params - 其他参数
 * @param {string} params.type - 搜索类型: restaurant, food, all（默认all）
 * @param {number} params.latitude - 用户纬度（可选）
 * @param {number} params.longitude - 用户经度（可选）
 * @returns {Promise} - 搜索结果
 */
export const search = async (keyword, params = {}) => {
  const response = await client.get('/search', {
    params: { keyword, ...params }
  });
  return response;
};
