import apiClient from './client';

/**
 * 获取首页个性化推荐
 * @param {object} params - 参数对象
 * @param {string} params.userId - 用户ID
 * @param {number} params.lat - 用户纬度
 * @param {number} params.lng - 用户经度
 * @param {number} params.limit - 返回数量
 * @returns {Promise} - 推荐列表
 */
export const getHomeRecommendations = (params) => {
  return apiClient.get('/reco/home', { params });
};

/**
 * 获取替代推荐（结算页）
 * @param {object} params - 参数对象
 * @param {string} params.orderId - 订单ID（可选）
 * @param {string} params.restaurantId - 当前餐厅ID
 * @param {number} params.lat - 用户纬度
 * @param {number} params.lng - 用户经度
 * @returns {Promise} - 替代推荐列表
 */
export const getAlternatives = (params) => {
  return apiClient.get('/reco/alternatives', { params });
};
