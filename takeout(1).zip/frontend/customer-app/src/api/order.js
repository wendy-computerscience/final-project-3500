import client from './client';

/**
 * 订单相关API
 */

/**
 * 获取用户订单列表
 * @param {number|string} userId - 用户ID
 * @param {string} status - 订单状态（可选）: pending_payment, preparing, delivering, completed, cancelled
 * @param {number} page - 页码（默认1）
 * @param {number} pageSize - 每页数量（默认10）
 * @returns {Promise} - 订单列表
 */
export const getUserOrders = async (userId, status = null, page = 1, pageSize = 10) => {
  const params = { page, pageSize };
  if (status) {
    params.status = status;
  }

  const response = await client.get(`/orders/user/${userId}`, { params });
  return response;
};

/**
 * 获取订单详情
 * @param {number|string} orderId - 订单ID
 * @returns {Promise} - 订单详情
 */
export const getOrderDetail = async (orderId) => {
  const response = await client.get(`/orders/${orderId}`);
  return response;
};

/**
 * 创建订单
 * @param {object} orderData - 订单数据
 * @param {number} orderData.userId - 用户ID
 * @param {number} orderData.merchantId - 商家ID
 * @param {number} orderData.restaurantId - 餐厅ID
 * @param {Array} orderData.items - 订单商品列表
 * @param {object} orderData.deliveryAddress - 配送地址
 * @param {number} orderData.itemsAmount - 商品总金额
 * @param {number} orderData.deliveryFee - 配送费
 * @param {number} orderData.couponId - 优惠券ID（可选）
 * @param {number} orderData.couponAmount - 优惠券金额（可选）
 * @param {number} orderData.totalAmount - 订单总金额
 * @param {number} orderData.distance - 配送距离
 * @param {string} orderData.area - 配送区域
 * @returns {Promise} - 创建结果
 */
export const createOrder = async (orderData) => {
  const response = await client.post('/orders', orderData);
  return response;
};

/**
 * 支付订单
 * @param {number|string} orderId - 订单ID
 * @param {string} paymentMethod - 支付方式: wechat, alipay
 * @returns {Promise} - 支付结果
 */
export const payOrder = async (orderId, paymentMethod) => {
  const response = await client.put(`/orders/${orderId}/pay`, { paymentMethod });
  return response;
};

/**
 * 取消订单
 * @param {number|string} orderId - 订单ID
 * @param {string} cancelReason - 取消原因
 * @returns {Promise} - 取消结果
 */
export const cancelOrder = async (orderId, cancelReason) => {
  const response = await client.put(`/orders/${orderId}/cancel`, { cancelReason });
  return response;
};

/**
 * 计算配送费
 * @param {object} params - 参数
 * @param {number} params.restaurantLat - 餐厅纬度
 * @param {number} params.restaurantLng - 餐厅经度
 * @param {number} params.userLat - 用户纬度
 * @param {number} params.userLng - 用户经度
 * @param {number} params.baseFee - 基础配送费（可选）
 * @returns {Promise} - 配送费和预计送达时间
 */
export const calculateDeliveryFee = async (params) => {
  const response = await client.post('/orders/calculate-delivery-fee', params);
  return response;
};

/**
 * 获取订单徽章数量
 * @param {number|string} userId - 用户ID
 * @returns {Promise} - 各状态订单数量
 */
export const getOrdersBadge = async (userId) => {
  const response = await client.get('/orders/badge/count', { params: { userId } });
  return response;
};

/**
 * 再来一单
 * @param {number|string} orderId - 原订单ID
 * @returns {Promise} - 新订单信息
 */
export const reorderOrder = async (orderId) => {
  const response = await client.post(`/orders/${orderId}/reorder`);
  return response;
};

/**
 * 申请退款
 * @param {number|string} orderId - 订单ID
 * @param {string} refundReason - 退款原因
 * @returns {Promise} - 退款申请结果
 */
export const refundOrder = async (orderId, refundReason) => {
  const response = await client.post(`/orders/${orderId}/refund`, { refundReason });
  return response;
};

/**
 * 删除订单（软删除）
 * @param {number|string} orderId - 订单ID
 * @returns {Promise} - 删除结果
 */
export const deleteOrder = async (orderId) => {
  const response = await client.delete(`/orders/${orderId}`);
  return response;
};
