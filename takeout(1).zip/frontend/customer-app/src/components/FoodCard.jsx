import { Card, Tag, Stepper, Button } from 'antd-mobile';
import { LikeOutline } from 'antd-mobile-icons';
import './FoodCard.css';

/**
 * 菜品卡片组件
 * @param {object} food - 菜品数据
 * @param {number} quantity - 当前数量
 * @param {function} onAdd - 添加回调
 * @param {function} onRemove - 移除回调
 * @param {function} onClick - 点击卡片回调（可选）
 */
const FoodCard = ({ food, quantity = 0, onAdd, onRemove, onClick }) => {
  const handleStepperChange = (value) => {
    if (value > quantity) {
      onAdd && onAdd(food);
    } else if (value < quantity) {
      onRemove && onRemove(food.id);
    }
  };

  const handleCardClick = (e) => {
    // 如果点击的是Stepper或Button，不触发卡片点击
    if (e.target.closest('.food-item-action')) {
      return;
    }
    onClick && onClick(food);
  };

  return (
    <Card
      className="food-card"
      onClick={handleCardClick}
      style={{ cursor: onClick ? 'pointer' : 'default' }}
    >
      <div className="food-item">
        <div className="food-item-info">
          <div className="food-item-name">{food.name}</div>
          {food.description && (
            <div className="food-item-desc">{food.description}</div>
          )}
          <div className="food-item-meta">
            {food.monthSales !== undefined && (
              <Tag color="default" fill="outline" style={{ fontSize: 11 }}>
                月售{food.monthSales}
              </Tag>
            )}
            {food.rating && (
              <span className="food-item-rating">
                <LikeOutline fontSize={12} />
                {food.rating}
              </span>
            )}
          </div>
          <div className="food-item-price">${food.price.toFixed(2)}</div>
        </div>

        <div className="food-item-action">
          {quantity > 0 ? (
            <Stepper
              value={quantity}
              onChange={handleStepperChange}
              min={0}
            />
          ) : (
            <Button
              size="small"
              color="primary"
              onClick={(e) => {
                e.stopPropagation();
                onAdd && onAdd(food);
              }}
            >
              加入
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
};

export default FoodCard;
