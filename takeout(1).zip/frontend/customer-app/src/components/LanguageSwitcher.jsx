import { useTranslation } from 'react-i18next';
import { Selector } from 'antd-mobile';
import { GlobalOutline } from 'antd-mobile-icons';
import './LanguageSwitcher.css';

const LanguageSwitcher = ({ style }) => {
  const { i18n } = useTranslation();

  const languageOptions = [
    { label: '中文', value: 'zh' },
    { label: 'English', value: 'en' }
  ];

  const handleLanguageChange = (value) => {
    if (value && value.length > 0) {
      i18n.changeLanguage(value[0]);
      localStorage.setItem('language', value[0]);
    }
  };

  return (
    <div className="language-switcher" style={style}>
      <GlobalOutline fontSize={18} style={{ marginRight: 8 }} />
      <Selector
        options={languageOptions}
        value={[i18n.language]}
        onChange={handleLanguageChange}
        style={{
          '--border-radius': '8px',
          '--border': '1px solid #e5e5e5',
          '--checked-border': '1px solid #667eea',
          '--checked-color': '#667eea',
          '--padding': '4px 12px'
        }}
      />
    </div>
  );
};

export default LanguageSwitcher;
