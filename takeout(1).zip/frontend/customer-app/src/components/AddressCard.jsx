import { Card, Tag, Button } from 'antd-mobile';
import { LocationFill, PhoneFill, CheckCircleFill } from 'antd-mobile-icons';
import { useTranslation } from 'react-i18next';
import './AddressCard.css';

/**
 * 地址卡片组件
 * @param {object} address - 地址数据
 * @param {boolean} selectable - 是否可选择（结算页使用）
 * @param {boolean} selected - 是否选中
 * @param {function} onClick - 点击回调
 * @param {function} onEdit - 编辑回调
 * @param {function} onDelete - 删除回调
 * @param {function} onSetDefault - 设置默认回调
 */
const AddressCard = ({
  address,
  selectable = false,
  selected = false,
  onClick,
  onEdit,
  onDelete,
  onSetDefault,
}) => {
  const { t } = useTranslation();

  // 标签颜色映射
  const tagColorMap = {
    home: 'primary',
    company: 'success',
    school: 'warning',
  };

  // 标签文本映射
  const tagTextMap = {
    home: t('address.tagHome'),
    company: t('address.tagCompany'),
    school: t('address.tagSchool'),
    '家': t('address.tagHome'),
    '公司': t('address.tagCompany'),
    '学校': t('address.tagSchool'),
  };

  const handleAction = (e, action, ...args) => {
    e.stopPropagation();
    action && action(...args);
  };

  return (
    <Card
      className={`address-card ${selectable ? 'selectable' : ''} ${selected ? 'selected' : ''}`}
      onClick={() => onClick && onClick(address)}
    >
      <div className="address-content">
        {/* 地址头部 */}
        <div className="address-header">
          <div className="address-title">
            {selectable && selected && (
              <CheckCircleFill color="#667eea" fontSize={18} style={{ marginRight: 6 }} />
            )}
            <LocationFill fontSize={16} color="#667eea" />
            {address.tag && (
              <Tag
                color={tagColorMap[address.tag] || 'default'}
                fill="solid"
                style={{ marginLeft: 8, fontSize: 11 }}
              >
                {tagTextMap[address.tag] || address.tag}
              </Tag>
            )}
            {address.isDefault && (
              <Tag color="primary" fill="outline" style={{ marginLeft: 8, fontSize: 11 }}>
                {t('address.default')}
              </Tag>
            )}
          </div>
        </div>

        {/* 联系人信息 */}
        <div className="address-contact">
          <span className="contact-name">{address.name}</span>
          <span className="contact-phone">
            <PhoneFill fontSize={12} />
            {address.phone}
          </span>
        </div>

        {/* 详细地址 */}
        <div className="address-detail">
          {address.region} {address.detail} {address.room}
        </div>

        {/* 操作按钮 */}
        {!selectable && (
          <div className="address-actions">
            {!address.isDefault && onSetDefault && (
              <Button
                size="small"
                fill="none"
                onClick={(e) => handleAction(e, onSetDefault, address.id)}
              >
                {t('address.setDefault')}
              </Button>
            )}
            {onEdit && (
              <Button
                size="small"
                fill="none"
                onClick={(e) => handleAction(e, onEdit, address)}
              >
                {t('common.edit')}
              </Button>
            )}
            {onDelete && (
              <Button
                size="small"
                fill="none"
                color="danger"
                onClick={(e) => handleAction(e, onDelete, address.id)}
              >
                {t('common.delete')}
              </Button>
            )}
          </div>
        )}
      </div>
    </Card>
  );
};

export default AddressCard;
