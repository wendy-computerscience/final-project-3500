import { Card, Tag, Button } from 'antd-mobile';
import { ShopbagOutline } from 'antd-mobile-icons';
import './OrderCard.css';

/**
 * 订单卡片组件
 * @param {object} order - 订单数据
 * @param {function} onClick - 点击卡片回调
 * @param {function} onAction - 操作按钮回调
 */
const OrderCard = ({ order, onClick, onAction }) => {
  // 订单状态配置
  const statusConfig = {
    pending_payment: { label: '待支付', color: 'warning', action: 'pay', actionText: '去支付' },
    preparing: { label: '制作中', color: 'primary', action: 'track', actionText: '查看进度' },
    pending_pickup: { label: '待取餐', color: 'primary', action: 'track', actionText: '查看进度' },
    delivering: { label: '配送中', color: 'primary', action: 'track', actionText: '查看进度' },
    completed: { label: '已完成', color: 'success', action: 'reorder', actionText: '再来一单' },
    cancelled: { label: '已取消', color: 'default', action: null, actionText: null },
  };

  const config = statusConfig[order.status] || statusConfig.pending_payment;

  // 格式化时间
  const formatTime = (timeStr) => {
    if (!timeStr) return '';

    const date = new Date(timeStr);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) return '今天 ' + timeStr.split(' ')[1];
    if (days === 1) return '昨天 ' + timeStr.split(' ')[1];
    return timeStr;
  };

  const handleAction = (e, action) => {
    e.stopPropagation();
    onAction && onAction(order, action);
  };

  return (
    <Card
      className="order-card"
      onClick={() => onClick && onClick(order)}
    >
      {/* 订单头部 */}
      <div className="order-header">
        <div className="restaurant-info">
          <ShopbagOutline fontSize={16} />
          <span className="restaurant-name">{order.restaurantName}</span>
        </div>
        <Tag color={config.color} fill="outline">
          {config.label}
        </Tag>
      </div>

      {/* 订单商品 */}
      <div className="order-items">
        <div className="items-text">
          {Array.isArray(order.items)
            ? order.items.join('、')
            : order.items
          }
          {order.itemCount > 2 && ` 等${order.itemCount}件商品`}
        </div>
      </div>

      {/* 订单底部 */}
      <div className="order-footer">
        <div className="order-info">
          <div className="order-time">{formatTime(order.createTime)}</div>
          <div className="order-amount">
            <span className="amount-label">实付</span>
            <span className="amount-symbol">$</span>
            <span className="amount-value">{order.totalAmount.toFixed(2)}</span>
          </div>
        </div>

        {/* 操作按钮 */}
        {config.action && (
          <div className="order-actions">
            <Button
              size="small"
              color={config.action === 'pay' ? 'primary' : 'default'}
              fill={config.action === 'pay' ? 'solid' : 'outline'}
              onClick={(e) => handleAction(e, config.action)}
            >
              {config.actionText}
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
};

export default OrderCard;
