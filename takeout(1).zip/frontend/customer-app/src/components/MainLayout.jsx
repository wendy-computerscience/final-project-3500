import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { TabBar } from 'antd-mobile';
import { useTranslation } from 'react-i18next';
import {
  AppOutline,
  ShopbagOutline,
  UnorderedListOutline,
  UserOutline
} from 'antd-mobile-icons';
import './MainLayout.css';

const MainLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();

  // TabBar配置
  const tabs = [
    {
      key: '/home',
      title: t('nav.home'),
      icon: <AppOutline />
    },
    {
      key: '/cart',
      title: t('nav.cart'),
      icon: <ShopbagOutline />
    },
    {
      key: '/orders',
      title: t('nav.orders'),
      icon: <UnorderedListOutline />
    },
    {
      key: '/profile',
      title: t('nav.profile'),
      icon: <UserOutline />
    }
  ];

  // 获取当前激活的Tab
  const getActiveKey = () => {
    const path = location.pathname;
    // 如果路径匹配某个tab，返回对应key
    const activeTab = tabs.find(tab => path.startsWith(tab.key));
    return activeTab ? activeTab.key : '/home';
  };

  // 切换Tab
  const handleTabChange = (key) => {
    navigate(key);
  };

  return (
    <div className="main-layout">
      {/* 页面内容区域 */}
      <div className="main-content">
        <Outlet />
      </div>

      {/* 底部TabBar */}
      <div className="main-tabbar">
        <TabBar activeKey={getActiveKey()} onChange={handleTabChange}>
          {tabs.map(item => (
            <TabBar.Item key={item.key} icon={item.icon} title={item.title} />
          ))}
        </TabBar>
      </div>
    </div>
  );
};

export default MainLayout;
