import { Card, Tag } from 'antd-mobile';
import { StarFill, LocationFill, ClockCircleFill } from 'antd-mobile-icons';
import './RestaurantCard.css';

/**
 * 餐厅卡片组件
 * @param {object} restaurant - 餐厅数据
 * @param {function} onClick - 点击回调
 */
const RestaurantCard = ({ restaurant, onClick }) => {
  return (
    <Card
      className="restaurant-card"
      onClick={() => onClick && onClick(restaurant)}
    >
      <div className="restaurant-content">
        <div className="restaurant-header">
          <h3 className="restaurant-name">{restaurant.name}</h3>
          <div className="restaurant-rating">
            <StarFill color="#ff6b00" fontSize={14} />
            <span>{restaurant.rating}</span>
          </div>
        </div>

        {restaurant.cuisine && restaurant.cuisine.length > 0 && (
          <div className="restaurant-tags">
            {restaurant.cuisine.map((c, i) => (
              <Tag
                key={i}
                color="primary"
                fill="outline"
                style={{ marginRight: 4, fontSize: 11 }}
              >
                {c}
              </Tag>
            ))}
          </div>
        )}

        <div className="restaurant-meta">
          {restaurant.distance !== undefined && (
            <span className="meta-item">
              <LocationFill fontSize={12} />
              {restaurant.distance}km
            </span>
          )}
          {restaurant.avgPrepMin && (
            <span className="meta-item">
              <ClockCircleFill fontSize={12} />
              约{restaurant.avgPrepMin}分钟
            </span>
          )}
        </div>

        <div className="restaurant-footer">
          {restaurant.minOrder !== undefined && (
            <span className="footer-item">起送${restaurant.minOrder}</span>
          )}
          {restaurant.deliveryFee !== undefined && (
            <>
              <span className="divider">|</span>
              <span className="footer-item">配送费${restaurant.deliveryFee}</span>
            </>
          )}
          {restaurant.onTimeRate !== undefined && (
            <>
              <span className="divider">|</span>
              <span className="footer-item on-time-rate">
                准时率{(restaurant.onTimeRate * 100).toFixed(0)}%
              </span>
            </>
          )}
        </div>
      </div>
    </Card>
  );
};

export default RestaurantCard;
